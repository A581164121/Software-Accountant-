#!/usr/bin/env python3
import sqlite3
import os
from datetime import datetime

class Database:
    def __init__(self, db_file="finance_flow.db"):
        """Initialize the database connection"""
        # Create directory for database if it doesn't exist
        os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)
        
        # Connect to database
        self.conn = sqlite3.connect(db_file)
        self.conn.row_factory = sqlite3.Row  # Return rows as dictionaries
        self.cursor = self.conn.cursor()
        
        # Create tables if they don't exist
        self.create_tables()
        
        # Insert demo data if database is empty
        self.initialize_demo_data()
    
    def create_tables(self):
        """Create all necessary tables if they don't exist"""
        # Users table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            role TEXT NOT NULL
        )
        ''')
        
        # Chart of Accounts table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS chart_of_accounts (
            id INTEGER PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            type TEXT NOT NULL,
            subtype TEXT NOT NULL,
            balance REAL DEFAULT 0,
            is_active INTEGER DEFAULT 1
        )
        ''')
        
        # Customers table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            address TEXT,
            balance REAL DEFAULT 0
        )
        ''')
        
        # Vendors table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendors (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT,
            phone TEXT,
            address TEXT,
            balance REAL DEFAULT 0
        )
        ''')
        
        # Inventory Items table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS inventory_items (
            id INTEGER PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            name TEXT NOT NULL,
            description TEXT,
            unit_price REAL NOT NULL,
            cost_price REAL NOT NULL,
            quantity_on_hand INTEGER DEFAULT 0,
            reorder_level INTEGER DEFAULT 0
        )
        ''')
        
        # Sales Invoices table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS sales_invoices (
            id INTEGER PRIMARY KEY,
            invoice_number TEXT NOT NULL UNIQUE,
            customer_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            subtotal REAL NOT NULL,
            tax REAL NOT NULL,
            total REAL NOT NULL,
            status TEXT NOT NULL,
            notes TEXT,
            FOREIGN KEY (customer_id) REFERENCES customers (id)
        )
        ''')
        
        # Sales Invoice Items table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS sales_invoice_items (
            id INTEGER PRIMARY KEY,
            sales_invoice_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            amount REAL NOT NULL,
            FOREIGN KEY (sales_invoice_id) REFERENCES sales_invoices (id),
            FOREIGN KEY (item_id) REFERENCES inventory_items (id)
        )
        ''')
        
        # Purchase Invoices table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS purchase_invoices (
            id INTEGER PRIMARY KEY,
            invoice_number TEXT NOT NULL UNIQUE,
            vendor_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            due_date TEXT NOT NULL,
            subtotal REAL NOT NULL,
            tax REAL NOT NULL,
            total REAL NOT NULL,
            status TEXT NOT NULL,
            notes TEXT,
            FOREIGN KEY (vendor_id) REFERENCES vendors (id)
        )
        ''')
        
        # Purchase Invoice Items table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS purchase_invoice_items (
            id INTEGER PRIMARY KEY,
            purchase_invoice_id INTEGER NOT NULL,
            item_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            amount REAL NOT NULL,
            FOREIGN KEY (purchase_invoice_id) REFERENCES purchase_invoices (id),
            FOREIGN KEY (item_id) REFERENCES inventory_items (id)
        )
        ''')
        
        # Journal Entries table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS journal_entries (
            id INTEGER PRIMARY KEY,
            entry_number TEXT NOT NULL UNIQUE,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            status TEXT NOT NULL,
            total_debit REAL NOT NULL,
            total_credit REAL NOT NULL
        )
        ''')
        
        # Journal Entry Lines table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS journal_entry_lines (
            id INTEGER PRIMARY KEY,
            journal_entry_id INTEGER NOT NULL,
            account_id INTEGER NOT NULL,
            description TEXT NOT NULL,
            debit REAL NOT NULL,
            credit REAL NOT NULL,
            FOREIGN KEY (journal_entry_id) REFERENCES journal_entries (id),
            FOREIGN KEY (account_id) REFERENCES chart_of_accounts (id)
        )
        ''')
        
        # Bank Accounts table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS bank_accounts (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            account_number TEXT NOT NULL UNIQUE,
            balance REAL DEFAULT 0,
            is_active INTEGER DEFAULT 1
        )
        ''')
        
        # Bank Transactions table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS bank_transactions (
            id INTEGER PRIMARY KEY,
            bank_account_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            description TEXT NOT NULL,
            amount REAL NOT NULL,
            type TEXT NOT NULL,
            reference TEXT,
            is_reconciled INTEGER DEFAULT 0,
            FOREIGN KEY (bank_account_id) REFERENCES bank_accounts (id)
        )
        ''')
        
        # Payments Received table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS payments_received (
            id INTEGER PRIMARY KEY,
            receipt_number TEXT NOT NULL UNIQUE,
            customer_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            reference TEXT,
            notes TEXT,
            FOREIGN KEY (customer_id) REFERENCES customers (id)
        )
        ''')
        
        # Payments Made table
        self.cursor.execute('''
        CREATE TABLE IF NOT EXISTS payments_made (
            id INTEGER PRIMARY KEY,
            payment_number TEXT NOT NULL UNIQUE,
            vendor_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            reference TEXT,
            notes TEXT,
            FOREIGN KEY (vendor_id) REFERENCES vendors (id)
        )
        ''')
        
        self.conn.commit()
    
    def initialize_demo_data(self):
        """Insert demo data if tables are empty"""
        # Check if users table is empty
        self.cursor.execute("SELECT COUNT(*) FROM users")
        if self.cursor.fetchone()[0] == 0:
            # Insert admin user
            self.cursor.execute(
                "INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)",
                ("admin", "admin123", "John Doe", "Administrator")
            )
            
            # Insert demo customers
            customers = [
                ("Tech Supplies Inc.", "contact@techsupplies.com", "555-123-4567", "123 Tech Blvd, Silicon Valley, CA 94025"),
                ("Acme Corporation", "info@acmecorp.com", "555-987-6543", "456 Industry Ave, Metropolis, NY 10001"),
                ("Global Partners LLC", "partners@globalpartners.com", "555-456-7890", "789 Global St, International City, TX 75001")
            ]
            self.cursor.executemany(
                "INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)",
                customers
            )
            
            # Insert demo vendors
            vendors = [
                ("Office Supplies Co.", "orders@officesupplies.com", "555-222-3333", "321 Supplier Rd, Commerce City, OH 43215"),
                ("Tech Hardware Ltd.", "sales@techhardware.com", "555-444-5555", "654 Component St, Assembly Town, WA 98001")
            ]
            self.cursor.executemany(
                "INSERT INTO vendors (name, email, phone, address) VALUES (?, ?, ?, ?)",
                vendors
            )
            
            # Insert demo inventory items
            inventory_items = [
                ("COMP-001", "Desktop Computer", "High-performance desktop workstation", 1200.00, 900.00, 15, 5),
                ("LAPTOP-001", "Business Laptop", "Lightweight business laptop with 16GB RAM", 950.00, 750.00, 22, 8),
                ("MONITOR-001", "24-inch Monitor", "Full HD monitor with adjustable stand", 250.00, 180.00, 30, 10)
            ]
            self.cursor.executemany(
                "INSERT INTO inventory_items (code, name, description, unit_price, cost_price, quantity_on_hand, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?)",
                inventory_items
            )
            
            # Insert demo chart of accounts
            chart_of_accounts = [
                ("1000", "Cash", "Asset", "Current Asset", 145629.78, 1),
                ("1100", "Accounts Receivable", "Asset", "Current Asset", 42580.00, 1),
                ("1200", "Inventory", "Asset", "Current Asset", 86450.00, 1),
                ("2000", "Accounts Payable", "Liability", "Current Liability", 28320.00, 1),
                ("4000", "Sales Revenue", "Revenue", "Operating Revenue", 128430.00, 1),
                ("5000", "Cost of Goods Sold", "Expense", "Operating Expense", 76235.00, 1)
            ]
            self.cursor.executemany(
                "INSERT INTO chart_of_accounts (code, name, type, subtype, balance, is_active) VALUES (?, ?, ?, ?, ?, ?)",
                chart_of_accounts
            )
            
            # Insert demo bank accounts
            bank_accounts = [
                ("Business Checking", "CHK-12345678", 125000.00, 1),
                ("Business Savings", "SAV-87654321", 50000.00, 1)
            ]
            self.cursor.executemany(
                "INSERT INTO bank_accounts (name, account_number, balance, is_active) VALUES (?, ?, ?, ?)",
                bank_accounts
            )
            
            # Get IDs for related entities
            self.cursor.execute("SELECT id FROM customers WHERE name=?", ("Tech Supplies Inc.",))
            customer1_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM customers WHERE name=?", ("Acme Corporation",))
            customer2_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM vendors WHERE name=?", ("Office Supplies Co.",))
            vendor1_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM inventory_items WHERE code=?", ("COMP-001",))
            item1_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM inventory_items WHERE code=?", ("LAPTOP-001",))
            item2_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM inventory_items WHERE code=?", ("MONITOR-001",))
            item3_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM bank_accounts WHERE name=?", ("Business Checking",))
            bank_account1_id = self.cursor.fetchone()[0]
            
            # Insert demo sales invoices
            sales_invoice1 = (
                "INV-202306001", customer1_id, "2023-06-24", "2023-07-24", 
                1960.00, 196.00, 2156.00, "paid", "Net 30 terms"
            )
            self.cursor.execute(
                "INSERT INTO sales_invoices (invoice_number, customer_id, date, due_date, subtotal, tax, total, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                sales_invoice1
            )
            sales_invoice1_id = self.cursor.lastrowid
            
            sales_invoice2 = (
                "INV-202306002", customer2_id, "2023-06-20", "2023-07-20", 
                7954.55, 795.45, 8750.00, "pending", "Corporate account"
            )
            self.cursor.execute(
                "INSERT INTO sales_invoices (invoice_number, customer_id, date, due_date, subtotal, tax, total, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                sales_invoice2
            )
            sales_invoice2_id = self.cursor.lastrowid
            
            # Insert demo sales invoice items
            sales_invoice_items = [
                (sales_invoice1_id, item1_id, "Desktop Computer", 1, 1200.00, 1200.00),
                (sales_invoice1_id, item3_id, "24-inch Monitor", 3, 250.00, 750.00),
                (sales_invoice2_id, item1_id, "Desktop Computer", 5, 1200.00, 6000.00),
                (sales_invoice2_id, item2_id, "Business Laptop", 2, 950.00, 1900.00)
            ]
            self.cursor.executemany(
                "INSERT INTO sales_invoice_items (sales_invoice_id, item_id, description, quantity, unit_price, amount) VALUES (?, ?, ?, ?, ?, ?)",
                sales_invoice_items
            )
            
            # Insert demo purchase invoices
            purchase_invoice1 = (
                "PO-202306001", vendor1_id, "2023-06-10", "2023-07-10", 
                1364.00, 136.40, 1500.40, "paid", "Office supplies"
            )
            self.cursor.execute(
                "INSERT INTO purchase_invoices (invoice_number, vendor_id, date, due_date, subtotal, tax, total, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                purchase_invoice1
            )
            purchase_invoice1_id = self.cursor.lastrowid
            
            # Insert demo purchase invoice items
            purchase_invoice_items = [
                (purchase_invoice1_id, item3_id, "24-inch Monitor", 4, 180.00, 720.00)
            ]
            self.cursor.executemany(
                "INSERT INTO purchase_invoice_items (purchase_invoice_id, item_id, description, quantity, unit_price, amount) VALUES (?, ?, ?, ?, ?, ?)",
                purchase_invoice_items
            )
            
            # Insert demo bank transactions
            bank_transactions = [
                (bank_account1_id, "2023-06-15", "Customer payment - Tech Supplies Inc.", 1450.00, "deposit", "DEP-12345", 1),
                (bank_account1_id, "2023-06-18", "Office rent payment", 3500.00, "withdrawal", "CHK-9876", 1),
                (bank_account1_id, "2023-06-22", "Vendor payment - Office Supplies Co.", 1250.00, "withdrawal", "CHK-9877", 0)
            ]
            self.cursor.executemany(
                "INSERT INTO bank_transactions (bank_account_id, date, description, amount, type, reference, is_reconciled) VALUES (?, ?, ?, ?, ?, ?, ?)",
                bank_transactions
            )
            
            # Insert demo journal entries
            journal_entry1 = (
                "JE-202306001", "2023-06-30", "End of month adjusting entry", "posted", 3500.00, 3500.00
            )
            self.cursor.execute(
                "INSERT INTO journal_entries (entry_number, date, description, status, total_debit, total_credit) VALUES (?, ?, ?, ?, ?, ?)",
                journal_entry1
            )
            journal_entry1_id = self.cursor.lastrowid
            
            # Insert demo journal entry lines
            self.cursor.execute("SELECT id FROM chart_of_accounts WHERE code=?", ("5000",))
            expense_account_id = self.cursor.fetchone()[0]
            
            self.cursor.execute("SELECT id FROM chart_of_accounts WHERE code=?", ("1000",))
            cash_account_id = self.cursor.fetchone()[0]
            
            journal_entry_lines = [
                (journal_entry1_id, expense_account_id, "Rent expense", 3500.00, 0.00),
                (journal_entry1_id, cash_account_id, "Cash payment", 0.00, 3500.00)
            ]
            self.cursor.executemany(
                "INSERT INTO journal_entry_lines (journal_entry_id, account_id, description, debit, credit) VALUES (?, ?, ?, ?, ?)",
                journal_entry_lines
            )
            
            # Insert demo payments
            payments_received = [
                ("RCPT-202306001", customer1_id, "2023-06-24", 2156.00, "bank_transfer", "WIRE-123456", "Payment for INV-202306001")
            ]
            self.cursor.executemany(
                "INSERT INTO payments_received (receipt_number, customer_id, date, amount, payment_method, reference, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
                payments_received
            )
            
            payments_made = [
                ("PMT-202306001", vendor1_id, "2023-06-15", 1500.40, "check", "CHK-100123", "Payment for PO-202306001")
            ]
            self.cursor.executemany(
                "INSERT INTO payments_made (payment_number, vendor_id, date, amount, payment_method, reference, notes) VALUES (?, ?, ?, ?, ?, ?, ?)",
                payments_made
            )
            
            self.conn.commit()
    
    #
    # USER METHODS
    #
    def get_user(self, user_id):
        """Get user by ID"""
        self.cursor.execute("SELECT * FROM users WHERE id=?", (user_id,))
        return dict(self.cursor.fetchone())
    
    def get_user_by_username(self, username):
        """Get user by username"""
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user = self.cursor.fetchone()
        return dict(user) if user else None
        
    def create_user(self, user_data):
        """Create a new user"""
        self.cursor.execute(
            "INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)",
            (user_data['username'], user_data['password'], user_data['name'], user_data['role'])
        )
        self.conn.commit()
        return self.get_user(self.cursor.lastrowid)
    
    #
    # CUSTOMER METHODS
    #
    def get_all_customers(self):
        """Get all customers"""
        self.cursor.execute("SELECT * FROM customers ORDER BY name")
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_customer(self, customer_id):
        """Get customer by ID"""
        self.cursor.execute("SELECT * FROM customers WHERE id=?", (customer_id,))
        customer = self.cursor.fetchone()
        return dict(customer) if customer else None
    
    def create_customer(self, customer_data):
        """Create a new customer"""
        self.cursor.execute(
            "INSERT INTO customers (name, email, phone, address) VALUES (?, ?, ?, ?)",
            (customer_data['name'], customer_data.get('email'), customer_data.get('phone'), customer_data.get('address'))
        )
        self.conn.commit()
        return self.get_customer(self.cursor.lastrowid)
    
    #
    # VENDOR METHODS
    #
    def get_all_vendors(self):
        """Get all vendors"""
        self.cursor.execute("SELECT * FROM vendors ORDER BY name")
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_vendor(self, vendor_id):
        """Get vendor by ID"""
        self.cursor.execute("SELECT * FROM vendors WHERE id=?", (vendor_id,))
        vendor = self.cursor.fetchone()
        return dict(vendor) if vendor else None
    
    def create_vendor(self, vendor_data):
        """Create a new vendor"""
        self.cursor.execute(
            "INSERT INTO vendors (name, email, phone, address) VALUES (?, ?, ?, ?)",
            (vendor_data['name'], vendor_data.get('email'), vendor_data.get('phone'), vendor_data.get('address'))
        )
        self.conn.commit()
        return self.get_vendor(self.cursor.lastrowid)
    
    #
    # INVENTORY METHODS
    #
    def get_all_inventory_items(self):
        """Get all inventory items"""
        self.cursor.execute("SELECT * FROM inventory_items ORDER BY name")
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_inventory_item(self, item_id):
        """Get inventory item by ID"""
        self.cursor.execute("SELECT * FROM inventory_items WHERE id=?", (item_id,))
        item = self.cursor.fetchone()
        return dict(item) if item else None
    
    def create_inventory_item(self, item_data):
        """Create a new inventory item"""
        self.cursor.execute(
            "INSERT INTO inventory_items (code, name, description, unit_price, cost_price, quantity_on_hand, reorder_level) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (item_data['code'], item_data['name'], item_data.get('description'), 
             item_data['unit_price'], item_data['cost_price'], 
             item_data.get('quantity_on_hand', 0), item_data.get('reorder_level', 0))
        )
        self.conn.commit()
        return self.get_inventory_item(self.cursor.lastrowid)
    
    def update_inventory_item(self, item_id, item_data):
        """Update an inventory item"""
        # Build SET clause and parameters for the query
        set_clause = []
        params = []
        
        for key, value in item_data.items():
            if key in ['code', 'name', 'description', 'unit_price', 'cost_price', 'quantity_on_hand', 'reorder_level']:
                # Convert keys from camelCase to snake_case for database
                db_key = key
                set_clause.append(f"{db_key}=?")
                params.append(value)
        
        if not set_clause:
            return None
        
        params.append(item_id)
        query = f"UPDATE inventory_items SET {', '.join(set_clause)} WHERE id=?"
        
        self.cursor.execute(query, params)
        self.conn.commit()
        
        return self.get_inventory_item(item_id)
    
    def delete_inventory_item(self, item_id):
        """Delete an inventory item"""
        # Check if the item exists
        item = self.get_inventory_item(item_id)
        if not item:
            return False
        
        # Delete the item
        self.cursor.execute("DELETE FROM inventory_items WHERE id=?", (item_id,))
        self.conn.commit()
        
        return True
    
    #
    # SALES INVOICE METHODS
    #
    def get_all_sales_invoices(self):
        """Get all sales invoices with customer details"""
        self.cursor.execute("""
            SELECT si.*, c.name as customer_name 
            FROM sales_invoices si
            JOIN customers c ON si.customer_id = c.id
            ORDER BY si.date DESC
        """)
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_sales_invoice(self, invoice_id):
        """Get sales invoice by ID with items"""
        self.cursor.execute("""
            SELECT si.*, c.name as customer_name 
            FROM sales_invoices si
            JOIN customers c ON si.customer_id = c.id
            WHERE si.id=?
        """, (invoice_id,))
        invoice = self.cursor.fetchone()
        
        if not invoice:
            return None
            
        invoice_dict = dict(invoice)
        
        # Get items for this invoice
        self.cursor.execute("""
            SELECT sii.*, i.code as item_code, i.name as item_name
            FROM sales_invoice_items sii
            JOIN inventory_items i ON sii.item_id = i.id
            WHERE sii.sales_invoice_id=?
        """, (invoice_id,))
        
        invoice_dict['items'] = [dict(row) for row in self.cursor.fetchall()]
        
        return invoice_dict
    
    def create_sales_invoice(self, invoice_data, items_data):
        """Create a new sales invoice with items"""
        self.cursor.execute(
            """INSERT INTO sales_invoices 
               (invoice_number, customer_id, date, due_date, subtotal, tax, total, status, notes) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (invoice_data['invoice_number'], invoice_data['customer_id'], 
             invoice_data['date'], invoice_data['due_date'], 
             invoice_data['subtotal'], invoice_data['tax'], invoice_data['total'], 
             invoice_data.get('status', 'draft'), invoice_data.get('notes'))
        )
        
        invoice_id = self.cursor.lastrowid
        
        # Insert invoice items
        for item in items_data:
            self.cursor.execute(
                """INSERT INTO sales_invoice_items 
                   (sales_invoice_id, item_id, description, quantity, unit_price, amount) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (invoice_id, item['item_id'], item['description'], 
                 item['quantity'], item['unit_price'], item['amount'])
            )
            
            # Update inventory quantity
            self.cursor.execute(
                "UPDATE inventory_items SET quantity_on_hand = quantity_on_hand - ? WHERE id=?",
                (item['quantity'], item['item_id'])
            )
        
        # Update customer balance
        self.cursor.execute(
            "UPDATE customers SET balance = balance + ? WHERE id=?",
            (invoice_data['total'], invoice_data['customer_id'])
        )
        
        self.conn.commit()
        
        return self.get_sales_invoice(invoice_id)
    
    #
    # PURCHASE INVOICE METHODS
    #
    def get_all_purchase_invoices(self):
        """Get all purchase invoices with vendor details"""
        self.cursor.execute("""
            SELECT pi.*, v.name as vendor_name 
            FROM purchase_invoices pi
            JOIN vendors v ON pi.vendor_id = v.id
            ORDER BY pi.date DESC
        """)
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_purchase_invoice(self, invoice_id):
        """Get purchase invoice by ID with items"""
        self.cursor.execute("""
            SELECT pi.*, v.name as vendor_name 
            FROM purchase_invoices pi
            JOIN vendors v ON pi.vendor_id = v.id
            WHERE pi.id=?
        """, (invoice_id,))
        invoice = self.cursor.fetchone()
        
        if not invoice:
            return None
            
        invoice_dict = dict(invoice)
        
        # Get items for this invoice
        self.cursor.execute("""
            SELECT pii.*, i.code as item_code, i.name as item_name
            FROM purchase_invoice_items pii
            JOIN inventory_items i ON pii.item_id = i.id
            WHERE pii.purchase_invoice_id=?
        """, (invoice_id,))
        
        invoice_dict['items'] = [dict(row) for row in self.cursor.fetchall()]
        
        return invoice_dict
    
    def create_purchase_invoice(self, invoice_data, items_data):
        """Create a new purchase invoice with items"""
        self.cursor.execute(
            """INSERT INTO purchase_invoices 
               (invoice_number, vendor_id, date, due_date, subtotal, tax, total, status, notes) 
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (invoice_data['invoice_number'], invoice_data['vendor_id'], 
             invoice_data['date'], invoice_data['due_date'], 
             invoice_data['subtotal'], invoice_data['tax'], invoice_data['total'], 
             invoice_data.get('status', 'draft'), invoice_data.get('notes'))
        )
        
        invoice_id = self.cursor.lastrowid
        
        # Insert invoice items
        for item in items_data:
            self.cursor.execute(
                """INSERT INTO purchase_invoice_items 
                   (purchase_invoice_id, item_id, description, quantity, unit_price, amount) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (invoice_id, item['item_id'], item['description'], 
                 item['quantity'], item['unit_price'], item['amount'])
            )
            
            # Update inventory quantity
            self.cursor.execute(
                "UPDATE inventory_items SET quantity_on_hand = quantity_on_hand + ? WHERE id=?",
                (item['quantity'], item['item_id'])
            )
        
        # Update vendor balance
        self.cursor.execute(
            "UPDATE vendors SET balance = balance + ? WHERE id=?",
            (invoice_data['total'], invoice_data['vendor_id'])
        )
        
        self.conn.commit()
        
        return self.get_purchase_invoice(invoice_id)
    
    #
    # ACCOUNTS RECEIVABLE/PAYABLE METHODS
    #
    def get_accounts_receivable(self):
        """Get accounts receivable data"""
        self.cursor.execute("""
            SELECT si.id, si.invoice_number, si.date, si.due_date, si.total, si.status,
                   c.id as customer_id, c.name as customer_name, c.balance
            FROM sales_invoices si
            JOIN customers c ON si.customer_id = c.id
            WHERE si.status != 'paid'
            ORDER BY si.due_date
        """)
        return [dict(row) for row in self.cursor.fetchall()]
    
    def get_accounts_payable(self):
        """Get accounts payable data"""
        self.cursor.execute("""
            SELECT pi.id, pi.invoice_number, pi.date, pi.due_date, pi.total, pi.status,
                   v.id as vendor_id, v.name as vendor_name, v.balance
            FROM purchase_invoices pi
            JOIN vendors v ON pi.vendor_id = v.id
            WHERE pi.status != 'paid'
            ORDER BY pi.due_date
        """)
        return [dict(row) for row in self.cursor.fetchall()]
    
    #
    # DASHBOARD AND REPORTING METHODS
    #
    def get_dashboard_data(self, period='month'):
        """Get dashboard data including KPIs and charts"""
        current_date = datetime.now().strftime('%Y-%m-%d')
        
        # Calculate date ranges
        if period == 'month':
            start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        elif period == 'quarter':
            month = datetime.now().month
            quarter_start_month = ((month - 1) // 3) * 3 + 1
            start_date = datetime.now().replace(month=quarter_start_month, day=1).strftime('%Y-%m-%d')
        elif period == 'year':
            start_date = datetime.now().replace(month=1, day=1).strftime('%Y-%m-%d')
        else:
            start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        
        # Get total revenue (sales)
        self.cursor.execute(
            """SELECT SUM(total) as total 
               FROM sales_invoices 
               WHERE date BETWEEN ? AND ?""",
            (start_date, current_date)
        )
        revenue = self.cursor.fetchone()[0] or 0
        
        # Get total expenses
        self.cursor.execute(
            """SELECT SUM(amount) as total 
               FROM journal_entry_lines jel
               JOIN journal_entries je ON jel.journal_entry_id = je.id
               JOIN chart_of_accounts coa ON jel.account_id = coa.id
               WHERE je.date BETWEEN ? AND ?
               AND coa.type = 'Expense'
               AND jel.debit > 0""",
            (start_date, current_date)
        )
        expenses = self.cursor.fetchone()[0] or 0
        
        # Get accounts receivable (unpaid invoices)
        self.cursor.execute(
            """SELECT SUM(total) as total 
               FROM sales_invoices 
               WHERE status != 'paid'"""
        )
        receivables = self.cursor.fetchone()[0] or 0
        
        # Get accounts payable (unpaid bills)
        self.cursor.execute(
            """SELECT SUM(total) as total 
               FROM purchase_invoices 
               WHERE status != 'paid'"""
        )
        payables = self.cursor.fetchone()[0] or 0
        
        # Get bank balances
        self.cursor.execute(
            """SELECT SUM(balance) as total 
               FROM bank_accounts"""
        )
        bank_balance = self.cursor.fetchone()[0] or 0
        
        # Get low stock items
        self.cursor.execute(
            """SELECT COUNT(*) as count 
               FROM inventory_items
               WHERE quantity_on_hand <= reorder_level"""
        )
        low_stock_count = self.cursor.fetchone()[0] or 0
        
        # Sales by month (last 6 months)
        self.cursor.execute(
            """SELECT strftime('%Y-%m', date) as month, 
                      SUM(total) as total
               FROM sales_invoices
               GROUP BY month
               ORDER BY month DESC
               LIMIT 6"""
        )
        sales_by_month = [dict(row) for row in self.cursor.fetchall()]
        sales_by_month.reverse()  # Show in chronological order
        
        # Top 5 customers
        self.cursor.execute(
            """SELECT c.name, SUM(si.total) as total
               FROM sales_invoices si
               JOIN customers c ON si.customer_id = c.id
               GROUP BY c.id
               ORDER BY total DESC
               LIMIT 5"""
        )
        top_customers = [dict(row) for row in self.cursor.fetchall()]
        
        return {
            'kpis': {
                'revenue': revenue,
                'expenses': expenses,
                'net_income': revenue - expenses,
                'receivables': receivables,
                'payables': payables,
                'bank_balance': bank_balance,
                'low_stock_count': low_stock_count,
            },
            'charts': {
                'sales_by_month': sales_by_month,
                'top_customers': top_customers,
            }
        }
    
    def get_recent_transactions(self, limit=10):
        """Get recent transactions for the dashboard"""
        # Recent sales invoices
        self.cursor.execute(
            """SELECT 'sales_invoice' as type, id, invoice_number as reference, 
                      date, total as amount, status,
                      (SELECT name FROM customers WHERE id = customer_id) as entity_name
               FROM sales_invoices
               ORDER BY date DESC
               LIMIT ?""",
            (limit // 2,)
        )
        recent_sales = [dict(row) for row in self.cursor.fetchall()]
        
        # Recent purchase invoices
        self.cursor.execute(
            """SELECT 'purchase_invoice' as type, id, invoice_number as reference, 
                      date, total as amount, status,
                      (SELECT name FROM vendors WHERE id = vendor_id) as entity_name
               FROM purchase_invoices
               ORDER BY date DESC
               LIMIT ?""",
            (limit // 2,)
        )
        recent_purchases = [dict(row) for row in self.cursor.fetchall()]
        
        # Combine and sort by date
        transactions = recent_sales + recent_purchases
        transactions.sort(key=lambda x: x['date'], reverse=True)
        
        return transactions[:limit]
    
    def get_balance_sheet_report(self, as_of_date=None, compare_with=None):
        """Generate a balance sheet report as of a specific date"""
        if not as_of_date:
            as_of_date = datetime.now().strftime('%Y-%m-%d')
        
        # Assets
        self.cursor.execute(
            """SELECT id, code, name, type, subtype, balance
               FROM chart_of_accounts
               WHERE type = 'Asset'
               AND is_active = 1
               ORDER BY code"""
        )
        assets = [dict(row) for row in self.cursor.fetchall()]
        
        # Group assets
        current_assets = [a for a in assets if a['subtype'] == 'Current Asset']
        fixed_assets = [a for a in assets if a['subtype'] == 'Fixed Asset']
        other_assets = [a for a in assets if a['subtype'] == 'Other Asset']
        
        # Calculate totals
        total_current_assets = sum(a['balance'] for a in current_assets)
        total_fixed_assets = sum(a['balance'] for a in fixed_assets)
        total_other_assets = sum(a['balance'] for a in other_assets)
        total_assets = total_current_assets + total_fixed_assets + total_other_assets
        
        # Liabilities
        self.cursor.execute(
            """SELECT id, code, name, type, subtype, balance
               FROM chart_of_accounts
               WHERE type = 'Liability'
               AND is_active = 1
               ORDER BY code"""
        )
        liabilities = [dict(row) for row in self.cursor.fetchall()]
        
        # Group liabilities
        current_liabilities = [l for l in liabilities if l['subtype'] == 'Current Liability']
        long_term_liabilities = [l for l in liabilities if l['subtype'] == 'Long Term Liability']
        
        # Calculate totals
        total_current_liabilities = sum(l['balance'] for l in current_liabilities)
        total_long_term_liabilities = sum(l['balance'] for l in long_term_liabilities)
        total_liabilities = total_current_liabilities + total_long_term_liabilities
        
        # Equity
        self.cursor.execute(
            """SELECT id, code, name, type, subtype, balance
               FROM chart_of_accounts
               WHERE type = 'Equity'
               AND is_active = 1
               ORDER BY code"""
        )
        equity_accounts = [dict(row) for row in self.cursor.fetchall()]
        
        # Calculate retained earnings
        self.cursor.execute(
            """SELECT 
                   SUM(CASE WHEN type = 'Revenue' THEN balance ELSE 0 END) - 
                   SUM(CASE WHEN type = 'Expense' THEN balance ELSE 0 END) as retained_earnings
               FROM chart_of_accounts
               WHERE (type = 'Revenue' OR type = 'Expense')
               AND is_active = 1"""
        )
        retained_earnings = self.cursor.fetchone()[0] or 0
        
        # Add retained earnings to equity
        equity_accounts.append({
            'id': None,
            'code': 'RE',
            'name': 'Retained Earnings',
            'type': 'Equity',
            'subtype': 'Equity',
            'balance': retained_earnings
        })
        
        # Calculate total equity
        total_equity = sum(e['balance'] for e in equity_accounts)
        
        # Total liabilities and equity
        total_liabilities_and_equity = total_liabilities + total_equity
        
        return {
            'as_of_date': as_of_date,
            'assets': {
                'current_assets': current_assets,
                'fixed_assets': fixed_assets,
                'other_assets': other_assets,
                'total_current_assets': total_current_assets,
                'total_fixed_assets': total_fixed_assets,
                'total_other_assets': total_other_assets,
                'total_assets': total_assets
            },
            'liabilities': {
                'current_liabilities': current_liabilities,
                'long_term_liabilities': long_term_liabilities,
                'total_current_liabilities': total_current_liabilities,
                'total_long_term_liabilities': total_long_term_liabilities,
                'total_liabilities': total_liabilities
            },
            'equity': {
                'accounts': equity_accounts,
                'retained_earnings': retained_earnings,
                'total_equity': total_equity
            },
            'total_liabilities_and_equity': total_liabilities_and_equity
        }
    
    def get_cash_flow_report(self, period='month', start_date=None, end_date=None):
        """Generate a cash flow report for a specific period"""
        if not start_date:
            start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Operating activities
        # Cash receipts from customers
        self.cursor.execute(
            """SELECT SUM(amount) as total
               FROM payments_received
               WHERE date BETWEEN ? AND ?""",
            (start_date, end_date)
        )
        cash_receipts = self.cursor.fetchone()[0] or 0
        
        # Cash payments to vendors
        self.cursor.execute(
            """SELECT SUM(amount) as total
               FROM payments_made
               WHERE date BETWEEN ? AND ?""",
            (start_date, end_date)
        )
        cash_payments_to_vendors = self.cursor.fetchone()[0] or 0
        
        # Net cash from operating activities
        net_cash_from_operations = cash_receipts - cash_payments_to_vendors
        
        # Net increase/decrease in cash
        net_cash_change = net_cash_from_operations
        
        # Cash at the beginning of the period
        self.cursor.execute(
            """SELECT SUM(balance) as total
               FROM bank_accounts
               WHERE is_active = 1"""
        )
        ending_cash = self.cursor.fetchone()[0] or 0
        beginning_cash = ending_cash - net_cash_change
        
        return {
            'period': period,
            'start_date': start_date,
            'end_date': end_date,
            'operating_activities': {
                'cash_receipts': cash_receipts,
                'cash_payments_to_vendors': cash_payments_to_vendors,
                'net_cash_from_operations': net_cash_from_operations
            },
            'cash_summary': {
                'beginning_cash': beginning_cash,
                'net_cash_change': net_cash_change,
                'ending_cash': ending_cash
            }
        }
    
    def get_profit_loss_report(self, period='month', start_date=None, end_date=None, compare_with=None):
        """Generate a profit and loss report for a specific period"""
        if not start_date:
            start_date = datetime.now().replace(day=1).strftime('%Y-%m-%d')
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Revenue - using demo data for now
        revenue = {
            'sales': 120540.00,
            'service_revenue': 7890.00,
            'other_revenue': 0.00,
            'total_revenue': 128430.00,
        }
        
        # Cost of Sales - using demo data
        cost_of_sales = {
            'cost_of_goods': 68250.00,
            'direct_labor': 7985.00,
            'total_cost_of_sales': 76235.00,
        }
        
        # Gross profit
        gross_profit = revenue['total_revenue'] - cost_of_sales['total_cost_of_sales']
        
        # Operating expenses - using demo data
        expenses = {
            'salaries': 14850.00,
            'rent': 3500.00,
            'utilities': 980.00,
            'office_supplies': 650.00,
            'marketing': 2500.00,
            'insurance': 1200.00,
            'depreciation': 1850.00,
            'other_expenses': 450.00,
            'total_expenses': 25980.00
        }
        
        # Operating income
        operating_income = gross_profit - expenses['total_expenses']
        
        # Other income and expenses
        other_income = {
            'interest_income': 0.00,
            'total_other_income': 0.00
        }
        
        other_expenses = {
            'interest_expense': 2000.00,
            'total_other_expenses': 2000.00
        }
        
        # Net income before tax
        net_income_before_tax = operating_income + other_income['total_other_income'] - other_expenses['total_other_expenses']
        
        # Income tax
        income_tax = {
            'current_tax': 10000.00,
            'total_tax': 10000.00
        }
        
        # Net income
        net_income = net_income_before_tax - income_tax['total_tax']
        
        # Monthly data for charts
        monthly_data = [
            { 'name': 'Jan', 'revenue': 108250, 'expenses': 92450, 'profit': 15800 },
            { 'name': 'Feb', 'revenue': 116420, 'expenses': 96780, 'profit': 19640 },
            { 'name': 'Mar', 'revenue': 112380, 'expenses': 99240, 'profit': 13140 },
            { 'name': 'Apr', 'revenue': 118650, 'expenses': 100850, 'profit': 17800 },
            { 'name': 'May', 'revenue': 122430, 'expenses': 97600, 'profit': 24830 },
            { 'name': 'Jun', 'revenue': 128430, 'expenses': 104215, 'profit': 24215 },
        ]
        
        return {
            'period': period,
            'start_date': start_date,
            'end_date': end_date,
            'revenue': revenue,
            'cost_of_sales': cost_of_sales,
            'gross_profit': gross_profit,
            'expenses': expenses,
            'operating_income': operating_income,
            'other_income': other_income,
            'other_expenses': other_expenses,
            'net_income_before_tax': net_income_before_tax,
            'income_tax': income_tax,
            'net_income': net_income,
            'monthly_data': monthly_data
        }