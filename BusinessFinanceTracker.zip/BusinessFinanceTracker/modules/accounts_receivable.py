#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime, timedelta

class PaymentForm(tk.Toplevel):
    """Form for recording payments received"""
    def __init__(self, parent, controller, invoice=None):
        super().__init__(parent)
        self.parent = parent
        self.controller = controller
        self.db = controller.db
        self.invoice = invoice
        
        # Window setup
        self.title("Record Payment")
        self.geometry("500x500")
        self.resizable(False, False)
        self.configure(background=controller.bg_color)
        
        # Make it a modal dialog
        self.transient(parent)
        self.grab_set()
        
        # Create form widgets
        self.create_widgets()
        
        # Populate customer and invoice data if provided
        if self.invoice:
            self.populate_fields()
        
        # Center the window
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        """Create form widgets"""
        # Main frame
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(
            main_frame, 
            text="Record Payment Received", 
            font=("Helvetica", 16, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 20))
        
        # Form fields
        # Receipt Number
        ttk.Label(main_frame, text="Receipt Number:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.receipt_var = tk.StringVar()
        # Generate a sequential receipt number
        self.receipt_var.set(f"RCPT-{datetime.now().strftime('%Y%m%d')}-{datetime.now().microsecond//1000}")
        receipt_entry = ttk.Entry(main_frame, textvariable=self.receipt_var, width=30)
        receipt_entry.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Customer
        ttk.Label(main_frame, text="Customer:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.customer_var = tk.StringVar()
        
        # Get all customers for dropdown
        customers = self.db.get_all_customers()
        customer_names = [customer['name'] for customer in customers]
        
        self.customer_combo = ttk.Combobox(main_frame, textvariable=self.customer_var, width=30, state="readonly")
        self.customer_combo['values'] = customer_names
        self.customer_combo.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Date
        ttk.Label(main_frame, text="Date:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.date_var = tk.StringVar()
        self.date_var.set(datetime.now().strftime("%Y-%m-%d"))
        date_entry = ttk.Entry(main_frame, textvariable=self.date_var, width=30)
        date_entry.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Amount
        ttk.Label(main_frame, text="Amount ($):").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.amount_var = tk.DoubleVar()
        amount_entry = ttk.Entry(main_frame, textvariable=self.amount_var, width=30)
        amount_entry.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Payment Method
        ttk.Label(main_frame, text="Payment Method:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.method_var = tk.StringVar()
        methods = ["Bank Transfer", "Check", "Credit Card", "Cash", "PayPal", "Other"]
        method_combo = ttk.Combobox(main_frame, textvariable=self.method_var, width=30, state="readonly")
        method_combo['values'] = methods
        method_combo.current(0)
        method_combo.grid(row=5, column=1, sticky=tk.W, pady=5)
        
        # Reference Number
        ttk.Label(main_frame, text="Reference Number:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.reference_var = tk.StringVar()
        reference_entry = ttk.Entry(main_frame, textvariable=self.reference_var, width=30)
        reference_entry.grid(row=6, column=1, sticky=tk.W, pady=5)
        
        # Notes
        ttk.Label(main_frame, text="Notes:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.notes_text = tk.Text(main_frame, width=30, height=4)
        self.notes_text.grid(row=7, column=1, sticky=tk.W, pady=5)
        
        # Separator
        ttk.Separator(main_frame, orient='horizontal').grid(
            row=8, column=0, columnspan=2, sticky=tk.EW, pady=20)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=9, column=0, columnspan=2, sticky=tk.EW)
        
        ttk.Button(button_frame, text="Cancel", command=self.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(
            button_frame, 
            text="Record Payment", 
            style="Primary.TButton", 
            command=self.save_payment
        ).pack(side=tk.RIGHT, padx=5)
        
        # Bind customer selection to update invoice details
        self.customer_combo.bind("<<ComboboxSelected>>", self.on_customer_selected)
    
    def populate_fields(self):
        """Populate form fields with invoice data"""
        if self.invoice:
            # Select the customer
            self.customer_var.set(self.invoice.get('customer_name', ''))
            
            # Set the amount to the invoice total
            self.amount_var.set(self.invoice.get('total', 0.0))
            
            # Add invoice reference to notes
            self.notes_text.insert('1.0', f"Payment for invoice {self.invoice.get('invoice_number', '')}")
    
    def on_customer_selected(self, event):
        """Handle customer selection - update related fields"""
        customer_name = self.customer_var.get()
        
        # Get customer details
        customers = self.db.get_all_customers()
        selected_customer = None
        
        for customer in customers:
            if customer['name'] == customer_name:
                selected_customer = customer
                break
        
        if selected_customer:
            # Could update other fields based on customer if needed
            pass
    
    def validate_form(self):
        """Validate form fields"""
        errors = []
        
        if not self.receipt_var.get().strip():
            errors.append("Receipt Number is required")
        
        if not self.customer_var.get():
            errors.append("Customer is required")
        
        try:
            amount = float(self.amount_var.get())
            if amount <= 0:
                errors.append("Amount must be greater than 0")
        except:
            errors.append("Amount must be a valid number")
        
        if not self.method_var.get():
            errors.append("Payment Method is required")
        
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors))
            return False
        
        return True
    
    def save_payment(self):
        """Save the payment received"""
        if not self.validate_form():
            return
        
        try:
            # Get customer ID from name
            customer_name = self.customer_var.get()
            customers = self.db.get_all_customers()
            customer_id = None
            
            for customer in customers:
                if customer['name'] == customer_name:
                    customer_id = customer['id']
                    break
            
            if not customer_id:
                messagebox.showerror("Error", "Could not find the selected customer")
                return
            
            # Prepare payment data
            payment_data = {
                'receipt_number': self.receipt_var.get().strip(),
                'customer_id': customer_id,
                'date': self.date_var.get(),
                'amount': float(self.amount_var.get()),
                'payment_method': self.method_var.get().lower().replace(' ', '_'),
                'reference': self.reference_var.get().strip(),
                'notes': self.notes_text.get('1.0', tk.END).strip()
            }
            
            # Create payment record
            self.db.create_payment_received(payment_data)
            
            # Update invoice status if applicable
            if self.invoice and self.invoice.get('id'):
                # In a real app, we would update the invoice status to 'paid'
                # and potentially handle partial payments
                pass
            
            messagebox.showinfo("Success", "Payment recorded successfully")
            
            # Refresh parent and close the form
            if isinstance(self.parent, AccountsReceivableFrame):
                self.parent.refresh_data()
            self.destroy()
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")


class AccountsReceivableFrame(ttk.Frame):
    """Main accounts receivable frame"""
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = controller.db
        
        # Create accounts receivable UI
        self.create_widgets()
    
    def create_widgets(self):
        """Create all widgets for accounts receivable"""
        # Main container with scrollbar
        self.main_canvas = tk.Canvas(self, bg=self.controller.bg_color)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.main_canvas.yview)
        self.scrollable_frame = ttk.Frame(self.main_canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all")
            )
        )
        
        self.main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Header section with title and action buttons
        self.create_header_section()
        
        # Summary statistics
        self.create_summary_section()
        
        # Receivables aging table
        self.create_aging_table()
        
        # Customer balances and trends
        self.create_customer_section()
    
    def create_header_section(self):
        """Create the header section with title and buttons"""
        header_frame = ttk.Frame(self.scrollable_frame)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        # Title
        title_label = ttk.Label(
            header_frame, 
            text="Accounts Receivable", 
            font=("Helvetica", 24, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        # Action buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        ttk.Button(
            button_frame,
            text="Record Payment",
            style="Primary.TButton",
            command=self.record_payment
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Create Invoice",
            style="Success.TButton",
            command=self.create_invoice
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Print Statements",
            command=self.print_statements
        ).pack(side=tk.LEFT, padx=5)
    
    def create_summary_section(self):
        """Create the summary statistics section"""
        # Section frame
        summary_frame = ttk.Frame(self.scrollable_frame)
        summary_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Configure grid columns
        for i in range(4):
            summary_frame.columnconfigure(i, weight=1)
        
        # Create summary cards
        self.create_summary_card(summary_frame, "Total Receivables", "$42,580.00", row=0, column=0)
        self.create_summary_card(summary_frame, "Current", "$24,150.00", row=0, column=1)
        self.create_summary_card(summary_frame, "1-30 Days Overdue", "$10,560.00", row=0, column=2)
        self.create_summary_card(summary_frame, "31+ Days Overdue", "$7,870.00", row=0, column=3)
    
    def create_summary_card(self, parent, title, value, **grid_options):
        """Create an individual summary card"""
        # Card frame
        card = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        card.grid(padx=5, pady=5, sticky=tk.NSEW, **grid_options)
        
        # Title
        title_label = ttk.Label(
            card, 
            text=title, 
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.CENTER)
        
        # Value
        value_label = ttk.Label(
            card, 
            text=value, 
            font=("Helvetica", 20, "bold"),
            foreground=self.controller.text_color
        )
        value_label.pack(anchor=tk.CENTER, pady=(5, 0))
    
    def create_aging_table(self):
        """Create the receivables aging table"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Accounts Receivable Aging", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # Table container
        table_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(0, 0))
        table_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Create treeview
        columns = ('invoice', 'customer', 'date', 'due_date', 'amount', 'current', 'days_1_30', 'days_31_60', 'days_61_plus')
        self.aging_tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=10)
        
        # Define column headings
        self.aging_tree.heading('invoice', text='Invoice #')
        self.aging_tree.heading('customer', text='Customer')
        self.aging_tree.heading('date', text='Date')
        self.aging_tree.heading('due_date', text='Due Date')
        self.aging_tree.heading('amount', text='Amount')
        self.aging_tree.heading('current', text='Current')
        self.aging_tree.heading('days_1_30', text='1-30 Days')
        self.aging_tree.heading('days_31_60', text='31-60 Days')
        self.aging_tree.heading('days_61_plus', text='61+ Days')
        
        # Define column widths and alignment
        self.aging_tree.column('invoice', width=100, anchor='w')
        self.aging_tree.column('customer', width=150, anchor='w')
        self.aging_tree.column('date', width=100, anchor='center')
        self.aging_tree.column('due_date', width=100, anchor='center')
        self.aging_tree.column('amount', width=100, anchor='e')
        self.aging_tree.column('current', width=100, anchor='e')
        self.aging_tree.column('days_1_30', width=100, anchor='e')
        self.aging_tree.column('days_31_60', width=100, anchor='e')
        self.aging_tree.column('days_61_plus', width=100, anchor='e')
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.aging_tree.yview)
        self.aging_tree.configure(yscroll=y_scrollbar.set)
        
        x_scrollbar = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.aging_tree.xview)
        self.aging_tree.configure(xscroll=x_scrollbar.set)
        
        # Pack widgets
        self.aging_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        x_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Add right-click context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Record Payment", command=self.record_payment_for_selected)
        self.context_menu.add_command(label="View Invoice", command=self.view_invoice)
        self.context_menu.add_command(label="Mark as Paid", command=self.mark_as_paid)
        self.context_menu.add_command(label="Send Reminder", command=self.send_reminder)
        
        self.aging_tree.bind("<Button-3>", self.show_context_menu)
        self.aging_tree.bind("<Double-1>", lambda e: self.view_invoice())
    
    def create_customer_section(self):
        """Create customer balances and trends section"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Customer Balances", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # Charts container
        charts_frame = ttk.Frame(self.scrollable_frame)
        charts_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Configure grid
        charts_frame.columnconfigure(0, weight=2)  # Balances chart is wider
        charts_frame.columnconfigure(1, weight=1)
        
        # Create top customers chart
        self.create_customer_balances_chart(charts_frame)
        
        # Create aging breakdown chart
        self.create_aging_chart(charts_frame)
    
    def create_customer_balances_chart(self, parent):
        """Create customer balances chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Top Customers by Outstanding Balance", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data - would come from database in real app
        customers = ['Acme Corporation', 'Tech Supplies Inc.', 'Global Partners LLC', 'Metro Services', 'First Co.']
        balances = [18750, 12580, 5400, 3650, 2200]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(8, 4), dpi=100)
        
        # Plot data - horizontal bar chart
        bars = ax.barh(customers, balances, color=self.controller.primary_color, alpha=0.7)
        
        # Add labels
        ax.set_xlabel('Outstanding Balance ($)')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        
        # Add value labels
        for bar in bars:
            width = bar.get_width()
            ax.text(width + 200, bar.get_y() + bar.get_height()/2, 
                    f'${width:,.0f}', ha='left', va='center')
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_aging_chart(self, parent):
        """Create aging breakdown chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Aging Breakdown", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data - would come from database in real app
        labels = ['Current', '1-30 Days', '31-60 Days', '61+ Days']
        sizes = [24150, 10560, 4350, 3520]
        total = sum(sizes)
        percentages = [size/total for size in sizes]
        
        # Format labels with percentages
        labels = [f"{label}\n({100*pct:.1f}%)" for label, pct in zip(labels, percentages)]
        
        # Define colors
        colors = [self.controller.secondary_color, '#3498db', '#f39c12', self.controller.accent_color]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(4, 4), dpi=100)
        
        # Plot data - pie chart
        wedges, texts = ax.pie(
            sizes, 
            labels=labels,
            colors=colors,
            autopct=lambda pct: f"${total*pct/100:,.0f}",
            startangle=90,
            wedgeprops=dict(width=0.5)  # Make it a donut
        )
        
        # Customize text
        for text in texts:
            text.set_fontsize(9)
        
        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.set_aspect('equal')
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def refresh_data(self):
        """Refresh accounts receivable data from the database"""
        # Get accounts receivable data
        receivables = self.db.get_accounts_receivable()
        
        # Clear existing items
        for item in self.aging_tree.get_children():
            self.aging_tree.delete(item)
        
        # Insert data into treeview
        today = datetime.now().date()
        
        for invoice in receivables:
            # Calculate days overdue
            due_date = datetime.strptime(invoice['due_date'], '%Y-%m-%d').date()
            days_overdue = (today - due_date).days if today > due_date else 0
            
            # Format dates
            formatted_date = datetime.strptime(invoice['date'], '%Y-%m-%d').strftime('%m/%d/%Y')
            formatted_due_date = datetime.strptime(invoice['due_date'], '%Y-%m-%d').strftime('%m/%d/%Y')
            
            # Format amount
            amount = f"${invoice['total']:,.2f}"
            
            # Determine aging columns
            current = f"${invoice['total']:,.2f}" if days_overdue <= 0 else "$0.00"
            days_1_30 = f"${invoice['total']:,.2f}" if 1 <= days_overdue <= 30 else "$0.00"
            days_31_60 = f"${invoice['total']:,.2f}" if 31 <= days_overdue <= 60 else "$0.00"
            days_61_plus = f"${invoice['total']:,.2f}" if days_overdue > 60 else "$0.00"
            
            # Add row to treeview
            row_values = (
                invoice['invoice_number'],
                invoice['customer_name'],
                formatted_date,
                formatted_due_date,
                amount,
                current,
                days_1_30,
                days_31_60,
                days_61_plus
            )
            
            # Use tags for overdue invoices
            if days_overdue > 0:
                tag = 'overdue_30' if days_overdue <= 30 else 'overdue_60' if days_overdue <= 60 else 'overdue_90'
                self.aging_tree.insert('', tk.END, values=row_values, tags=(tag,))
            else:
                self.aging_tree.insert('', tk.END, values=row_values)
        
        # Configure tags for overdue invoices
        self.aging_tree.tag_configure('overdue_30', background='#FFECB3')
        self.aging_tree.tag_configure('overdue_60', background='#FFCC80')
        self.aging_tree.tag_configure('overdue_90', background='#FFAB91')
    
    def record_payment(self):
        """Open form to record a payment"""
        PaymentForm(self, self.controller)
    
    def record_payment_for_selected(self):
        """Record payment for the selected invoice"""
        selected_id = self.aging_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an invoice to record payment")
            return
        
        # Get the invoice number from the selected row
        invoice_number = self.aging_tree.item(selected_id)['values'][0]
        
        # Get the complete invoice data
        receivables = self.db.get_accounts_receivable()
        selected_invoice = None
        
        for invoice in receivables:
            if invoice['invoice_number'] == invoice_number:
                selected_invoice = invoice
                break
        
        if selected_invoice:
            PaymentForm(self, self.controller, selected_invoice)
        else:
            messagebox.showerror("Error", "Could not find the selected invoice")
    
    def view_invoice(self):
        """View details of the selected invoice"""
        selected_id = self.aging_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an invoice to view")
            return
        
        # Get the invoice number from the selected row
        invoice_number = self.aging_tree.item(selected_id)['values'][0]
        
        # In a real app, this would open a detailed invoice view
        messagebox.showinfo("View Invoice", f"Viewing invoice {invoice_number}")
    
    def mark_as_paid(self):
        """Mark the selected invoice as paid"""
        selected_id = self.aging_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an invoice to mark as paid")
            return
        
        # Get the invoice number from the selected row
        invoice_number = self.aging_tree.item(selected_id)['values'][0]
        
        # Confirm action
        confirm = messagebox.askyesno(
            "Confirm", 
            f"Mark invoice {invoice_number} as paid without recording payment details?"
        )
        
        if confirm:
            # In a real app, this would update the invoice status
            messagebox.showinfo("Success", f"Invoice {invoice_number} marked as paid")
            self.refresh_data()
    
    def send_reminder(self):
        """Send payment reminder for the selected invoice"""
        selected_id = self.aging_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an invoice to send reminder")
            return
        
        # Get the invoice and customer from the selected row
        invoice_number = self.aging_tree.item(selected_id)['values'][0]
        customer_name = self.aging_tree.item(selected_id)['values'][1]
        
        # In a real app, this would send an email reminder
        messagebox.showinfo(
            "Send Reminder", 
            f"Payment reminder for invoice {invoice_number} sent to {customer_name}"
        )
    
    def create_invoice(self):
        """Open form to create a new sales invoice"""
        # In a real app, this would open the invoice creation form
        messagebox.showinfo("Create Invoice", "Opening sales invoice form...")
    
    def print_statements(self):
        """Print customer statements"""
        # In a real app, this would generate customer statements
        messagebox.showinfo("Print Statements", "Generating customer statements...")
    
    def show_context_menu(self, event):
        """Show context menu on right-click"""
        selected_id = self.aging_tree.identify_row(event.y)
        if selected_id:
            self.aging_tree.selection_set(selected_id)
            self.context_menu.post(event.x_root, event.y_root)