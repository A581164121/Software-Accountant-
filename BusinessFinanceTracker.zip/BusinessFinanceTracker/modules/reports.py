#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime, timedelta
import calendar

class ReportBaseFrame(ttk.Frame):
    """Base class for report frames with common functionality"""
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = controller.db
        
        # Period options for reports
        self.period_options = ["Month", "Quarter", "Year"]
        
        # Create common widgets
        self.create_main_container()
    
    def create_main_container(self):
        """Create the main container with scrollbar"""
        # Main container with scrollbar
        self.main_canvas = tk.Canvas(self, bg=self.controller.bg_color)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.main_canvas.yview)
        self.scrollable_frame = ttk.Frame(self.main_canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all")
            )
        )
        
        self.main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
    
    def create_header_section(self, title):
        """Create the header section with title and controls"""
        header_frame = ttk.Frame(self.scrollable_frame)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        # Title
        title_label = ttk.Label(
            header_frame, 
            text=title, 
            font=("Helvetica", 24, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        # Controls frame
        controls_frame = ttk.Frame(header_frame)
        controls_frame.pack(side=tk.RIGHT)
        
        # Period selection
        period_frame = ttk.Frame(controls_frame)
        period_frame.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(period_frame, text="Period:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.period_var = tk.StringVar(value=self.period_options[0])
        period_combo = ttk.Combobox(
            period_frame, 
            textvariable=self.period_var, 
            values=self.period_options,
            width=10,
            state="readonly"
        )
        period_combo.pack(side=tk.LEFT)
        period_combo.bind("<<ComboboxSelected>>", self.on_period_changed)
        
        # Date range selection
        date_frame = ttk.Frame(controls_frame)
        date_frame.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(date_frame, text="From:").pack(side=tk.LEFT, padx=(0, 5))
        
        # Default to first day of current month
        today = datetime.now()
        first_day = today.replace(day=1)
        
        self.start_date_var = tk.StringVar(value=first_day.strftime("%Y-%m-%d"))
        self.start_date_entry = ttk.Entry(date_frame, textvariable=self.start_date_var, width=10)
        self.start_date_entry.pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(date_frame, text="To:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.end_date_var = tk.StringVar(value=today.strftime("%Y-%m-%d"))
        self.end_date_entry = ttk.Entry(date_frame, textvariable=self.end_date_var, width=10)
        self.end_date_entry.pack(side=tk.LEFT)
        
        # Action buttons
        button_frame = ttk.Frame(controls_frame)
        button_frame.pack(side=tk.LEFT, padx=10)
        
        ttk.Button(
            button_frame,
            text="Refresh",
            style="Primary.TButton",
            command=self.refresh_report
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Export",
            command=self.export_report
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Print",
            command=self.print_report
        ).pack(side=tk.LEFT, padx=5)
    
    def on_period_changed(self, event):
        """Handle period change and update date range"""
        period = self.period_var.get()
        today = datetime.now()
        
        if period == "Month":
            # Current month
            first_day = today.replace(day=1)
            self.start_date_var.set(first_day.strftime("%Y-%m-%d"))
            self.end_date_var.set(today.strftime("%Y-%m-%d"))
        
        elif period == "Quarter":
            # Current quarter
            quarter = (today.month - 1) // 3 + 1
            first_month = (quarter - 1) * 3 + 1
            first_day = today.replace(month=first_month, day=1)
            self.start_date_var.set(first_day.strftime("%Y-%m-%d"))
            self.end_date_var.set(today.strftime("%Y-%m-%d"))
        
        elif period == "Year":
            # Current year
            first_day = today.replace(month=1, day=1)
            self.start_date_var.set(first_day.strftime("%Y-%m-%d"))
            self.end_date_var.set(today.strftime("%Y-%m-%d"))
        
        # Refresh the report with the new date range
        self.refresh_report()
    
    def refresh_report(self):
        """Refresh the report with current settings"""
        # This method should be implemented by subclasses
        pass
    
    def export_report(self):
        """Export the report to a file"""
        messagebox.showinfo("Export", "Exporting report to file...")
        # In a real app, this would export to CSV, Excel, or PDF
    
    def print_report(self):
        """Print the report"""
        messagebox.showinfo("Print", "Sending report to printer...")
        # In a real app, this would send to the printer


class BalanceSheetFrame(ReportBaseFrame):
    """Balance Sheet report frame"""
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        
        # Create balance sheet specific widgets
        self.create_header_section("Balance Sheet")
        self.create_balance_sheet_report()
    
    def create_balance_sheet_report(self):
        """Create the balance sheet report section"""
        # Report container
        report_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(20, 20))
        report_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Report header
        header_frame = ttk.Frame(report_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = ttk.Label(
            header_frame, 
            text="Balance Sheet", 
            font=("Helvetica", 18, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        self.as_of_label = ttk.Label(
            header_frame, 
            text=f"As of {datetime.now().strftime('%B %d, %Y')}",
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        self.as_of_label.pack(side=tk.RIGHT)
        
        # Create sections for Assets, Liabilities, and Equity
        self.create_assets_section(report_frame)
        self.create_liabilities_section(report_frame)
        self.create_equity_section(report_frame)
    
    def create_assets_section(self, parent):
        """Create the assets section of the balance sheet"""
        # Section header
        ttk.Label(
            parent, 
            text="Assets", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Assets container
        assets_frame = ttk.Frame(parent)
        assets_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Current Assets
        self.create_account_section(
            assets_frame, 
            "Current Assets", 
            [
                {"name": "Cash", "amount": 145629.78},
                {"name": "Accounts Receivable", "amount": 42580.00},
                {"name": "Inventory", "amount": 86450.00},
                {"name": "Prepaid Expenses", "amount": 12500.00}
            ],
            "Total Current Assets"
        )
        
        # Fixed Assets
        self.create_account_section(
            assets_frame, 
            "Fixed Assets", 
            [
                {"name": "Property & Equipment", "amount": 285000.00},
                {"name": "Less: Accumulated Depreciation", "amount": -78500.00}
            ],
            "Total Fixed Assets"
        )
        
        # Other Assets
        self.create_account_section(
            assets_frame, 
            "Other Assets", 
            [
                {"name": "Goodwill", "amount": 50000.00},
                {"name": "Deposits", "amount": 15000.00}
            ],
            "Total Other Assets"
        )
        
        # Total Assets
        ttk.Separator(assets_frame, orient='horizontal').pack(fill=tk.X, pady=10)
        
        total_frame = ttk.Frame(assets_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Assets", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        self.total_assets_label = ttk.Label(
            total_frame, 
            text="$558,659.78", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        self.total_assets_label.pack(side=tk.RIGHT)
    
    def create_liabilities_section(self, parent):
        """Create the liabilities section of the balance sheet"""
        # Section header
        ttk.Label(
            parent, 
            text="Liabilities", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Liabilities container
        liabilities_frame = ttk.Frame(parent)
        liabilities_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Current Liabilities
        self.create_account_section(
            liabilities_frame, 
            "Current Liabilities", 
            [
                {"name": "Accounts Payable", "amount": 28320.00},
                {"name": "Accrued Expenses", "amount": 18500.00},
                {"name": "Current Portion of Long-term Debt", "amount": 25000.00},
                {"name": "Taxes Payable", "amount": 12450.00}
            ],
            "Total Current Liabilities"
        )
        
        # Long-term Liabilities
        self.create_account_section(
            liabilities_frame, 
            "Long-term Liabilities", 
            [
                {"name": "Long-term Debt", "amount": 125000.00},
                {"name": "Deferred Tax Liabilities", "amount": 22500.00}
            ],
            "Total Long-term Liabilities"
        )
        
        # Total Liabilities
        ttk.Separator(liabilities_frame, orient='horizontal').pack(fill=tk.X, pady=10)
        
        total_frame = ttk.Frame(liabilities_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Liabilities", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        self.total_liabilities_label = ttk.Label(
            total_frame, 
            text="$231,770.00", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        self.total_liabilities_label.pack(side=tk.RIGHT)
    
    def create_equity_section(self, parent):
        """Create the equity section of the balance sheet"""
        # Section header
        ttk.Label(
            parent, 
            text="Equity", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Equity container
        equity_frame = ttk.Frame(parent)
        equity_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Equity accounts
        self.create_account_section(
            equity_frame, 
            "", 
            [
                {"name": "Common Stock", "amount": 200000.00},
                {"name": "Retained Earnings", "amount": 126889.78}
            ],
            "Total Equity"
        )
        
        # Total Liabilities and Equity
        ttk.Separator(equity_frame, orient='horizontal').pack(fill=tk.X, pady=10)
        
        total_frame = ttk.Frame(equity_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Liabilities and Equity", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        self.total_liab_equity_label = ttk.Label(
            total_frame, 
            text="$558,659.78", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        self.total_liab_equity_label.pack(side=tk.RIGHT)
    
    def create_account_section(self, parent, section_title, accounts, total_label):
        """Create a section of accounts with subtotal"""
        # Section container
        section_frame = ttk.Frame(parent)
        section_frame.pack(fill=tk.X, pady=(0, 10))
        
        # Section title
        if section_title:
            ttk.Label(
                section_frame, 
                text=section_title, 
                font=("Helvetica", 12),
                foreground=self.controller.text_color
            ).pack(fill=tk.X, anchor=tk.W, pady=(0, 5))
        
        # Accounts
        accounts_frame = ttk.Frame(section_frame)
        accounts_frame.pack(fill=tk.X, padx=20)
        
        total_amount = 0
        
        for account in accounts:
            account_frame = ttk.Frame(accounts_frame)
            account_frame.pack(fill=tk.X, pady=2)
            
            ttk.Label(
                account_frame, 
                text=account["name"],
                foreground=self.controller.text_color
            ).pack(side=tk.LEFT)
            
            amount = account["amount"]
            total_amount += amount
            
            ttk.Label(
                account_frame, 
                text=f"${amount:,.2f}",
                foreground=self.controller.text_color
            ).pack(side=tk.RIGHT)
        
        # Total
        ttk.Separator(section_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        total_frame = ttk.Frame(section_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text=total_label,
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            total_frame, 
            text=f"${total_amount:,.2f}",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        return total_amount
    
    def refresh_report(self):
        """Refresh the balance sheet report with current settings"""
        # In a real app, this would fetch the latest data from the database
        # For now, we'll just update the as of date
        as_of_date = self.end_date_var.get()
        formatted_date = datetime.strptime(as_of_date, "%Y-%m-%d").strftime("%B %d, %Y")
        self.as_of_label.config(text=f"As of {formatted_date}")
        
        # In a real app, we would also update all the account balances and totals


class CashFlowFrame(ReportBaseFrame):
    """Cash Flow report frame"""
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        
        # Create cash flow specific widgets
        self.create_header_section("Cash Flow Statement")
        self.create_cash_flow_report()
    
    def create_cash_flow_report(self):
        """Create the cash flow report section"""
        # Report container
        report_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(20, 20))
        report_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Report header
        header_frame = ttk.Frame(report_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = ttk.Label(
            header_frame, 
            text="Cash Flow Statement", 
            font=("Helvetica", 18, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        today = datetime.now()
        first_day = today.replace(day=1)
        
        self.period_label = ttk.Label(
            header_frame, 
            text=f"For the period {first_day.strftime('%B %d, %Y')} to {today.strftime('%B %d, %Y')}",
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        self.period_label.pack(side=tk.RIGHT)
        
        # Create chart
        self.create_cash_flow_chart(report_frame)
        
        # Create sections for Operating, Investing, and Financing activities
        self.create_operating_section(report_frame)
        self.create_investing_section(report_frame)
        self.create_financing_section(report_frame)
        self.create_summary_section(report_frame)
    
    def create_cash_flow_chart(self, parent):
        """Create a chart showing cash flow trends"""
        # Chart container
        chart_frame = ttk.Frame(parent)
        chart_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Sample data - would come from database in real app
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        cash_in = [58250, 62420, 59380, 65650, 69430, 78430]
        cash_out = [52450, 56780, 54240, 58850, 59600, 64215]
        net_flow = [5800, 5640, 5140, 6800, 9830, 14215]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(10, 4), dpi=100)
        
        # Plot data
        x = range(len(months))
        width = 0.3
        
        ax.bar([i - width for i in x], cash_in, width=width, label='Cash In', color=self.controller.secondary_color, alpha=0.7)
        ax.bar([i for i in x], cash_out, width=width, label='Cash Out', color=self.controller.accent_color, alpha=0.7)
        ax.bar([i + width for i in x], net_flow, width=width, label='Net Flow', color=self.controller.primary_color, alpha=0.7)
        
        # Add labels and legend
        ax.set_ylabel('Amount ($)')
        ax.set_xlabel('Month')
        ax.set_xticks(x)
        ax.set_xticklabels(months)
        ax.legend()
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_operating_section(self, parent):
        """Create the operating activities section"""
        # Section header
        ttk.Label(
            parent, 
            text="Cash Flow from Operating Activities", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Operating activities container
        operating_frame = ttk.Frame(parent)
        operating_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Cash receipts
        receipts_frame = ttk.Frame(operating_frame)
        receipts_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            receipts_frame, 
            text="Cash receipts from customers",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            receipts_frame, 
            text="$78,430.00",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Cash payments
        payments_frame = ttk.Frame(operating_frame)
        payments_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            payments_frame, 
            text="Cash payments to suppliers and employees",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            payments_frame, 
            text="($64,215.00)",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Net cash from operating activities
        ttk.Separator(operating_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        net_frame = ttk.Frame(operating_frame)
        net_frame.pack(fill=tk.X)
        
        ttk.Label(
            net_frame, 
            text="Net cash provided by operating activities",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_frame, 
            text="$14,215.00",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_investing_section(self, parent):
        """Create the investing activities section"""
        # Section header
        ttk.Label(
            parent, 
            text="Cash Flow from Investing Activities", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Investing activities container
        investing_frame = ttk.Frame(parent)
        investing_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Purchase of equipment
        purchase_frame = ttk.Frame(investing_frame)
        purchase_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            purchase_frame, 
            text="Purchase of property and equipment",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            purchase_frame, 
            text="($12,500.00)",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Net cash from investing activities
        ttk.Separator(investing_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        net_frame = ttk.Frame(investing_frame)
        net_frame.pack(fill=tk.X)
        
        ttk.Label(
            net_frame, 
            text="Net cash used in investing activities",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_frame, 
            text="($12,500.00)",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_financing_section(self, parent):
        """Create the financing activities section"""
        # Section header
        ttk.Label(
            parent, 
            text="Cash Flow from Financing Activities", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Financing activities container
        financing_frame = ttk.Frame(parent)
        financing_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Loan repayment
        loan_frame = ttk.Frame(financing_frame)
        loan_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            loan_frame, 
            text="Repayment of long-term debt",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            loan_frame, 
            text="($5,000.00)",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Net cash from financing activities
        ttk.Separator(financing_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        net_frame = ttk.Frame(financing_frame)
        net_frame.pack(fill=tk.X)
        
        ttk.Label(
            net_frame, 
            text="Net cash used in financing activities",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_frame, 
            text="($5,000.00)",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_summary_section(self, parent):
        """Create the summary section"""
        # Summary container
        summary_frame = ttk.Frame(parent)
        summary_frame.pack(fill=tk.X, pady=(20, 0))
        
        # Net increase in cash
        net_frame = ttk.Frame(summary_frame)
        net_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            net_frame, 
            text="Net increase in cash",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_frame, 
            text="$1,715.00",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Cash at beginning of period
        beginning_frame = ttk.Frame(summary_frame)
        beginning_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            beginning_frame, 
            text="Cash at beginning of period",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            beginning_frame, 
            text="$143,914.78",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Cash at end of period
        ttk.Separator(summary_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        end_frame = ttk.Frame(summary_frame)
        end_frame.pack(fill=tk.X)
        
        ttk.Label(
            end_frame, 
            text="Cash at end of period",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            end_frame, 
            text="$145,629.78",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def refresh_report(self):
        """Refresh the cash flow report with current settings"""
        # In a real app, this would fetch the latest data from the database
        # For now, we'll just update the period label
        start_date = self.start_date_var.get()
        end_date = self.end_date_var.get()
        
        formatted_start = datetime.strptime(start_date, "%Y-%m-%d").strftime("%B %d, %Y")
        formatted_end = datetime.strptime(end_date, "%Y-%m-%d").strftime("%B %d, %Y")
        
        self.period_label.config(text=f"For the period {formatted_start} to {formatted_end}")
        
        # In a real app, we would also update all the cash flow figures and the chart


class ProfitLossFrame(ReportBaseFrame):
    """Profit & Loss report frame"""
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        
        # Create profit & loss specific widgets
        self.create_header_section("Profit & Loss Statement")
        self.create_profit_loss_report()
    
    def create_profit_loss_report(self):
        """Create the profit & loss report section"""
        # Report container
        report_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(20, 20))
        report_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Report header
        header_frame = ttk.Frame(report_frame)
        header_frame.pack(fill=tk.X, pady=(0, 20))
        
        title_label = ttk.Label(
            header_frame, 
            text="Profit & Loss Statement", 
            font=("Helvetica", 18, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        today = datetime.now()
        first_day = today.replace(day=1)
        
        self.period_label = ttk.Label(
            header_frame, 
            text=f"For the period {first_day.strftime('%B %d, %Y')} to {today.strftime('%B %d, %Y')}",
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        self.period_label.pack(side=tk.RIGHT)
        
        # Create chart
        self.create_profit_loss_chart(report_frame)
        
        # Create sections for Revenue, Expenses, and Net Income
        self.create_revenue_section(report_frame)
        self.create_cost_of_sales_section(report_frame)
        self.create_gross_profit_section(report_frame)
        self.create_expenses_section(report_frame)
        self.create_operating_income_section(report_frame)
        self.create_other_income_expense_section(report_frame)
        self.create_net_income_section(report_frame)
    
    def create_profit_loss_chart(self, parent):
        """Create a chart showing profit & loss trends"""
        # Chart container
        chart_frame = ttk.Frame(parent)
        chart_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Sample data - would come from database in real app
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        revenue = [108250, 116420, 112380, 118650, 122430, 128430]
        expenses = [92450, 96780, 99240, 100850, 97600, 104215]
        profit = [15800, 19640, 13140, 17800, 24830, 24215]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(10, 4), dpi=100)
        
        # Plot data
        ax.bar(months, revenue, label='Revenue', alpha=0.7, color=self.controller.primary_color)
        ax.bar(months, expenses, label='Expenses', alpha=0.7, color=self.controller.accent_color)
        ax.plot(months, profit, label='Profit', marker='o', color=self.controller.secondary_color, linewidth=2)
        
        # Add labels and legend
        ax.set_ylabel('Amount ($)')
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        ax.legend()
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_revenue_section(self, parent):
        """Create the revenue section"""
        # Section header
        ttk.Label(
            parent, 
            text="Revenue", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Revenue container
        revenue_frame = ttk.Frame(parent)
        revenue_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Revenue items
        self.create_line_item(revenue_frame, "Sales Revenue", 120540.00)
        self.create_line_item(revenue_frame, "Service Revenue", 7890.00)
        self.create_line_item(revenue_frame, "Other Revenue", 0.00)
        
        # Total Revenue
        ttk.Separator(revenue_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        total_frame = ttk.Frame(revenue_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Revenue",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            total_frame, 
            text="$128,430.00",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_cost_of_sales_section(self, parent):
        """Create the cost of sales section"""
        # Section header
        ttk.Label(
            parent, 
            text="Cost of Sales", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Cost of Sales container
        cos_frame = ttk.Frame(parent)
        cos_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Cost of Sales items
        self.create_line_item(cos_frame, "Cost of Goods Sold", 68250.00)
        self.create_line_item(cos_frame, "Direct Labor", 7985.00)
        
        # Total Cost of Sales
        ttk.Separator(cos_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        total_frame = ttk.Frame(cos_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Cost of Sales",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            total_frame, 
            text="$76,235.00",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_gross_profit_section(self, parent):
        """Create the gross profit section"""
        # Gross Profit container
        gross_frame = ttk.Frame(parent)
        gross_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Gross Profit
        ttk.Separator(gross_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        gross_label_frame = ttk.Frame(gross_frame)
        gross_label_frame.pack(fill=tk.X)
        
        ttk.Label(
            gross_label_frame, 
            text="Gross Profit",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            gross_label_frame, 
            text="$52,195.00",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Gross Margin
        margin_frame = ttk.Frame(gross_frame)
        margin_frame.pack(fill=tk.X)
        
        ttk.Label(
            margin_frame, 
            text="Gross Margin",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            margin_frame, 
            text="40.6%",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_expenses_section(self, parent):
        """Create the operating expenses section"""
        # Section header
        ttk.Label(
            parent, 
            text="Operating Expenses", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Expenses container
        expenses_frame = ttk.Frame(parent)
        expenses_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Expense items
        self.create_line_item(expenses_frame, "Salaries and Wages", 14850.00)
        self.create_line_item(expenses_frame, "Rent", 3500.00)
        self.create_line_item(expenses_frame, "Utilities", 980.00)
        self.create_line_item(expenses_frame, "Office Supplies", 650.00)
        self.create_line_item(expenses_frame, "Marketing", 2500.00)
        self.create_line_item(expenses_frame, "Insurance", 1200.00)
        self.create_line_item(expenses_frame, "Depreciation", 1850.00)
        self.create_line_item(expenses_frame, "Other Expenses", 450.00)
        
        # Total Expenses
        ttk.Separator(expenses_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        total_frame = ttk.Frame(expenses_frame)
        total_frame.pack(fill=tk.X)
        
        ttk.Label(
            total_frame, 
            text="Total Operating Expenses",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            total_frame, 
            text="$25,980.00",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_operating_income_section(self, parent):
        """Create the operating income section"""
        # Operating Income container
        income_frame = ttk.Frame(parent)
        income_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Operating Income
        ttk.Separator(income_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        income_label_frame = ttk.Frame(income_frame)
        income_label_frame.pack(fill=tk.X)
        
        ttk.Label(
            income_label_frame, 
            text="Operating Income",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            income_label_frame, 
            text="$26,215.00",
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Operating Margin
        margin_frame = ttk.Frame(income_frame)
        margin_frame.pack(fill=tk.X)
        
        ttk.Label(
            margin_frame, 
            text="Operating Margin",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            margin_frame, 
            text="20.4%",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_other_income_expense_section(self, parent):
        """Create the other income/expense section"""
        # Section header
        ttk.Label(
            parent, 
            text="Other Income and Expenses", 
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(fill=tk.X, pady=(0, 10), anchor=tk.W)
        
        # Other Income/Expense container
        other_frame = ttk.Frame(parent)
        other_frame.pack(fill=tk.X, pady=(0, 20))
        
        # Other Income items
        self.create_line_item(other_frame, "Interest Income", 0.00)
        
        # Other Income Total
        other_income_frame = ttk.Frame(other_frame)
        other_income_frame.pack(fill=tk.X)
        
        ttk.Label(
            other_income_frame, 
            text="Total Other Income",
            font=("Helvetica", 10),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            other_income_frame, 
            text="$0.00",
            font=("Helvetica", 10),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Other Expense items
        self.create_line_item(other_frame, "Interest Expense", 2000.00)
        
        # Other Expense Total
        other_expense_frame = ttk.Frame(other_frame)
        other_expense_frame.pack(fill=tk.X)
        
        ttk.Label(
            other_expense_frame, 
            text="Total Other Expenses",
            font=("Helvetica", 10),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            other_expense_frame, 
            text="$2,000.00",
            font=("Helvetica", 10),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Net Other Income/Expense
        ttk.Separator(other_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        net_frame = ttk.Frame(other_frame)
        net_frame.pack(fill=tk.X)
        
        ttk.Label(
            net_frame, 
            text="Net Other Income/Expense",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_frame, 
            text="($2,000.00)",
            font=("Helvetica", 10, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_net_income_section(self, parent):
        """Create the net income section"""
        # Net Income container
        net_frame = ttk.Frame(parent)
        net_frame.pack(fill=tk.X, pady=(0, 0))
        
        # Income Before Tax
        income_before_tax_frame = ttk.Frame(net_frame)
        income_before_tax_frame.pack(fill=tk.X)
        
        ttk.Label(
            income_before_tax_frame, 
            text="Net Income Before Tax",
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            income_before_tax_frame, 
            text="$24,215.00",
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Income Tax
        self.create_line_item(net_frame, "Income Tax (35%)", 10000.00)
        
        # Net Income
        ttk.Separator(net_frame, orient='horizontal').pack(fill=tk.X, pady=5)
        
        net_income_frame = ttk.Frame(net_frame)
        net_income_frame.pack(fill=tk.X)
        
        ttk.Label(
            net_income_frame, 
            text="Net Income",
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            net_income_frame, 
            text="$14,215.00",
            font=("Helvetica", 14, "bold"),
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
        
        # Net Margin
        margin_frame = ttk.Frame(net_frame)
        margin_frame.pack(fill=tk.X)
        
        ttk.Label(
            margin_frame, 
            text="Net Profit Margin",
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            margin_frame, 
            text="11.1%",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def create_line_item(self, parent, label, amount):
        """Create a single line item in the report"""
        line_frame = ttk.Frame(parent)
        line_frame.pack(fill=tk.X, pady=2)
        
        ttk.Label(
            line_frame, 
            text=label,
            foreground=self.controller.text_color
        ).pack(side=tk.LEFT)
        
        ttk.Label(
            line_frame, 
            text=f"${amount:,.2f}",
            foreground=self.controller.text_color
        ).pack(side=tk.RIGHT)
    
    def refresh_report(self):
        """Refresh the profit & loss report with current settings"""
        # In a real app, this would fetch the latest data from the database
        # For now, we'll just update the period label
        start_date = self.start_date_var.get()
        end_date = self.end_date_var.get()
        
        formatted_start = datetime.strptime(start_date, "%Y-%m-%d").strftime("%B %d, %Y")
        formatted_end = datetime.strptime(end_date, "%Y-%m-%d").strftime("%B %d, %Y")
        
        self.period_label.config(text=f"For the period {formatted_start} to {formatted_end}")
        
        # In a real app, we would also update all the figures and the chart