#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, simpledialog, messagebox
from tkinter import font as tkfont
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime

class InventoryForm(tk.Toplevel):
    """Form for adding or editing inventory items"""
    def __init__(self, parent, controller, item=None):
        super().__init__(parent)
        self.parent = parent
        self.controller = controller
        self.db = controller.db
        self.item = item  # If item is provided, we're editing; otherwise, adding new
        
        # Window setup
        self.title("Add Inventory Item" if not item else "Edit Inventory Item")
        self.geometry("500x600")
        self.resizable(False, False)
        self.configure(background=controller.bg_color)
        
        # Make it a modal dialog
        self.transient(parent)
        self.grab_set()
        
        # Create form widgets
        self.create_widgets()
        
        # If editing, populate fields
        if self.item:
            self.populate_fields()
        
        # Center the window
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')
    
    def create_widgets(self):
        """Create form widgets"""
        # Main frame
        main_frame = ttk.Frame(self, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title
        title_label = ttk.Label(
            main_frame, 
            text="Inventory Item Details", 
            font=("Helvetica", 16, "bold")
        )
        title_label.grid(row=0, column=0, columnspan=2, sticky=tk.W, pady=(0, 20))
        
        # Form fields
        # Item Code
        ttk.Label(main_frame, text="Item Code:").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.code_var = tk.StringVar()
        self.code_entry = ttk.Entry(main_frame, textvariable=self.code_var, width=30)
        self.code_entry.grid(row=1, column=1, sticky=tk.W, pady=5)
        
        # Item Name
        ttk.Label(main_frame, text="Item Name:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(main_frame, textvariable=self.name_var, width=30)
        self.name_entry.grid(row=2, column=1, sticky=tk.W, pady=5)
        
        # Description
        ttk.Label(main_frame, text="Description:").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.desc_text = tk.Text(main_frame, width=30, height=4)
        self.desc_text.grid(row=3, column=1, sticky=tk.W, pady=5)
        
        # Unit Price
        ttk.Label(main_frame, text="Unit Price ($):").grid(row=4, column=0, sticky=tk.W, pady=5)
        self.price_var = tk.DoubleVar()
        self.price_entry = ttk.Entry(main_frame, textvariable=self.price_var, width=30)
        self.price_entry.grid(row=4, column=1, sticky=tk.W, pady=5)
        
        # Cost Price
        ttk.Label(main_frame, text="Cost Price ($):").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.cost_var = tk.DoubleVar()
        self.cost_entry = ttk.Entry(main_frame, textvariable=self.cost_var, width=30)
        self.cost_entry.grid(row=5, column=1, sticky=tk.W, pady=5)
        
        # Quantity on Hand
        ttk.Label(main_frame, text="Quantity on Hand:").grid(row=6, column=0, sticky=tk.W, pady=5)
        self.qty_var = tk.IntVar()
        self.qty_entry = ttk.Entry(main_frame, textvariable=self.qty_var, width=30)
        self.qty_entry.grid(row=6, column=1, sticky=tk.W, pady=5)
        
        # Reorder Level
        ttk.Label(main_frame, text="Reorder Level:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.reorder_var = tk.IntVar()
        self.reorder_entry = ttk.Entry(main_frame, textvariable=self.reorder_var, width=30)
        self.reorder_entry.grid(row=7, column=1, sticky=tk.W, pady=5)
        
        # Separator
        ttk.Separator(main_frame, orient='horizontal').grid(
            row=8, column=0, columnspan=2, sticky=tk.EW, pady=20)
        
        # Buttons
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=9, column=0, columnspan=2, sticky=tk.EW)
        
        ttk.Button(button_frame, text="Cancel", command=self.destroy).pack(side=tk.RIGHT, padx=5)
        ttk.Button(
            button_frame, 
            text="Save", 
            style="Primary.TButton", 
            command=self.save_item
        ).pack(side=tk.RIGHT, padx=5)
    
    def populate_fields(self):
        """Populate form fields with item data"""
        self.code_var.set(self.item.get('code', ''))
        self.name_var.set(self.item.get('name', ''))
        self.desc_text.insert('1.0', self.item.get('description', ''))
        self.price_var.set(self.item.get('unit_price', 0.0))
        self.cost_var.set(self.item.get('cost_price', 0.0))
        self.qty_var.set(self.item.get('quantity_on_hand', 0))
        self.reorder_var.set(self.item.get('reorder_level', 0))
        
        # Disable code field when editing
        if self.item:
            self.code_entry.configure(state='disabled')
    
    def validate_form(self):
        """Validate form fields"""
        errors = []
        
        if not self.code_var.get().strip():
            errors.append("Item Code is required")
        
        if not self.name_var.get().strip():
            errors.append("Item Name is required")
        
        try:
            price = float(self.price_var.get())
            if price <= 0:
                errors.append("Unit Price must be greater than 0")
        except:
            errors.append("Unit Price must be a valid number")
        
        try:
            cost = float(self.cost_var.get())
            if cost < 0:
                errors.append("Cost Price must be greater than or equal to 0")
        except:
            errors.append("Cost Price must be a valid number")
        
        try:
            qty = int(self.qty_var.get())
            if qty < 0:
                errors.append("Quantity on Hand must be greater than or equal to 0")
        except:
            errors.append("Quantity on Hand must be a valid integer")
        
        try:
            reorder = int(self.reorder_var.get())
            if reorder < 0:
                errors.append("Reorder Level must be greater than or equal to 0")
        except:
            errors.append("Reorder Level must be a valid integer")
        
        if errors:
            messagebox.showerror("Validation Error", "\n".join(errors))
            return False
        
        return True
    
    def save_item(self):
        """Save the inventory item"""
        if not self.validate_form():
            return
        
        try:
            item_data = {
                'code': self.code_var.get().strip(),
                'name': self.name_var.get().strip(),
                'description': self.desc_text.get('1.0', tk.END).strip(),
                'unit_price': float(self.price_var.get()),
                'cost_price': float(self.cost_var.get()),
                'quantity_on_hand': int(self.qty_var.get()),
                'reorder_level': int(self.reorder_var.get())
            }
            
            if self.item:  # Editing existing item
                self.db.update_inventory_item(self.item['id'], item_data)
                messagebox.showinfo("Success", "Inventory item updated successfully")
            else:  # Adding new item
                self.db.create_inventory_item(item_data)
                messagebox.showinfo("Success", "Inventory item added successfully")
            
            # Refresh parent and close the form
            if isinstance(self.parent, InventoryFrame):
                self.parent.refresh_data()
            self.destroy()
            
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")


class InventoryFrame(ttk.Frame):
    """Main inventory management frame"""
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = controller.db
        
        # Create inventory management UI
        self.create_widgets()
    
    def create_widgets(self):
        """Create all widgets for inventory management"""
        # Main container with scrollbar
        self.main_canvas = tk.Canvas(self, bg=self.controller.bg_color)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.main_canvas.yview)
        self.scrollable_frame = ttk.Frame(self.main_canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all")
            )
        )
        
        self.main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Header section with title and action buttons
        self.create_header_section()
        
        # Filters and search section
        self.create_filters_section()
        
        # Inventory table
        self.create_inventory_table()
        
        # Inventory stats section
        self.create_stats_section()
    
    def create_header_section(self):
        """Create the header section with title and buttons"""
        header_frame = ttk.Frame(self.scrollable_frame)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        # Title
        title_label = ttk.Label(
            header_frame, 
            text="Inventory Management", 
            font=("Helvetica", 24, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(side=tk.LEFT)
        
        # Action buttons
        button_frame = ttk.Frame(header_frame)
        button_frame.pack(side=tk.RIGHT)
        
        ttk.Button(
            button_frame,
            text="Add New Item",
            style="Primary.TButton",
            command=self.open_add_form
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Print Inventory List",
            style="Success.TButton",
            command=self.print_inventory
        ).pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            button_frame,
            text="Export to CSV",
            command=self.export_to_csv
        ).pack(side=tk.LEFT, padx=5)
    
    def create_filters_section(self):
        """Create filters and search section"""
        filters_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=10)
        filters_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Search
        search_frame = ttk.Frame(filters_frame)
        search_frame.pack(side=tk.LEFT, padx=10)
        
        ttk.Label(search_frame, text="Search:").pack(side=tk.LEFT, padx=(0, 5))
        
        self.search_var = tk.StringVar()
        search_entry = ttk.Entry(search_frame, textvariable=self.search_var, width=25)
        search_entry.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(
            search_frame,
            text="Search",
            command=self.search_inventory
        ).pack(side=tk.LEFT, padx=5)
        
        # Filters
        filter_frame = ttk.Frame(filters_frame)
        filter_frame.pack(side=tk.RIGHT, padx=10)
        
        # Filter by low stock
        self.low_stock_var = tk.BooleanVar()
        ttk.Checkbutton(
            filter_frame,
            text="Show Low Stock Items Only",
            variable=self.low_stock_var,
            command=self.filter_inventory
        ).pack(side=tk.LEFT, padx=10)
    
    def create_inventory_table(self):
        """Create the inventory data table"""
        # Table container
        table_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(0, 0))
        table_frame.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
        
        # Create treeview
        columns = ('code', 'name', 'unit_price', 'cost_price', 'quantity', 'reorder', 'value')
        self.inventory_tree = ttk.Treeview(table_frame, columns=columns, show='headings', height=15)
        
        # Define column headings
        self.inventory_tree.heading('code', text='Item Code')
        self.inventory_tree.heading('name', text='Item Name')
        self.inventory_tree.heading('unit_price', text='Unit Price')
        self.inventory_tree.heading('cost_price', text='Cost Price')
        self.inventory_tree.heading('quantity', text='Quantity')
        self.inventory_tree.heading('reorder', text='Reorder Level')
        self.inventory_tree.heading('value', text='Total Value')
        
        # Define column widths and alignment
        self.inventory_tree.column('code', width=100, anchor='w')
        self.inventory_tree.column('name', width=250, anchor='w')
        self.inventory_tree.column('unit_price', width=100, anchor='e')
        self.inventory_tree.column('cost_price', width=100, anchor='e')
        self.inventory_tree.column('quantity', width=80, anchor='center')
        self.inventory_tree.column('reorder', width=100, anchor='center')
        self.inventory_tree.column('value', width=120, anchor='e')
        
        # Add scrollbars
        y_scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.inventory_tree.yview)
        self.inventory_tree.configure(yscroll=y_scrollbar.set)
        
        x_scrollbar = ttk.Scrollbar(table_frame, orient=tk.HORIZONTAL, command=self.inventory_tree.xview)
        self.inventory_tree.configure(xscroll=x_scrollbar.set)
        
        # Pack widgets
        self.inventory_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        y_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        x_scrollbar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Add right-click context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Edit Item", command=self.edit_selected_item)
        self.context_menu.add_command(label="Delete Item", command=self.delete_selected_item)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="View Details", command=self.view_item_details)
        
        self.inventory_tree.bind("<Button-3>", self.show_context_menu)
        self.inventory_tree.bind("<Double-1>", lambda e: self.edit_selected_item())
    
    def create_stats_section(self):
        """Create inventory statistics section"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Inventory Statistics", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # Stats container
        stats_frame = ttk.Frame(self.scrollable_frame)
        stats_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Configure grid
        stats_frame.columnconfigure(0, weight=2)  # Value charts
        stats_frame.columnconfigure(1, weight=1)  # Stock level donut
        
        # Create inventory value chart
        self.create_value_chart(stats_frame)
        
        # Create stock level chart
        self.create_stock_level_chart(stats_frame)
    
    def create_value_chart(self, parent):
        """Create inventory value chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Top Items by Inventory Value", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data - would come from database in real app
        items = ['Desktop Computer', 'Business Laptop', '24-inch Monitor', 'Keyboard', 'Mouse']
        values = [13500, 16500, 5400, 1200, 475]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(8, 4), dpi=100)
        
        # Plot data - horizontal bar chart
        bars = ax.barh(items, values, color=self.controller.primary_color, alpha=0.7)
        
        # Add labels
        ax.set_xlabel('Inventory Value ($)')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        
        # Add value labels
        for bar in bars:
            width = bar.get_width()
            ax.text(width + 200, bar.get_y() + bar.get_height()/2, 
                    f'${width:,.0f}', ha='left', va='center')
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_stock_level_chart(self, parent):
        """Create stock level donut chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Inventory Status", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data - would come from database in real app
        labels = ['Sufficient Stock', 'Low Stock', 'Out of Stock']
        sizes = [70, 25, 5]
        colors = [self.controller.secondary_color, '#FFC107', self.controller.accent_color]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(4, 4), dpi=100)
        
        # Plot data - donut chart
        wedges, texts, autotexts = ax.pie(
            sizes, 
            labels=None, 
            autopct='%1.1f%%',
            startangle=90,
            colors=colors,
            wedgeprops=dict(width=0.5)  # Make it a donut
        )
        
        # Customize text
        for autotext in autotexts:
            autotext.set_color('white')
            autotext.set_fontsize(9)
        
        # Add legend
        ax.legend(wedges, labels, loc="center", bbox_to_anchor=(0.5, 0), fontsize=9)
        
        # Equal aspect ratio ensures that pie is drawn as a circle
        ax.set_aspect('equal')
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def refresh_data(self):
        """Refresh inventory data from the database"""
        # Get inventory data
        inventory_items = self.db.get_all_inventory_items()
        
        # Clear existing items
        for item in self.inventory_tree.get_children():
            self.inventory_tree.delete(item)
        
        # Insert data into treeview
        for item in inventory_items:
            total_value = item['quantity_on_hand'] * item['cost_price']
            
            # Format monetary values
            unit_price = f"${item['unit_price']:,.2f}"
            cost_price = f"${item['cost_price']:,.2f}"
            value = f"${total_value:,.2f}"
            
            # Add row to treeview
            row_values = (
                item['code'],
                item['name'],
                unit_price,
                cost_price,
                item['quantity_on_hand'],
                item['reorder_level'],
                value
            )
            
            # Use tags for low stock items
            if item['quantity_on_hand'] <= item['reorder_level']:
                self.inventory_tree.insert('', tk.END, values=row_values, tags=('low_stock',))
            else:
                self.inventory_tree.insert('', tk.END, values=row_values)
        
        # Configure tag for low stock items
        self.inventory_tree.tag_configure('low_stock', background='#FFECB3')
    
    def search_inventory(self):
        """Search inventory based on search term"""
        search_term = self.search_var.get().lower()
        
        # Get all inventory items
        inventory_items = self.db.get_all_inventory_items()
        
        # Clear existing items
        for item in self.inventory_tree.get_children():
            self.inventory_tree.delete(item)
        
        # Filter and insert matching items
        for item in inventory_items:
            # Check if search term matches any field
            if (search_term in item['code'].lower() or 
                search_term in item['name'].lower() or 
                (item['description'] and search_term in item['description'].lower())):
                
                total_value = item['quantity_on_hand'] * item['cost_price']
                
                # Format monetary values
                unit_price = f"${item['unit_price']:,.2f}"
                cost_price = f"${item['cost_price']:,.2f}"
                value = f"${total_value:,.2f}"
                
                # Add row to treeview
                row_values = (
                    item['code'],
                    item['name'],
                    unit_price,
                    cost_price,
                    item['quantity_on_hand'],
                    item['reorder_level'],
                    value
                )
                
                # Use tags for low stock items
                if item['quantity_on_hand'] <= item['reorder_level']:
                    self.inventory_tree.insert('', tk.END, values=row_values, tags=('low_stock',))
                else:
                    self.inventory_tree.insert('', tk.END, values=row_values)
    
    def filter_inventory(self):
        """Filter inventory based on selected filters"""
        show_low_stock = self.low_stock_var.get()
        
        # Get all inventory items
        inventory_items = self.db.get_all_inventory_items()
        
        # Clear existing items
        for item in self.inventory_tree.get_children():
            self.inventory_tree.delete(item)
        
        # Filter and insert matching items
        for item in inventory_items:
            # Apply low stock filter
            if show_low_stock and item['quantity_on_hand'] > item['reorder_level']:
                continue
                
            total_value = item['quantity_on_hand'] * item['cost_price']
            
            # Format monetary values
            unit_price = f"${item['unit_price']:,.2f}"
            cost_price = f"${item['cost_price']:,.2f}"
            value = f"${total_value:,.2f}"
            
            # Add row to treeview
            row_values = (
                item['code'],
                item['name'],
                unit_price,
                cost_price,
                item['quantity_on_hand'],
                item['reorder_level'],
                value
            )
            
            # Use tags for low stock items
            if item['quantity_on_hand'] <= item['reorder_level']:
                self.inventory_tree.insert('', tk.END, values=row_values, tags=('low_stock',))
            else:
                self.inventory_tree.insert('', tk.END, values=row_values)
    
    def open_add_form(self):
        """Open form to add a new inventory item"""
        InventoryForm(self, self.controller)
    
    def edit_selected_item(self):
        """Open form to edit the selected inventory item"""
        selected_id = self.inventory_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an item to edit")
            return
        
        # Get the item code from the selected row
        item_code = self.inventory_tree.item(selected_id)['values'][0]
        
        # Get the complete item data from the database
        inventory_items = self.db.get_all_inventory_items()
        selected_item = None
        
        for item in inventory_items:
            if item['code'] == item_code:
                selected_item = item
                break
        
        if selected_item:
            InventoryForm(self, self.controller, selected_item)
        else:
            messagebox.showerror("Error", "Could not find the selected item")
    
    def delete_selected_item(self):
        """Delete the selected inventory item"""
        selected_id = self.inventory_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an item to delete")
            return
        
        # Get the item code from the selected row
        item_code = self.inventory_tree.item(selected_id)['values'][0]
        
        # Get the complete item data from the database
        inventory_items = self.db.get_all_inventory_items()
        selected_item = None
        
        for item in inventory_items:
            if item['code'] == item_code:
                selected_item = item
                break
        
        if selected_item:
            # Confirm deletion
            confirm = messagebox.askyesno(
                "Confirm Delete",
                f"Are you sure you want to delete {selected_item['name']}?\nThis action cannot be undone."
            )
            
            if confirm:
                try:
                    self.db.delete_inventory_item(selected_item['id'])
                    messagebox.showinfo("Success", "Inventory item deleted successfully")
                    self.refresh_data()
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to delete item: {str(e)}")
        else:
            messagebox.showerror("Error", "Could not find the selected item")
    
    def view_item_details(self):
        """View detailed information about the selected item"""
        selected_id = self.inventory_tree.focus()
        if not selected_id:
            messagebox.showinfo("Info", "Please select an item to view")
            return
        
        # Get the item code from the selected row
        item_code = self.inventory_tree.item(selected_id)['values'][0]
        
        # Get the complete item data from the database
        inventory_items = self.db.get_all_inventory_items()
        selected_item = None
        
        for item in inventory_items:
            if item['code'] == item_code:
                selected_item = item
                break
        
        if selected_item:
            # Format the details
            details = (
                f"Item Code: {selected_item['code']}\n"
                f"Name: {selected_item['name']}\n"
                f"Description: {selected_item['description'] or 'N/A'}\n\n"
                f"Unit Price: ${selected_item['unit_price']:,.2f}\n"
                f"Cost Price: ${selected_item['cost_price']:,.2f}\n"
                f"Markup: {((selected_item['unit_price'] / selected_item['cost_price']) - 1) * 100:.1f}%\n\n"
                f"Quantity on Hand: {selected_item['quantity_on_hand']}\n"
                f"Reorder Level: {selected_item['reorder_level']}\n"
                f"Total Value: ${selected_item['quantity_on_hand'] * selected_item['cost_price']:,.2f}"
            )
            
            # Show details in a dialog
            messagebox.showinfo(f"Item Details: {selected_item['name']}", details)
        else:
            messagebox.showerror("Error", "Could not find the selected item")
    
    def show_context_menu(self, event):
        """Show context menu on right-click"""
        selected_id = self.inventory_tree.identify_row(event.y)
        if selected_id:
            self.inventory_tree.selection_set(selected_id)
            self.context_menu.post(event.x_root, event.y_root)
    
    def print_inventory(self):
        """Print the inventory list"""
        messagebox.showinfo("Print", "Sending inventory list to printer...")
        # In a real app, this would generate a printable report
        
    def export_to_csv(self):
        """Export inventory data to CSV"""
        messagebox.showinfo("Export", "Exporting inventory data to CSV file...")
        # In a real app, this would generate a CSV file