#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from datetime import datetime

class DashboardFrame(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.db = controller.db
        
        # Create dashboard content
        self.create_widgets()
    
    def create_widgets(self):
        """Create all widgets for the dashboard"""
        # Main container with scrollbar
        self.main_canvas = tk.Canvas(self, bg=self.controller.bg_color)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.main_canvas.yview)
        self.scrollable_frame = ttk.Frame(self.main_canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.main_canvas.configure(
                scrollregion=self.main_canvas.bbox("all")
            )
        )
        
        self.main_canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=self.scrollbar.set)
        
        self.main_canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
        
        # Dashboard header
        header_frame = ttk.Frame(self.scrollable_frame)
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        header_label = ttk.Label(
            header_frame, 
            text="Dashboard", 
            font=("Helvetica", 24, "bold"),
            foreground=self.controller.text_color
        )
        header_label.pack(side=tk.LEFT)
        
        date_label = ttk.Label(
            header_frame, 
            text=f"Today: {datetime.now().strftime('%B %d, %Y')}", 
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        date_label.pack(side=tk.RIGHT, padx=10, pady=10)
        
        # Financial KPIs section
        self.create_kpi_section()
        
        # Charts section
        self.create_charts_section()
        
        # Recent transactions section
        self.create_transactions_section()
    
    def create_kpi_section(self):
        """Create the KPI cards section"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Financial Overview", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # KPI cards container
        kpi_frame = ttk.Frame(self.scrollable_frame)
        kpi_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Configure grid
        kpi_frame.columnconfigure(0, weight=1)
        kpi_frame.columnconfigure(1, weight=1)
        kpi_frame.columnconfigure(2, weight=1)
        kpi_frame.columnconfigure(3, weight=1)
        
        # Create KPI cards
        self.create_kpi_card(kpi_frame, "Revenue", "$128,430", "+5.2%", row=0, column=0, color=self.controller.primary_color)
        self.create_kpi_card(kpi_frame, "Expenses", "$94,215", "+2.8%", row=0, column=1, color="#D32F2F")
        self.create_kpi_card(kpi_frame, "Net Income", "$34,215", "+12.4%", row=0, column=2, color=self.controller.secondary_color)
        self.create_kpi_card(kpi_frame, "Cash Balance", "$175,630", "+0.9%", row=0, column=3, color="#FF9800")
        
        self.create_kpi_card(kpi_frame, "Receivables", "$42,580", "-3.1%", row=1, column=0, color="#5C6BC0")
        self.create_kpi_card(kpi_frame, "Payables", "$28,320", "-5.7%", row=1, column=1, color="#7E57C2")
        self.create_kpi_card(kpi_frame, "Inventory Value", "$86,450", "+2.3%", row=1, column=2, color="#26A69A")
        self.create_kpi_card(kpi_frame, "Low Stock Items", "3", "", row=1, column=3, color="#EF5350")
    
    def create_kpi_card(self, parent, title, value, change, row=0, column=0, color=None):
        """Create an individual KPI card"""
        # Card frame
        card = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        card.grid(row=row, column=column, padx=5, pady=5, sticky=tk.NSEW)
        
        # Title
        title_label = ttk.Label(
            card, 
            text=title, 
            font=("Helvetica", 12),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W)
        
        # Value
        value_label = ttk.Label(
            card, 
            text=value, 
            font=("Helvetica", 20, "bold"),
            foreground=self.controller.text_color
        )
        value_label.pack(anchor=tk.W, pady=(5, 0))
        
        # Change percentage
        if change:
            if change.startswith("+"):
                change_color = self.controller.secondary_color  # Green for positive
            else:
                change_color = self.controller.accent_color  # Red for negative
                
            change_label = ttk.Label(
                card, 
                text=change, 
                font=("Helvetica", 10),
                foreground=change_color
            )
            change_label.pack(anchor=tk.W)
    
    def create_charts_section(self):
        """Create the charts section"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Financial Performance", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # Charts container
        charts_frame = ttk.Frame(self.scrollable_frame)
        charts_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Configure grid
        charts_frame.columnconfigure(0, weight=2)  # Revenue chart is wider
        charts_frame.columnconfigure(1, weight=1)
        
        # Create Revenue Chart
        self.create_revenue_chart(charts_frame)
        
        # Create Top Customers Chart
        self.create_customers_chart(charts_frame)
    
    def create_revenue_chart(self, parent):
        """Create revenue trend chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=0, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Revenue, Expenses & Profit (Last 6 Months)", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data
        months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        revenue = [108250, 116420, 112380, 118650, 122430, 128430]
        expenses = [92450, 96780, 99240, 100850, 97600, 104215]
        profit = [15800, 19640, 13140, 17800, 24830, 24215]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(8, 4), dpi=100)
        
        # Plot data
        ax.bar(months, revenue, label='Revenue', alpha=0.7, color=self.controller.primary_color)
        ax.bar(months, expenses, label='Expenses', alpha=0.7, color=self.controller.accent_color)
        ax.plot(months, profit, label='Profit', marker='o', color=self.controller.secondary_color, linewidth=2)
        
        # Add labels and legend
        ax.set_ylabel('Amount ($)')
        ax.grid(axis='y', linestyle='--', alpha=0.7)
        ax.legend()
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_customers_chart(self, parent):
        """Create top customers chart"""
        # Chart frame
        chart_frame = ttk.Frame(parent, style="Card.TFrame", padding=(15, 15))
        chart_frame.grid(row=0, column=1, padx=5, pady=5, sticky=tk.NSEW)
        
        # Chart title
        title_label = ttk.Label(
            chart_frame, 
            text="Top Customers by Revenue", 
            font=("Helvetica", 12, "bold"),
            foreground=self.controller.text_color
        )
        title_label.pack(anchor=tk.W, pady=(0, 10))
        
        # Sample data
        customers = ['Acme Corp', 'Tech Inc', 'Global LLC', 'Metro SA', 'First Co']
        sales = [42580, 25430, 18750, 15320, 8950]
        
        # Create matplotlib figure
        fig, ax = plt.subplots(figsize=(4, 4), dpi=100)
        
        # Plot data - horizontal bar chart
        bars = ax.barh(customers, sales, color=self.controller.primary_color, alpha=0.7)
        
        # Add labels
        ax.set_xlabel('Revenue ($)')
        ax.grid(axis='x', linestyle='--', alpha=0.7)
        
        # Add value labels
        for bar in bars:
            width = bar.get_width()
            ax.text(width + 500, bar.get_y() + bar.get_height()/2, 
                    f'${width:,.0f}', ha='left', va='center')
        
        # Adjust layout
        plt.tight_layout()
        
        # Embed chart in tkinter
        canvas = FigureCanvasTkAgg(fig, master=chart_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
    
    def create_transactions_section(self):
        """Create recent transactions section"""
        # Section header
        section_label = ttk.Label(
            self.scrollable_frame, 
            text="Recent Transactions", 
            font=("Helvetica", 16, "bold"),
            foreground=self.controller.text_color
        )
        section_label.pack(fill=tk.X, padx=20, pady=(20, 10), anchor=tk.W)
        
        # Transactions container
        trans_frame = ttk.Frame(self.scrollable_frame, style="Card.TFrame", padding=(0, 0))
        trans_frame.pack(fill=tk.X, padx=20, pady=10)
        
        # Create treeview
        columns = ('date', 'reference', 'type', 'entity', 'amount', 'status')
        self.transactions_tree = ttk.Treeview(trans_frame, columns=columns, show='headings', height=8)
        
        # Define column headings
        self.transactions_tree.heading('date', text='Date')
        self.transactions_tree.heading('reference', text='Reference')
        self.transactions_tree.heading('type', text='Type')
        self.transactions_tree.heading('entity', text='Customer/Vendor')
        self.transactions_tree.heading('amount', text='Amount')
        self.transactions_tree.heading('status', text='Status')
        
        # Define column widths and alignment
        self.transactions_tree.column('date', width=100, anchor='w')
        self.transactions_tree.column('reference', width=150, anchor='w')
        self.transactions_tree.column('type', width=150, anchor='w')
        self.transactions_tree.column('entity', width=200, anchor='w')
        self.transactions_tree.column('amount', width=100, anchor='e')
        self.transactions_tree.column('status', width=100, anchor='center')
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(trans_frame, orient=tk.VERTICAL, command=self.transactions_tree.yview)
        self.transactions_tree.configure(yscroll=scrollbar.set)
        
        # Pack widgets
        self.transactions_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Add sample data
        self.load_sample_transactions()
    
    def load_sample_transactions(self):
        """Load sample transaction data into the treeview"""
        # Sample transaction data
        transactions = [
            ('2023-06-24', 'INV-202306001', 'Sales Invoice', 'Tech Supplies Inc.', '$2,156.00', 'Paid'),
            ('2023-06-20', 'INV-202306002', 'Sales Invoice', 'Acme Corporation', '$8,750.00', 'Pending'),
            ('2023-06-15', 'PMT-202306001', 'Payment Made', 'Office Supplies Co.', '$1,500.40', 'Complete'),
            ('2023-06-10', 'PO-202306001', 'Purchase Order', 'Office Supplies Co.', '$1,500.40', 'Paid'),
            ('2023-06-15', 'RCPT-202306001', 'Payment Received', 'Tech Supplies Inc.', '$2,156.00', 'Complete'),
            ('2023-06-30', 'JE-202306001', 'Journal Entry', 'N/A', '$3,500.00', 'Posted'),
        ]
        
        # Clear existing items
        for item in self.transactions_tree.get_children():
            self.transactions_tree.delete(item)
        
        # Insert new data
        for tx in transactions:
            self.transactions_tree.insert('', tk.END, values=tx)
    
    def refresh_data(self):
        """Refresh dashboard data from the database"""
        # In a real application, this would fetch the latest data
        # from the database and update all widgets
        pass