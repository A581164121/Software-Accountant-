import { 
  users, type User, type InsertUser,
  chartOfAccounts, type ChartOfAccount, type InsertChartOfAccount,
  customers, type Customer, type InsertCustomer,
  vendors, type Vendor, type InsertVendor,
  inventoryItems, type InventoryItem, type InsertInventoryItem,
  salesInvoices, type SalesInvoice, type InsertSalesInvoice,
  salesInvoiceItems, type SalesInvoiceItem, type InsertSalesInvoiceItem,
  purchaseInvoices, type PurchaseInvoice, type InsertPurchaseInvoice,
  purchaseInvoiceItems, type PurchaseInvoiceItem, type InsertPurchaseInvoiceItem,
  journalEntries, type JournalEntry, type InsertJournalEntry,
  journalEntryLines, type JournalEntryLine, type InsertJournalEntryLine,
  paymentsReceived, type PaymentReceived, type InsertPaymentReceived,
  paymentsMade, type PaymentMade, type InsertPaymentMade,
  bankAccounts, type BankAccount, type InsertBankAccount,
  bankTransactions, type BankTransaction, type InsertBankTransaction
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Customer methods
  getAllCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;

  // Vendor methods
  getAllVendors(): Promise<Vendor[]>;
  getVendor(id: number): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;

  // Inventory methods
  getAllInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, item: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<boolean>;

  // Sales methods
  getAllSalesInvoices(): Promise<SalesInvoice[]>;
  getSalesInvoice(id: number): Promise<SalesInvoice | undefined>;
  createSalesInvoice(invoice: InsertSalesInvoice, items: any[]): Promise<SalesInvoice>;

  // Purchase methods
  getAllPurchaseInvoices(): Promise<PurchaseInvoice[]>;
  getPurchaseInvoice(id: number): Promise<PurchaseInvoice | undefined>;
  createPurchaseInvoice(invoice: InsertPurchaseInvoice, items: any[]): Promise<PurchaseInvoice>;

  // Chart of Accounts methods
  getAllChartOfAccounts(): Promise<ChartOfAccount[]>;
  getChartOfAccount(id: number): Promise<ChartOfAccount | undefined>;
  createChartOfAccount(account: InsertChartOfAccount): Promise<ChartOfAccount>;

  // Journal Entry methods
  getAllJournalEntries(): Promise<JournalEntry[]>;
  getJournalEntry(id: number): Promise<JournalEntry | undefined>;
  createJournalEntry(entry: InsertJournalEntry, lines: any[]): Promise<JournalEntry>;

  // Bank Account methods
  getAllBankAccounts(): Promise<BankAccount[]>;
  getBankAccount(id: number): Promise<BankAccount | undefined>;
  createBankAccount(account: InsertBankAccount): Promise<BankAccount>;

  // Bank Transaction methods
  getBankTransactions(bankAccountId?: number): Promise<BankTransaction[]>;
  getBankTransaction(id: number): Promise<BankTransaction | undefined>;
  createBankTransaction(transaction: InsertBankTransaction): Promise<BankTransaction>;
  reconcileBankTransactions(transactionIds: string[]): Promise<boolean>;

  // Payment methods
  getAllPaymentsReceived(): Promise<PaymentReceived[]>;
  getPaymentReceived(id: number): Promise<PaymentReceived | undefined>;
  createPaymentReceived(payment: InsertPaymentReceived): Promise<PaymentReceived>;
  getAllPaymentsMade(): Promise<PaymentMade[]>;
  getPaymentMade(id: number): Promise<PaymentMade | undefined>;
  createPaymentMade(payment: InsertPaymentMade): Promise<PaymentMade>;

  // Accounts Receivable/Payable methods
  getAccountsReceivable(): Promise<any[]>;
  getAccountsPayable(): Promise<any[]>;

  // Dashboard and reporting methods
  getDashboardData(period: string): Promise<any>;
  getRecentTransactions(): Promise<any[]>;
  getBalanceSheetReport(asOfDate: string, compareWith: string | null): Promise<any>;
  getCashFlowReport(period: string, startDate: string, endDate: string): Promise<any>;
  getProfitLossReport(period: string, startDate: string, endDate: string, compareWith: string | null): Promise<any>;
}

export class MemStorage implements IStorage {
  private usersMap: Map<number, User>;
  private customersMap: Map<number, Customer>;
  private vendorsMap: Map<number, Vendor>;
  private inventoryItemsMap: Map<number, InventoryItem>;
  private salesInvoicesMap: Map<number, SalesInvoice>;
  private salesInvoiceItemsMap: Map<number, SalesInvoiceItem[]>;
  private purchaseInvoicesMap: Map<number, PurchaseInvoice>;
  private purchaseInvoiceItemsMap: Map<number, PurchaseInvoiceItem[]>;
  private chartOfAccountsMap: Map<number, ChartOfAccount>;
  private journalEntriesMap: Map<number, JournalEntry>;
  private journalEntryLinesMap: Map<number, JournalEntryLine[]>;
  private paymentsReceivedMap: Map<number, PaymentReceived>;
  private paymentsMadeMap: Map<number, PaymentMade>;
  private bankAccountsMap: Map<number, BankAccount>;
  private bankTransactionsMap: Map<number, BankTransaction>;

  private currentUserId: number;
  private currentCustomerId: number;
  private currentVendorId: number;
  private currentInventoryItemId: number;
  private currentSalesInvoiceId: number;
  private currentSalesInvoiceItemId: number;
  private currentPurchaseInvoiceId: number;
  private currentPurchaseInvoiceItemId: number;
  private currentChartOfAccountId: number;
  private currentJournalEntryId: number;
  private currentJournalEntryLineId: number;
  private currentPaymentReceivedId: number;
  private currentPaymentMadeId: number;
  private currentBankAccountId: number;
  private currentBankTransactionId: number;

  constructor() {
    this.usersMap = new Map();
    this.customersMap = new Map();
    this.vendorsMap = new Map();
    this.inventoryItemsMap = new Map();
    this.salesInvoicesMap = new Map();
    this.salesInvoiceItemsMap = new Map();
    this.purchaseInvoicesMap = new Map();
    this.purchaseInvoiceItemsMap = new Map();
    this.chartOfAccountsMap = new Map();
    this.journalEntriesMap = new Map();
    this.journalEntryLinesMap = new Map();
    this.paymentsReceivedMap = new Map();
    this.paymentsMadeMap = new Map();
    this.bankAccountsMap = new Map();
    this.bankTransactionsMap = new Map();

    this.currentUserId = 1;
    this.currentCustomerId = 1;
    this.currentVendorId = 1;
    this.currentInventoryItemId = 1;
    this.currentSalesInvoiceId = 1;
    this.currentSalesInvoiceItemId = 1;
    this.currentPurchaseInvoiceId = 1;
    this.currentPurchaseInvoiceItemId = 1;
    this.currentChartOfAccountId = 1;
    this.currentJournalEntryId = 1;
    this.currentJournalEntryLineId = 1;
    this.currentPaymentReceivedId = 1;
    this.currentPaymentMadeId = 1;
    this.currentBankAccountId = 1;
    this.currentBankTransactionId = 1;

    this.initializeDemoData();
  }

  // Initialize demo data for UI testing
  private initializeDemoData() {
    // Create demo users
    this.createUser({
      username: "admin",
      password: "admin123",
      name: "John Doe",
      role: "Administrator"
    });

    // Create demo customers
    const customer1 = this.createCustomer({
      name: "Tech Supplies Inc.",
      email: "contact@techsupplies.com",
      phone: "555-123-4567",
      address: "123 Tech Blvd, Silicon Valley, CA 94025"
    });

    const customer2 = this.createCustomer({
      name: "Acme Corporation",
      email: "info@acmecorp.com",
      phone: "555-987-6543",
      address: "456 Industry Ave, Metropolis, NY 10001"
    });

    const customer3 = this.createCustomer({
      name: "Global Partners LLC",
      email: "partners@globalpartners.com",
      phone: "555-456-7890",
      address: "789 Global St, International City, TX 75001"
    });

    // Create demo vendors
    const vendor1 = this.createVendor({
      name: "Office Supplies Co.",
      email: "orders@officesupplies.com",
      phone: "555-222-3333",
      address: "321 Supplier Rd, Commerce City, OH 43215"
    });

    const vendor2 = this.createVendor({
      name: "Tech Hardware Ltd.",
      email: "sales@techhardware.com",
      phone: "555-444-5555",
      address: "654 Component St, Assembly Town, WA 98001"
    });

    // Create demo inventory items
    const item1 = this.createInventoryItem({
      code: "COMP-001",
      name: "Desktop Computer",
      description: "High-performance desktop workstation",
      unitPrice: 1200.00,
      costPrice: 900.00,
      quantityOnHand: 15,
      reorderLevel: 5
    });

    const item2 = this.createInventoryItem({
      code: "LAPTOP-001",
      name: "Business Laptop",
      description: "Lightweight business laptop with 16GB RAM",
      unitPrice: 950.00,
      costPrice: 750.00,
      quantityOnHand: 22,
      reorderLevel: 8
    });

    const item3 = this.createInventoryItem({
      code: "MONITOR-001",
      name: "24-inch Monitor",
      description: "Full HD monitor with adjustable stand",
      unitPrice: 250.00,
      costPrice: 180.00,
      quantityOnHand: 30,
      reorderLevel: 10
    });

    // Create chart of accounts
    const asset1 = this.createChartOfAccount({
      code: "1000",
      name: "Cash",
      type: "Asset",
      subtype: "Current Asset",
      isActive: true,
      balance: 145629.78
    });

    const asset2 = this.createChartOfAccount({
      code: "1100",
      name: "Accounts Receivable",
      type: "Asset",
      subtype: "Current Asset",
      isActive: true,
      balance: 42580.00
    });

    const asset3 = this.createChartOfAccount({
      code: "1200",
      name: "Inventory",
      type: "Asset",
      subtype: "Current Asset",
      isActive: true,
      balance: 86450.00
    });

    const liability1 = this.createChartOfAccount({
      code: "2000",
      name: "Accounts Payable",
      type: "Liability",
      subtype: "Current Liability",
      isActive: true,
      balance: 28320.00
    });

    const revenue1 = this.createChartOfAccount({
      code: "4000",
      name: "Sales Revenue",
      type: "Revenue",
      subtype: "Operating Revenue",
      isActive: true,
      balance: 128430.00
    });

    const expense1 = this.createChartOfAccount({
      code: "5000",
      name: "Cost of Goods Sold",
      type: "Expense",
      subtype: "Operating Expense",
      isActive: true,
      balance: 76235.00
    });

    // Create bank accounts
    const bankAccount1 = this.createBankAccount({
      name: "Business Checking",
      accountNumber: "CHK-12345678",
      isActive: true
    });

    const bankAccount2 = this.createBankAccount({
      name: "Business Savings",
      accountNumber: "SAV-87654321",
      isActive: true
    });

    // Create bank transactions
    this.createBankTransaction({
      bankAccountId: bankAccount1.id,
      date: new Date("2023-06-15").toISOString(),
      description: "Customer payment - Tech Supplies Inc.",
      amount: 1450.00,
      type: "deposit",
      reference: "DEP-12345",
      isReconciled: true
    });

    this.createBankTransaction({
      bankAccountId: bankAccount1.id,
      date: new Date("2023-06-18").toISOString(),
      description: "Office rent payment",
      amount: 3500.00,
      type: "withdrawal",
      reference: "CHK-9876",
      isReconciled: true
    });

    this.createBankTransaction({
      bankAccountId: bankAccount1.id,
      date: new Date("2023-06-22").toISOString(),
      description: "Vendor payment - Office Supplies Co.",
      amount: 1250.00,
      type: "withdrawal",
      reference: "CHK-9877",
      isReconciled: false
    });

    // Create sales invoices
    const salesInvoice1 = this.createSalesInvoice({
      invoiceNumber: "INV-202306001",
      customerId: customer1.id,
      date: new Date("2023-06-24").toISOString(),
      dueDate: new Date("2023-07-24").toISOString(),
      subtotal: 1960.00,
      tax: 196.00,
      total: 2156.00,
      status: "paid",
      notes: "Net 30 terms"
    }, [
      {
        itemId: item1.id,
        description: "Desktop Computer",
        quantity: 1,
        unitPrice: 1200.00,
        amount: 1200.00
      },
      {
        itemId: item3.id,
        description: "24-inch Monitor",
        quantity: 3,
        unitPrice: 250.00,
        amount: 750.00
      }
    ]);

    const salesInvoice2 = this.createSalesInvoice({
      invoiceNumber: "INV-202306002",
      customerId: customer2.id,
      date: new Date("2023-06-20").toISOString(),
      dueDate: new Date("2023-07-20").toISOString(),
      subtotal: 7954.55,
      tax: 795.45,
      total: 8750.00,
      status: "pending",
      notes: "Corporate account"
    }, [
      {
        itemId: item1.id,
        description: "Desktop Computer",
        quantity: 5,
        unitPrice: 1200.00,
        amount: 6000.00
      },
      {
        itemId: item2.id,
        description: "Business Laptop",
        quantity: 2,
        unitPrice: 950.00,
        amount: 1900.00
      }
    ]);

    // Create purchase invoices
    const purchaseInvoice1 = this.createPurchaseInvoice({
      invoiceNumber: "PO-202306001",
      vendorId: vendor1.id,
      date: new Date("2023-06-10").toISOString(),
      dueDate: new Date("2023-07-10").toISOString(),
      subtotal: 1364.00,
      tax: 136.40,
      total: 1500.40,
      status: "paid",
      notes: "Office supplies"
    }, [
      {
        itemId: item3.id,
        description: "24-inch Monitor",
        quantity: 4,
        unitPrice: 180.00,
        amount: 720.00
      }
    ]);

    // Add payments received
    this.createPaymentReceived({
      receiptNumber: "RCPT-202306001",
      customerId: customer1.id,
      date: new Date("2023-06-24").toISOString(),
      amount: 2156.00,
      paymentMethod: "bank_transfer",
      reference: "WIRE-123456",
      notes: "Payment for INV-202306001"
    });

    // Add payments made
    this.createPaymentMade({
      paymentNumber: "PMT-202306001",
      vendorId: vendor1.id,
      date: new Date("2023-06-15").toISOString(),
      amount: 1500.40,
      paymentMethod: "check",
      reference: "CHK-100123",
      notes: "Payment for PO-202306001"
    });

    // Create journal entries
    this.createJournalEntry({
      entryNumber: "JE-202306001",
      date: new Date("2023-06-30").toISOString(),
      description: "End of month adjusting entry",
      status: "posted",
      totalDebit: 3500.00,
      totalCredit: 3500.00
    }, [
      {
        accountId: this.getChartOfAccountByCode("5000").id,
        description: "Rent expense",
        debit: 3500.00,
        credit: 0.00
      },
      {
        accountId: this.getChartOfAccountByCode("1000").id,
        description: "Cash payment",
        debit: 0.00,
        credit: 3500.00
      }
    ]);
  }

  private getChartOfAccountByCode(code: string): ChartOfAccount {
    for (const [_, account] of this.chartOfAccountsMap) {
      if (account.code === code) {
        return account;
      }
    }
    throw new Error(`Chart of account with code ${code} not found`);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.usersMap.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const [_, user] of this.usersMap) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...userData, id };
    this.usersMap.set(id, user);
    return user;
  }

  // Customer methods
  async getAllCustomers(): Promise<Customer[]> {
    return Array.from(this.customersMap.values());
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    return this.customersMap.get(id);
  }

  async createCustomer(customerData: InsertCustomer): Promise<Customer> {
    const id = this.currentCustomerId++;
    const customer: Customer = { ...customerData, id, balance: 0 };
    this.customersMap.set(id, customer);
    return customer;
  }

  // Vendor methods
  async getAllVendors(): Promise<Vendor[]> {
    return Array.from(this.vendorsMap.values());
  }

  async getVendor(id: number): Promise<Vendor | undefined> {
    return this.vendorsMap.get(id);
  }

  async createVendor(vendorData: InsertVendor): Promise<Vendor> {
    const id = this.currentVendorId++;
    const vendor: Vendor = { ...vendorData, id, balance: 0 };
    this.vendorsMap.set(id, vendor);
    return vendor;
  }

  // Inventory methods
  async getAllInventoryItems(): Promise<InventoryItem[]> {
    return Array.from(this.inventoryItemsMap.values());
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    return this.inventoryItemsMap.get(id);
  }

  async createInventoryItem(itemData: InsertInventoryItem): Promise<InventoryItem> {
    const id = this.currentInventoryItemId++;
    const item: InventoryItem = { ...itemData, id };
    this.inventoryItemsMap.set(id, item);
    return item;
  }

  async updateInventoryItem(id: number, itemData: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const existingItem = this.inventoryItemsMap.get(id);
    if (!existingItem) {
      return undefined;
    }
    
    const updatedItem = { ...existingItem, ...itemData };
    this.inventoryItemsMap.set(id, updatedItem);
    return updatedItem;
  }

  async deleteInventoryItem(id: number): Promise<boolean> {
    return this.inventoryItemsMap.delete(id);
  }

  // Sales methods
  async getAllSalesInvoices(): Promise<SalesInvoice[]> {
    const invoices = Array.from(this.salesInvoicesMap.values());
    // Enrich with customer data
    return invoices.map(invoice => {
      const customer = this.customersMap.get(invoice.customerId);
      const items = this.salesInvoiceItemsMap.get(invoice.id) || [];
      return { ...invoice, customer, items };
    });
  }

  async getSalesInvoice(id: number): Promise<SalesInvoice | undefined> {
    const invoice = this.salesInvoicesMap.get(id);
    if (!invoice) return undefined;
    
    const customer = this.customersMap.get(invoice.customerId);
    const items = this.salesInvoiceItemsMap.get(id) || [];
    return { ...invoice, customer, items };
  }

  async createSalesInvoice(invoiceData: InsertSalesInvoice, items: any[]): Promise<SalesInvoice> {
    const id = this.currentSalesInvoiceId++;
    const invoice: SalesInvoice = { ...invoiceData, id };
    this.salesInvoicesMap.set(id, invoice);
    
    // Add invoice items
    const invoiceItems: SalesInvoiceItem[] = [];
    for (const item of items) {
      const itemId = this.currentSalesInvoiceItemId++;
      const invoiceItem: SalesInvoiceItem = {
        id: itemId,
        invoiceId: id,
        itemId: item.itemId,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        amount: item.amount
      };
      invoiceItems.push(invoiceItem);
    }
    this.salesInvoiceItemsMap.set(id, invoiceItems);
    
    // Update customer balance
    const customer = this.customersMap.get(invoiceData.customerId);
    if (customer) {
      customer.balance += invoiceData.total;
      this.customersMap.set(customer.id, customer);
    }
    
    // Return full invoice with customer and items
    return this.getSalesInvoice(id) as Promise<SalesInvoice>;
  }

  // Purchase methods
  async getAllPurchaseInvoices(): Promise<PurchaseInvoice[]> {
    const invoices = Array.from(this.purchaseInvoicesMap.values());
    // Enrich with vendor data
    return invoices.map(invoice => {
      const vendor = this.vendorsMap.get(invoice.vendorId);
      const items = this.purchaseInvoiceItemsMap.get(invoice.id) || [];
      return { ...invoice, vendor, items };
    });
  }

  async getPurchaseInvoice(id: number): Promise<PurchaseInvoice | undefined> {
    const invoice = this.purchaseInvoicesMap.get(id);
    if (!invoice) return undefined;
    
    const vendor = this.vendorsMap.get(invoice.vendorId);
    const items = this.purchaseInvoiceItemsMap.get(id) || [];
    return { ...invoice, vendor, items };
  }

  async createPurchaseInvoice(invoiceData: InsertPurchaseInvoice, items: any[]): Promise<PurchaseInvoice> {
    const id = this.currentPurchaseInvoiceId++;
    const invoice: PurchaseInvoice = { ...invoiceData, id };
    this.purchaseInvoicesMap.set(id, invoice);
    
    // Add invoice items
    const invoiceItems: PurchaseInvoiceItem[] = [];
    for (const item of items) {
      const itemId = this.currentPurchaseInvoiceItemId++;
      const invoiceItem: PurchaseInvoiceItem = {
        id: itemId,
        invoiceId: id,
        itemId: item.itemId,
        description: item.description,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        amount: item.amount
      };
      invoiceItems.push(invoiceItem);
      
      // Update inventory quantity
      const inventoryItem = this.inventoryItemsMap.get(item.itemId);
      if (inventoryItem) {
        inventoryItem.quantityOnHand += item.quantity;
        this.inventoryItemsMap.set(item.itemId, inventoryItem);
      }
    }
    this.purchaseInvoiceItemsMap.set(id, invoiceItems);
    
    // Update vendor balance
    const vendor = this.vendorsMap.get(invoiceData.vendorId);
    if (vendor) {
      vendor.balance += invoiceData.total;
      this.vendorsMap.set(vendor.id, vendor);
    }
    
    // Return full invoice with vendor and items
    return this.getPurchaseInvoice(id) as Promise<PurchaseInvoice>;
  }

  // Chart of Accounts methods
  async getAllChartOfAccounts(): Promise<ChartOfAccount[]> {
    return Array.from(this.chartOfAccountsMap.values());
  }

  async getChartOfAccount(id: number): Promise<ChartOfAccount | undefined> {
    return this.chartOfAccountsMap.get(id);
  }

  async createChartOfAccount(accountData: InsertChartOfAccount): Promise<ChartOfAccount> {
    const id = this.currentChartOfAccountId++;
    const account: ChartOfAccount = { ...accountData, id };
    this.chartOfAccountsMap.set(id, account);
    return account;
  }

  // Journal Entry methods
  async getAllJournalEntries(): Promise<JournalEntry[]> {
    const entries = Array.from(this.journalEntriesMap.values());
    // Enrich with lines
    return entries.map(entry => {
      const lines = this.journalEntryLinesMap.get(entry.id) || [];
      return { ...entry, lines };
    });
  }

  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    const entry = this.journalEntriesMap.get(id);
    if (!entry) return undefined;
    
    const lines = this.journalEntryLinesMap.get(id) || [];
    return { ...entry, lines };
  }

  async createJournalEntry(entryData: InsertJournalEntry, lines: any[]): Promise<JournalEntry> {
    const id = this.currentJournalEntryId++;
    const entry: JournalEntry = { ...entryData, id };
    this.journalEntriesMap.set(id, entry);
    
    // Add journal entry lines
    const entryLines: JournalEntryLine[] = [];
    for (const line of lines) {
      const lineId = this.currentJournalEntryLineId++;
      const entryLine: JournalEntryLine = {
        id: lineId,
        journalEntryId: id,
        accountId: line.accountId,
        description: line.description,
        debit: line.debit,
        credit: line.credit
      };
      entryLines.push(entryLine);
      
      // Update account balance if entry is posted
      if (entry.status === 'posted') {
        const account = this.chartOfAccountsMap.get(line.accountId);
        if (account) {
          // Update based on account type and debit/credit
          if (account.type === 'Asset' || account.type === 'Expense') {
            account.balance += line.debit - line.credit;
          } else {
            // Liability, Equity, Revenue
            account.balance += line.credit - line.debit;
          }
          this.chartOfAccountsMap.set(account.id, account);
        }
      }
    }
    this.journalEntryLinesMap.set(id, entryLines);
    
    // Return full entry with lines
    return this.getJournalEntry(id) as Promise<JournalEntry>;
  }

  // Bank Account methods
  async getAllBankAccounts(): Promise<BankAccount[]> {
    return Array.from(this.bankAccountsMap.values());
  }

  async getBankAccount(id: number): Promise<BankAccount | undefined> {
    return this.bankAccountsMap.get(id);
  }

  async createBankAccount(accountData: InsertBankAccount): Promise<BankAccount> {
    const id = this.currentBankAccountId++;
    const account: BankAccount = { ...accountData, id, balance: 0 };
    this.bankAccountsMap.set(id, account);
    return account;
  }

  // Bank Transaction methods
  async getBankTransactions(bankAccountId?: number): Promise<BankTransaction[]> {
    const transactions = Array.from(this.bankTransactionsMap.values());
    if (bankAccountId) {
      return transactions.filter(tx => tx.bankAccountId === bankAccountId);
    }
    return transactions;
  }

  async getBankTransaction(id: number): Promise<BankTransaction | undefined> {
    return this.bankTransactionsMap.get(id);
  }

  async createBankTransaction(transactionData: InsertBankTransaction): Promise<BankTransaction> {
    const id = this.currentBankTransactionId++;
    const transaction: BankTransaction = { ...transactionData, id };
    this.bankTransactionsMap.set(id, transaction);
    
    // Update bank account balance
    const bankAccount = this.bankAccountsMap.get(transactionData.bankAccountId);
    if (bankAccount) {
      if (transactionData.type === 'deposit') {
        bankAccount.balance += transactionData.amount;
      } else {
        bankAccount.balance -= transactionData.amount;
      }
      this.bankAccountsMap.set(bankAccount.id, bankAccount);
    }
    
    return transaction;
  }

  async reconcileBankTransactions(transactionIds: string[]): Promise<boolean> {
    for (const id of transactionIds) {
      const transaction = this.bankTransactionsMap.get(parseInt(id));
      if (transaction) {
        transaction.isReconciled = true;
        this.bankTransactionsMap.set(transaction.id, transaction);
      }
    }
    return true;
  }

  // Payment methods
  async getAllPaymentsReceived(): Promise<PaymentReceived[]> {
    const payments = Array.from(this.paymentsReceivedMap.values());
    // Enrich with customer data
    return payments.map(payment => {
      const customer = this.customersMap.get(payment.customerId);
      return { ...payment, customer };
    });
  }

  async getPaymentReceived(id: number): Promise<PaymentReceived | undefined> {
    const payment = this.paymentsReceivedMap.get(id);
    if (!payment) return undefined;
    
    const customer = this.customersMap.get(payment.customerId);
    return { ...payment, customer };
  }

  async createPaymentReceived(paymentData: InsertPaymentReceived): Promise<PaymentReceived> {
    const id = this.currentPaymentReceivedId++;
    const payment: PaymentReceived = { ...paymentData, id };
    this.paymentsReceivedMap.set(id, payment);
    
    // Update customer balance
    const customer = this.customersMap.get(paymentData.customerId);
    if (customer) {
      customer.balance -= paymentData.amount;
      this.customersMap.set(customer.id, customer);
    }
    
    // Return full payment with customer
    return this.getPaymentReceived(id) as Promise<PaymentReceived>;
  }

  async getAllPaymentsMade(): Promise<PaymentMade[]> {
    const payments = Array.from(this.paymentsMadeMap.values());
    // Enrich with vendor data
    return payments.map(payment => {
      const vendor = this.vendorsMap.get(payment.vendorId);
      return { ...payment, vendor };
    });
  }

  async getPaymentMade(id: number): Promise<PaymentMade | undefined> {
    const payment = this.paymentsMadeMap.get(id);
    if (!payment) return undefined;
    
    const vendor = this.vendorsMap.get(payment.vendorId);
    return { ...payment, vendor };
  }

  async createPaymentMade(paymentData: InsertPaymentMade): Promise<PaymentMade> {
    const id = this.currentPaymentMadeId++;
    const payment: PaymentMade = { ...paymentData, id };
    this.paymentsMadeMap.set(id, payment);
    
    // Update vendor balance
    const vendor = this.vendorsMap.get(paymentData.vendorId);
    if (vendor) {
      vendor.balance -= paymentData.amount;
      this.vendorsMap.set(vendor.id, vendor);
    }
    
    // Return full payment with vendor
    return this.getPaymentMade(id) as Promise<PaymentMade>;
  }

  // Accounts Receivable/Payable methods
  async getAccountsReceivable(): Promise<any[]> {
    return this.getAllSalesInvoices();
  }

  async getAccountsPayable(): Promise<any[]> {
    return this.getAllPurchaseInvoices();
  }

  // Dashboard and reporting methods
  async getDashboardData(period: string): Promise<any> {
    // Generate sample dashboard data
    return {
      kpis: {
        revenue: 128430,
        expenses: 94215,
        netProfit: 34215,
        cashPosition: 215784
      },
      revenueExpensesChart: [
        { name: "Jan", revenue: 92000, expenses: 80000 },
        { name: "Feb", revenue: 98000, expenses: 85000 },
        { name: "Mar", revenue: 105000, expenses: 90000 },
        { name: "Apr", revenue: 110000, expenses: 88000 },
        { name: "May", revenue: 120000, expenses: 95000 },
        { name: "Jun", revenue: 128430, expenses: 94215 },
      ],
      accountsStatus: {
        receivable: {
          total: 42580,
          current: 32150,
          overdue: 10430
        },
        payable: {
          total: 28320,
          current: 25620,
          overdue: 2700
        },
        inventory: {
          value: 86450,
          stockItems: 238,
          lowStock: 15
        }
      }
    };
  }

  async getRecentTransactions(): Promise<any[]> {
    // Combine and sort recent transactions
    const salesInvoices = await this.getAllSalesInvoices();
    const purchaseInvoices = await this.getAllPurchaseInvoices();
    
    const combinedTransactions = [
      ...salesInvoices.map(invoice => ({
        date: new Date(invoice.date),
        description: invoice.customer?.name || "Unknown Customer",
        type: "Invoice",
        amount: invoice.total,
        status: invoice.status
      })),
      ...purchaseInvoices.map(invoice => ({
        date: new Date(invoice.date),
        description: invoice.vendor?.name || "Unknown Vendor",
        type: "Expense",
        amount: invoice.total,
        status: invoice.status
      }))
    ];
    
    // Sort by date descending and take the most recent 5
    return combinedTransactions
      .sort((a, b) => b.date.getTime() - a.date.getTime())
      .slice(0, 5);
  }

  async getBalanceSheetReport(asOfDate: string, compareWith: string | null): Promise<any> {
    // Generate sample balance sheet report
    return {
      asOfDate: asOfDate,
      assets: {
        currentAssets: {
          cash: 145629.78,
          accountsReceivable: 42580.00,
          inventory: 86450.00,
          otherCurrentAssets: 12500.00,
          totalCurrentAssets: 287159.78,
        },
        fixedAssets: {
          propertyAndEquipment: 275000.00,
          accumulatedDepreciation: -45000.00,
          totalFixedAssets: 230000.00,
        },
        totalAssets: 517159.78,
      },
      liabilities: {
        currentLiabilities: {
          accountsPayable: 28320.00,
          shortTermDebt: 15000.00,
          accruedExpenses: 8500.00,
          totalCurrentLiabilities: 51820.00,
        },
        longTermLiabilities: {
          longTermDebt: 120000.00,
          totalLongTermLiabilities: 120000.00,
        },
        totalLiabilities: 171820.00,
      },
      equity: {
        capitalStock: 150000.00,
        retainedEarnings: 161124.78,
        currentYearEarnings: 34215.00,
        totalEquity: 345339.78,
      },
      totalLiabilitiesAndEquity: 517159.78,
    };
  }

  async getCashFlowReport(period: string, startDate: string, endDate: string): Promise<any> {
    // Generate sample cash flow report
    return {
      period: period,
      startDate: startDate || new Date(new Date().setMonth(new Date().getMonth() - 5)).toISOString().split('T')[0],
      endDate: endDate || new Date().toISOString().split('T')[0],
      summary: {
        startingBalance: 180569.20,
        endingBalance: 215784.00,
        netCashFlow: 35214.80,
      },
      operations: {
        inflows: {
          receivedFromCustomers: 132450.00,
          otherOperatingInflows: 5280.00,
          totalOperatingInflows: 137730.00,
        },
        outflows: {
          paidToSuppliers: 62580.00,
          paidToEmployees: 12450.00,
          otherOperatingOutflows: 8750.00,
          totalOperatingOutflows: 83780.00,
        },
        netCashFromOperations: 53950.00,
      },
      investing: {
        inflows: {
          saleOfEquipment: 0.00,
          totalInvestingInflows: 0.00,
        },
        outflows: {
          purchaseOfEquipment: 15000.00,
          totalInvestingOutflows: 15000.00,
        },
        netCashFromInvesting: -15000.00,
      },
      financing: {
        inflows: {
          proceedsFromLoans: 0.00,
          totalFinancingInflows: 0.00,
        },
        outflows: {
          loanRepayments: 3735.20,
          totalFinancingOutflows: 3735.20,
        },
        netCashFromFinancing: -3735.20,
      },
      monthlyData: [
        { name: 'Jan', operations: 8250, investing: -2000, financing: -800 },
        { name: 'Feb', operations: 9120, investing: -1500, financing: -800 },
        { name: 'Mar', operations: 10500, investing: -1000, financing: -800 },
        { name: 'Apr', operations: 11340, investing: -3500, financing: -520 },
        { name: 'May', operations: 11890, investing: -3000, financing: -520 },
        { name: 'Jun', operations: 12850, investing: -4000, financing: -520 },
      ],
    };
  }

  async getProfitLossReport(period: string, startDate: string, endDate: string, compareWith: string | null): Promise<any> {
    // Generate sample profit & loss report
    return {
      period: period,
      startDate: startDate || new Date(new Date().setMonth(new Date().getMonth() - 5)).toISOString().split('T')[0],
      endDate: endDate || new Date().toISOString().split('T')[0],
      revenue: {
        sales: 120540.00,
        serviceRevenue: 7890.00,
        otherRevenue: 0.00,
        totalRevenue: 128430.00,
      },
      costOfSales: {
        costOfGoods: 68250.00,
        directLabor: 7985.00,
        totalCostOfSales: 76235.00,
      },
      grossProfit: 52195.00,
      expenses: {
        salaries: 14850.00,
        rent: 3500.00,
        utilities: 980.00,
        officeSupplies: 650.00,
        marketing: 2500.00,
        insurance: 1200.00,
        depreciation: 1850.00,
        otherExpenses: 450.00,
        totalExpenses: 25980.00,
      },
      operatingIncome: 26215.00,
      otherIncome: {
        interestIncome: 0.00,
        totalOtherIncome: 0.00,
      },
      otherExpenses: {
        interestExpense: 2000.00,
        totalOtherExpenses: 2000.00,
      },
      netIncomeBeforeTax: 24215.00,
      incomeTax: {
        currentTax: 10000.00,
        totalTax: 10000.00,
      },
      netIncome: 14215.00,
      monthlyData: [
        { name: 'Jan', revenue: 108250, expenses: 92450, profit: 15800 },
        { name: 'Feb', revenue: 116420, expenses: 96780, profit: 19640 },
        { name: 'Mar', revenue: 112380, expenses: 99240, profit: 13140 },
        { name: 'Apr', revenue: 118650, expenses: 100850, profit: 17800 },
        { name: 'May', revenue: 122430, expenses: 97600, profit: 24830 },
        { name: 'Jun', revenue: 128430, expenses: 104215, profit: 24215 },
      ],
    };
  }
}

export const storage = new MemStorage();
