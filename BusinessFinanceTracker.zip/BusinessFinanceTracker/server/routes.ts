import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertUserSchema,
  insertChartOfAccountSchema,
  insertCustomerSchema,
  insertVendorSchema,
  insertInventoryItemSchema,
  insertSalesInvoiceSchema,
  insertPurchaseInvoiceSchema,
  insertJournalEntrySchema,
  insertJournalEntryLineSchema,
  insertPaymentReceivedSchema,
  insertPaymentMadeSchema,
  insertBankAccountSchema,
  insertBankTransactionSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // ============= USERS API =============
  app.post('/api/users', async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create user' });
      }
    }
  });

  app.get('/api/users/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get user' });
    }
  });

  // ============= CUSTOMERS API =============
  app.get('/api/customers', async (req, res) => {
    try {
      const customers = await storage.getAllCustomers();
      res.json(customers);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch customers' });
    }
  });

  app.post('/api/customers', async (req, res) => {
    try {
      const customerData = insertCustomerSchema.parse(req.body);
      const customer = await storage.createCustomer(customerData);
      res.status(201).json(customer);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create customer' });
      }
    }
  });

  // ============= VENDORS API =============
  app.get('/api/vendors', async (req, res) => {
    try {
      const vendors = await storage.getAllVendors();
      res.json(vendors);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch vendors' });
    }
  });

  app.post('/api/vendors', async (req, res) => {
    try {
      const vendorData = insertVendorSchema.parse(req.body);
      const vendor = await storage.createVendor(vendorData);
      res.status(201).json(vendor);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create vendor' });
      }
    }
  });

  // ============= INVENTORY API =============
  app.get('/api/inventory', async (req, res) => {
    try {
      const inventoryItems = await storage.getAllInventoryItems();
      res.json(inventoryItems);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch inventory items' });
    }
  });

  app.post('/api/inventory', async (req, res) => {
    try {
      const itemData = insertInventoryItemSchema.parse(req.body);
      const item = await storage.createInventoryItem(itemData);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create inventory item' });
      }
    }
  });

  app.patch('/api/inventory/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updateData = insertInventoryItemSchema.partial().parse(req.body);
      const item = await storage.updateInventoryItem(id, updateData);
      if (!item) {
        return res.status(404).json({ message: 'Inventory item not found' });
      }
      res.json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to update inventory item' });
      }
    }
  });

  app.delete('/api/inventory/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteInventoryItem(id);
      if (!success) {
        return res.status(404).json({ message: 'Inventory item not found' });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete inventory item' });
    }
  });

  // ============= SALES API =============
  app.get('/api/sales', async (req, res) => {
    try {
      const salesInvoices = await storage.getAllSalesInvoices();
      res.json(salesInvoices);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch sales invoices' });
    }
  });

  app.post('/api/sales', async (req, res) => {
    try {
      const invoiceData = insertSalesInvoiceSchema.parse(req.body);
      const invoice = await storage.createSalesInvoice(invoiceData, req.body.items);
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create sales invoice' });
      }
    }
  });

  // ============= PURCHASES API =============
  app.get('/api/purchases', async (req, res) => {
    try {
      const purchaseInvoices = await storage.getAllPurchaseInvoices();
      res.json(purchaseInvoices);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch purchase invoices' });
    }
  });

  app.post('/api/purchases', async (req, res) => {
    try {
      const invoiceData = insertPurchaseInvoiceSchema.parse(req.body);
      const invoice = await storage.createPurchaseInvoice(invoiceData, req.body.items);
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create purchase invoice' });
      }
    }
  });

  // ============= ACCOUNTS RECEIVABLE API =============
  app.get('/api/accounts-receivable', async (req, res) => {
    try {
      const receivables = await storage.getAccountsReceivable();
      res.json(receivables);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch accounts receivable' });
    }
  });

  // ============= ACCOUNTS PAYABLE API =============
  app.get('/api/accounts-payable', async (req, res) => {
    try {
      const payables = await storage.getAccountsPayable();
      res.json(payables);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch accounts payable' });
    }
  });

  // ============= GENERAL LEDGER API =============
  app.get('/api/accounts', async (req, res) => {
    try {
      const accounts = await storage.getAllChartOfAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch chart of accounts' });
    }
  });

  app.post('/api/accounts', async (req, res) => {
    try {
      const accountData = insertChartOfAccountSchema.parse(req.body);
      const account = await storage.createChartOfAccount(accountData);
      res.status(201).json(account);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create account' });
      }
    }
  });

  app.get('/api/journal-entries', async (req, res) => {
    try {
      const entries = await storage.getAllJournalEntries();
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch journal entries' });
    }
  });

  app.post('/api/journal-entries', async (req, res) => {
    try {
      const entryData = insertJournalEntrySchema.parse(req.body);
      const entry = await storage.createJournalEntry(entryData, req.body.lines);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create journal entry' });
      }
    }
  });

  // ============= BANK RECONCILIATION API =============
  app.get('/api/bank-accounts', async (req, res) => {
    try {
      const accounts = await storage.getAllBankAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch bank accounts' });
    }
  });

  app.post('/api/bank-accounts', async (req, res) => {
    try {
      const accountData = insertBankAccountSchema.parse(req.body);
      const account = await storage.createBankAccount(accountData);
      res.status(201).json(account);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create bank account' });
      }
    }
  });

  app.get('/api/bank-transactions', async (req, res) => {
    try {
      const bankAccountId = req.query.bankAccountId ? parseInt(req.query.bankAccountId as string) : undefined;
      const transactions = await storage.getBankTransactions(bankAccountId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch bank transactions' });
    }
  });

  app.post('/api/bank-transactions', async (req, res) => {
    try {
      const transactionData = insertBankTransactionSchema.parse(req.body);
      const transaction = await storage.createBankTransaction(transactionData);
      res.status(201).json(transaction);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create bank transaction' });
      }
    }
  });

  app.post('/api/bank-transactions/reconcile', async (req, res) => {
    try {
      const { transactionIds } = req.body;
      const success = await storage.reconcileBankTransactions(transactionIds);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ message: 'Failed to reconcile transactions' });
    }
  });

  // ============= PAYMENTS API =============
  app.get('/api/payments/received', async (req, res) => {
    try {
      const payments = await storage.getAllPaymentsReceived();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payments received' });
    }
  });

  app.post('/api/payments/received', async (req, res) => {
    try {
      const paymentData = insertPaymentReceivedSchema.parse(req.body);
      const payment = await storage.createPaymentReceived(paymentData);
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create payment received' });
      }
    }
  });

  app.get('/api/payments/made', async (req, res) => {
    try {
      const payments = await storage.getAllPaymentsMade();
      res.json(payments);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch payments made' });
    }
  });

  app.post('/api/payments/made', async (req, res) => {
    try {
      const paymentData = insertPaymentMadeSchema.parse(req.body);
      const payment = await storage.createPaymentMade(paymentData);
      res.status(201).json(payment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Failed to create payment made' });
      }
    }
  });

  // ============= DASHBOARD API =============
  app.get('/api/dashboard', async (req, res) => {
    try {
      const period = req.query.period || 'month';
      const dashboardData = await storage.getDashboardData(period as string);
      res.json(dashboardData);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch dashboard data' });
    }
  });

  app.get('/api/transactions/recent', async (req, res) => {
    try {
      const recentTransactions = await storage.getRecentTransactions();
      res.json(recentTransactions);
    } catch (error) {
      res.status(500).json({ message: 'Failed to fetch recent transactions' });
    }
  });

  // ============= REPORTS API =============
  app.get('/api/reports/balance-sheet', async (req, res) => {
    try {
      const asOfDate = req.query.asOfDate as string || new Date().toISOString().split('T')[0];
      const compareWith = req.query.compareWith as string || null;
      const balanceSheet = await storage.getBalanceSheetReport(asOfDate, compareWith);
      res.json(balanceSheet);
    } catch (error) {
      res.status(500).json({ message: 'Failed to generate balance sheet report' });
    }
  });

  app.get('/api/reports/cash-flow', async (req, res) => {
    try {
      const period = req.query.period as string || 'month';
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      const cashFlow = await storage.getCashFlowReport(period, startDate, endDate);
      res.json(cashFlow);
    } catch (error) {
      res.status(500).json({ message: 'Failed to generate cash flow report' });
    }
  });

  app.get('/api/reports/profit-loss', async (req, res) => {
    try {
      const period = req.query.period as string || 'month';
      const startDate = req.query.startDate as string;
      const endDate = req.query.endDate as string;
      const compareWith = req.query.compareWith as string || null;
      const profitLoss = await storage.getProfitLossReport(period, startDate, endDate, compareWith);
      res.json(profitLoss);
    } catch (error) {
      res.status(500).json({ message: 'Failed to generate profit & loss report' });
    }
  });

  return httpServer;
}
