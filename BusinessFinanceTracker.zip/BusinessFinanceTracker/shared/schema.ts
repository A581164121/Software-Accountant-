import { pgTable, text, serial, integer, boolean, real, timestamp, customType, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
});

// Chart of Accounts
export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(), // Asset, Liability, Equity, Revenue, Expense
  subtype: text("subtype").notNull(), // More specific categorization
  isActive: boolean("is_active").notNull().default(true),
  balance: real("balance").notNull().default(0),
});

export const insertChartOfAccountSchema = createInsertSchema(chartOfAccounts).pick({
  code: true,
  name: true,
  type: true,
  subtype: true,
  isActive: true,
});

// Customers
export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  balance: real("balance").notNull().default(0),
});

export const insertCustomerSchema = createInsertSchema(customers).pick({
  name: true,
  email: true,
  phone: true,
  address: true,
});

// Vendors
export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  balance: real("balance").notNull().default(0),
});

export const insertVendorSchema = createInsertSchema(vendors).pick({
  name: true,
  email: true,
  phone: true,
  address: true,
});

// Inventory Items
export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  unitPrice: real("unit_price").notNull(),
  costPrice: real("cost_price").notNull(),
  quantityOnHand: integer("quantity_on_hand").notNull().default(0),
  reorderLevel: integer("reorder_level").notNull().default(10),
});

export const insertInventoryItemSchema = createInsertSchema(inventoryItems).pick({
  code: true,
  name: true,
  description: true,
  unitPrice: true,
  costPrice: true,
  quantityOnHand: true,
  reorderLevel: true,
});

// Sales Invoices
export const salesInvoices = pgTable("sales_invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  date: timestamp("date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  subtotal: real("subtotal").notNull(),
  tax: real("tax").notNull(),
  total: real("total").notNull(),
  status: text("status").notNull().default("draft"), // draft, sent, paid, overdue, cancelled
  notes: text("notes"),
});

export const insertSalesInvoiceSchema = createInsertSchema(salesInvoices).pick({
  invoiceNumber: true,
  customerId: true,
  date: true,
  dueDate: true,
  subtotal: true,
  tax: true,
  total: true,
  status: true,
  notes: true,
});

// Sales Invoice Items
export const salesInvoiceItems = pgTable("sales_invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(),
  itemId: integer("item_id").notNull(),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: real("unit_price").notNull(),
  amount: real("amount").notNull(),
});

export const insertSalesInvoiceItemSchema = createInsertSchema(salesInvoiceItems).pick({
  invoiceId: true,
  itemId: true,
  description: true,
  quantity: true,
  unitPrice: true,
  amount: true,
});

// Purchase Invoices
export const purchaseInvoices = pgTable("purchase_invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  vendorId: integer("vendor_id").notNull(),
  date: timestamp("date").notNull(),
  dueDate: timestamp("due_date").notNull(),
  subtotal: real("subtotal").notNull(),
  tax: real("tax").notNull(),
  total: real("total").notNull(),
  status: text("status").notNull().default("draft"), // draft, received, paid, overdue, cancelled
  notes: text("notes"),
});

export const insertPurchaseInvoiceSchema = createInsertSchema(purchaseInvoices).pick({
  invoiceNumber: true,
  vendorId: true,
  date: true,
  dueDate: true,
  subtotal: true,
  tax: true,
  total: true,
  status: true,
  notes: true,
});

// Purchase Invoice Items
export const purchaseInvoiceItems = pgTable("purchase_invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(),
  itemId: integer("item_id").notNull(),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull(),
  unitPrice: real("unit_price").notNull(),
  amount: real("amount").notNull(),
});

export const insertPurchaseInvoiceItemSchema = createInsertSchema(purchaseInvoiceItems).pick({
  invoiceId: true,
  itemId: true,
  description: true,
  quantity: true,
  unitPrice: true,
  amount: true,
});

// Journal Entries
export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  entryNumber: text("entry_number").notNull().unique(),
  date: timestamp("date").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("draft"), // draft, posted, archived
  totalDebit: real("total_debit").notNull(),
  totalCredit: real("total_credit").notNull(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries).pick({
  entryNumber: true,
  date: true,
  description: true,
  status: true,
  totalDebit: true,
  totalCredit: true,
});

// Journal Entry Lines
export const journalEntryLines = pgTable("journal_entry_lines", {
  id: serial("id").primaryKey(),
  journalEntryId: integer("journal_entry_id").notNull(),
  accountId: integer("account_id").notNull(),
  description: text("description"),
  debit: real("debit").notNull().default(0),
  credit: real("credit").notNull().default(0),
});

export const insertJournalEntryLineSchema = createInsertSchema(journalEntryLines).pick({
  journalEntryId: true,
  accountId: true,
  description: true,
  debit: true,
  credit: true,
});

// Payments Received
export const paymentsReceived = pgTable("payments_received", {
  id: serial("id").primaryKey(),
  receiptNumber: text("receipt_number").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  date: timestamp("date").notNull(),
  amount: real("amount").notNull(),
  paymentMethod: text("payment_method").notNull(), // cash, check, credit_card, bank_transfer
  reference: text("reference"),
  notes: text("notes"),
});

export const insertPaymentReceivedSchema = createInsertSchema(paymentsReceived).pick({
  receiptNumber: true,
  customerId: true,
  date: true,
  amount: true,
  paymentMethod: true,
  reference: true,
  notes: true,
});

// Payments Made
export const paymentsMade = pgTable("payments_made", {
  id: serial("id").primaryKey(),
  paymentNumber: text("payment_number").notNull().unique(),
  vendorId: integer("vendor_id").notNull(),
  date: timestamp("date").notNull(),
  amount: real("amount").notNull(),
  paymentMethod: text("payment_method").notNull(), // cash, check, credit_card, bank_transfer
  reference: text("reference"),
  notes: text("notes"),
});

export const insertPaymentMadeSchema = createInsertSchema(paymentsMade).pick({
  paymentNumber: true,
  vendorId: true,
  date: true,
  amount: true,
  paymentMethod: true,
  reference: true,
  notes: true,
});

// Bank Accounts
export const bankAccounts = pgTable("bank_accounts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  accountNumber: text("account_number").notNull(),
  balance: real("balance").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertBankAccountSchema = createInsertSchema(bankAccounts).pick({
  name: true,
  accountNumber: true,
  isActive: true,
});

// Bank Transactions
export const bankTransactions = pgTable("bank_transactions", {
  id: serial("id").primaryKey(),
  bankAccountId: integer("bank_account_id").notNull(),
  date: timestamp("date").notNull(),
  description: text("description").notNull(),
  amount: real("amount").notNull(),
  type: text("type").notNull(), // deposit, withdrawal, transfer
  reference: text("reference"),
  isReconciled: boolean("is_reconciled").notNull().default(false),
});

export const insertBankTransactionSchema = createInsertSchema(bankTransactions).pick({
  bankAccountId: true,
  date: true,
  description: true,
  amount: true,
  type: true,
  reference: true,
  isReconciled: true,
});

// Type exports
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type ChartOfAccount = typeof chartOfAccounts.$inferSelect;
export type InsertChartOfAccount = z.infer<typeof insertChartOfAccountSchema>;

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;

export type Vendor = typeof vendors.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;

export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;

export type SalesInvoice = typeof salesInvoices.$inferSelect;
export type InsertSalesInvoice = z.infer<typeof insertSalesInvoiceSchema>;

export type SalesInvoiceItem = typeof salesInvoiceItems.$inferSelect;
export type InsertSalesInvoiceItem = z.infer<typeof insertSalesInvoiceItemSchema>;

export type PurchaseInvoice = typeof purchaseInvoices.$inferSelect;
export type InsertPurchaseInvoice = z.infer<typeof insertPurchaseInvoiceSchema>;

export type PurchaseInvoiceItem = typeof purchaseInvoiceItems.$inferSelect;
export type InsertPurchaseInvoiceItem = z.infer<typeof insertPurchaseInvoiceItemSchema>;

export type JournalEntry = typeof journalEntries.$inferSelect;
export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;

export type JournalEntryLine = typeof journalEntryLines.$inferSelect;
export type InsertJournalEntryLine = z.infer<typeof insertJournalEntryLineSchema>;

export type PaymentReceived = typeof paymentsReceived.$inferSelect;
export type InsertPaymentReceived = z.infer<typeof insertPaymentReceivedSchema>;

export type PaymentMade = typeof paymentsMade.$inferSelect;
export type InsertPaymentMade = z.infer<typeof insertPaymentMadeSchema>;

export type BankAccount = typeof bankAccounts.$inferSelect;
export type InsertBankAccount = z.infer<typeof insertBankAccountSchema>;

export type BankTransaction = typeof bankTransactions.$inferSelect;
export type InsertBankTransaction = z.infer<typeof insertBankTransactionSchema>;
