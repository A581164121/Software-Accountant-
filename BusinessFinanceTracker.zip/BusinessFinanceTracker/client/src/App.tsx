import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";

import Sidebar from "@/components/layout/sidebar";
import AppHeader from "@/components/layout/app-header";
import PageContainer from "@/components/layout/page-container";

import Dashboard from "@/pages/dashboard";
import Sales from "@/pages/sales";
import Purchases from "@/pages/purchases";
import Inventory from "@/pages/inventory";
import AccountsReceivable from "@/pages/accounts-receivable";
import AccountsPayable from "@/pages/accounts-payable";
import GeneralLedger from "@/pages/general-ledger";
import BankReconciliation from "@/pages/bank-reconciliation";
import Receipts from "@/pages/receipts";
import BalanceSheet from "@/pages/reports/balance-sheet";
import CashFlow from "@/pages/reports/cash-flow";
import ProfitLoss from "@/pages/reports/profit-loss";
import NotFound from "@/pages/not-found";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="flex h-screen overflow-hidden">
          <Sidebar />
          <div className="flex-1 ml-0 lg:ml-64">
            <AppHeader />
            <PageContainer>
              <Switch>
                <Route path="/" component={Dashboard} />
                <Route path="/dashboard" component={Dashboard} />
                <Route path="/sales" component={Sales} />
                <Route path="/purchases" component={Purchases} />
                <Route path="/inventory" component={Inventory} />
                <Route path="/accounts-receivable" component={AccountsReceivable} />
                <Route path="/accounts-payable" component={AccountsPayable} />
                <Route path="/general-ledger" component={GeneralLedger} />
                <Route path="/bank-reconciliation" component={BankReconciliation} />
                <Route path="/receipts" component={Receipts} />
                <Route path="/reports/balance-sheet" component={BalanceSheet} />
                <Route path="/reports/cash-flow" component={CashFlow} />
                <Route path="/reports/profit-loss" component={ProfitLoss} />
                <Route component={NotFound} />
              </Switch>
            </PageContainer>
          </div>
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
