import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertInventoryItemSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Package2 } from "lucide-react";

// Extend the schema with additional validation
const inventoryFormSchema = insertInventoryItemSchema.extend({
  code: z.string().min(2, "Code must be at least 2 characters").max(20, "Code must be at most 20 characters"),
  name: z.string().min(2, "Name must be at least 2 characters").max(100, "Name must be at most 100 characters"),
  unitPrice: z.coerce.number().min(0.01, "Unit price must be greater than 0"),
  costPrice: z.coerce.number().min(0.01, "Cost price must be greater than 0"),
  quantityOnHand: z.coerce.number().int().min(0, "Quantity cannot be negative"),
  reorderLevel: z.coerce.number().int().min(1, "Reorder level must be at least 1"),
});

type InventoryFormValues = z.infer<typeof inventoryFormSchema>;

export function InventoryForm({ onSuccess, initialData }: { onSuccess?: () => void, initialData?: any }) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!initialData;

  const form = useForm<InventoryFormValues>({
    resolver: zodResolver(inventoryFormSchema),
    defaultValues: initialData || {
      code: `ITEM-${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
      name: '',
      description: '',
      unitPrice: 0,
      costPrice: 0,
      quantityOnHand: 0,
      reorderLevel: 10,
    },
  });
  
  // Calculate profit margin
  const [profitMargin, setProfitMargin] = useState(() => {
    if (initialData) {
      const { unitPrice, costPrice } = initialData;
      return costPrice > 0 ? ((unitPrice - costPrice) / costPrice) * 100 : 0;
    }
    return 0;
  });

  const inventoryMutation = useMutation({
    mutationFn: async (data: InventoryFormValues) => {
      if (isEditing) {
        return await apiRequest('PATCH', `/api/inventory/${initialData.id}`, data);
      } else {
        return await apiRequest('POST', '/api/inventory', data);
      }
    },
    onSuccess: () => {
      toast({
        title: isEditing ? "Item updated" : "Item created",
        description: isEditing 
          ? "Inventory item has been updated successfully" 
          : "Inventory item has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to ${isEditing ? 'update' : 'create'} inventory item: ${error.message}`,
      });
    },
  });

  // Update profit margin when unit price or cost price changes
  const calculateProfitMargin = (unitPrice: number, costPrice: number) => {
    if (costPrice > 0) {
      const margin = ((unitPrice - costPrice) / costPrice) * 100;
      setProfitMargin(margin);
    } else {
      setProfitMargin(0);
    }
  };

  // Handle form submission
  function onSubmit(data: InventoryFormValues) {
    inventoryMutation.mutate(data);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Package2 className="mr-2 h-5 w-5" />
          {isEditing ? "Edit Inventory Item" : "Add Inventory Item"}
        </CardTitle>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Code</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea {...field} rows={3} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <FormField
                control={form.control}
                name="unitPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Unit Selling Price</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01"
                        min="0"
                        onChange={(e) => {
                          const value = parseFloat(e.target.value) || 0;
                          field.onChange(value);
                          calculateProfitMargin(value, form.getValues('costPrice'));
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="costPrice"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cost Price</FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number" 
                        step="0.01"
                        min="0"
                        onChange={(e) => {
                          const value = parseFloat(e.target.value) || 0;
                          field.onChange(value);
                          calculateProfitMargin(form.getValues('unitPrice'), value);
                        }}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div>
                <FormLabel>Profit Margin</FormLabel>
                <div className="flex items-center h-10 px-3 border rounded-md mt-2 bg-neutral-lightest">
                  <span className="text-sm">{profitMargin.toFixed(2)}%</span>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="quantityOnHand"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Quantity on Hand</FormLabel>
                    <FormControl>
                      <Input {...field} type="number" min="0" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="reorderLevel"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reorder Level</FormLabel>
                    <FormControl>
                      <Input {...field} type="number" min="1" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onSuccess}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={inventoryMutation.isPending}
            >
              {inventoryMutation.isPending 
                ? isEditing ? "Updating..." : "Creating..." 
                : isEditing ? "Update Item" : "Create Item"
              }
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
