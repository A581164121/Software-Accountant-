import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertPurchaseInvoiceSchema } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Plus } from "lucide-react";

// Extend the schema with additional validation
const purchaseFormSchema = insertPurchaseInvoiceSchema.extend({
  items: z.array(z.object({
    itemId: z.coerce.number().min(1, "Item is required"),
    description: z.string().min(1, "Description is required"),
    quantity: z.coerce.number().min(1, "Quantity must be at least 1"),
    unitPrice: z.coerce.number().min(0.01, "Unit price must be greater than 0"),
    amount: z.coerce.number().min(0),
  })).min(1, "At least one item is required"),
});

type PurchaseFormValues = z.infer<typeof purchaseFormSchema>;

export function PurchaseForm({ onSuccess }: { onSuccess?: () => void }) {
  const [items, setItems] = useState([{ itemId: 0, description: "", quantity: 1, unitPrice: 0, amount: 0 }]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get vendors
  const { data: vendors } = useQuery({
    queryKey: ['/api/vendors'],
  });

  // Get inventory items
  const { data: inventoryItems } = useQuery({
    queryKey: ['/api/inventory'],
  });

  const form = useForm<PurchaseFormValues>({
    resolver: zodResolver(purchaseFormSchema),
    defaultValues: {
      invoiceNumber: `PO-${new Date().getFullYear()}${(new Date().getMonth() + 1).toString().padStart(2, '0')}${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      vendorId: 0,
      date: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      subtotal: 0,
      tax: 0,
      total: 0,
      status: 'draft',
      notes: '',
      items: [{ itemId: 0, description: "", quantity: 1, unitPrice: 0, amount: 0 }]
    },
  });

  const createPurchaseInvoiceMutation = useMutation({
    mutationFn: async (data: PurchaseFormValues) => {
      await apiRequest('POST', '/api/purchases', data);
    },
    onSuccess: () => {
      toast({
        title: "Purchase order created",
        description: "Purchase order has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/purchases'] });
      if (onSuccess) onSuccess();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to create purchase order: ${error.message}`,
      });
    },
  });

  // Calculate line amount when quantity or price changes
  const calculateLineAmount = (index: number, quantity: number, unitPrice: number) => {
    const newItems = [...items];
    newItems[index] = {
      ...newItems[index],
      quantity,
      unitPrice,
      amount: quantity * unitPrice
    };
    setItems(newItems);
    
    // Update form values
    form.setValue(`items.${index}.quantity`, quantity);
    form.setValue(`items.${index}.unitPrice`, unitPrice);
    form.setValue(`items.${index}.amount`, quantity * unitPrice);
    
    // Recalculate totals
    const subtotal = newItems.reduce((sum, item) => sum + item.amount, 0);
    const tax = subtotal * 0.1; // 10% tax rate
    
    form.setValue('subtotal', subtotal);
    form.setValue('tax', tax);
    form.setValue('total', subtotal + tax);
  };

  // Add a new line item
  const addLineItem = () => {
    const newItems = [...items, { itemId: 0, description: "", quantity: 1, unitPrice: 0, amount: 0 }];
    setItems(newItems);
    form.setValue('items', newItems);
  };

  // Remove a line item
  const removeLineItem = (index: number) => {
    if (items.length === 1) return; // Keep at least one item
    
    const newItems = items.filter((_, i) => i !== index);
    setItems(newItems);
    form.setValue('items', newItems);
    
    // Recalculate totals
    const subtotal = newItems.reduce((sum, item) => sum + item.amount, 0);
    const tax = subtotal * 0.1; // 10% tax rate
    
    form.setValue('subtotal', subtotal);
    form.setValue('tax', tax);
    form.setValue('total', subtotal + tax);
  };

  // Update line item description when inventory item is selected
  const handleItemSelection = (index: number, itemId: number) => {
    if (!inventoryItems) return;
    
    const selectedItem = inventoryItems.find((item: any) => item.id === itemId);
    if (selectedItem) {
      const newItems = [...items];
      newItems[index] = {
        ...newItems[index],
        itemId,
        description: selectedItem.name,
        unitPrice: selectedItem.costPrice // Use cost price for purchases
      };
      setItems(newItems);
      
      form.setValue(`items.${index}.itemId`, itemId);
      form.setValue(`items.${index}.description`, selectedItem.name);
      form.setValue(`items.${index}.unitPrice`, selectedItem.costPrice);
      
      // Recalculate amount
      calculateLineAmount(index, newItems[index].quantity, selectedItem.costPrice);
    }
  };

  // Handle form submission
  function onSubmit(data: PurchaseFormValues) {
    createPurchaseInvoiceMutation.mutate(data);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create Purchase Order</CardTitle>
      </CardHeader>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="invoiceNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Purchase Order #</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="vendorId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vendor</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      defaultValue={field.value.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a vendor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {vendors?.map((vendor: any) => (
                          <SelectItem key={vendor.id} value={vendor.id.toString()}>
                            {vendor.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Order Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select status" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="received">Received</SelectItem>
                        <SelectItem value="paid">Paid</SelectItem>
                        <SelectItem value="overdue">Overdue</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <Separator />
            
            <div>
              <h3 className="font-medium mb-4">Order Items</h3>
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={index} className="grid grid-cols-12 gap-4 items-end">
                    <div className="col-span-6 md:col-span-3">
                      <FormField
                        control={form.control}
                        name={`items.${index}.itemId`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Item</FormLabel>
                            <Select
                              onValueChange={(value) => handleItemSelection(index, parseInt(value))}
                              defaultValue={field.value.toString()}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select an item" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {inventoryItems?.map((item: any) => (
                                  <SelectItem key={item.id} value={item.id.toString()}>
                                    {item.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-6 md:col-span-3">
                      <FormField
                        control={form.control}
                        name={`items.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Description</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-4 md:col-span-2">
                      <FormField
                        control={form.control}
                        name={`items.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Quantity</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                min="1"
                                onChange={(e) => {
                                  const value = parseInt(e.target.value) || 0;
                                  field.onChange(value);
                                  calculateLineAmount(index, value, items[index].unitPrice);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-4 md:col-span-2">
                      <FormField
                        control={form.control}
                        name={`items.${index}.unitPrice`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Unit Price</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="number" 
                                step="0.01"
                                min="0"
                                onChange={(e) => {
                                  const value = parseFloat(e.target.value) || 0;
                                  field.onChange(value);
                                  calculateLineAmount(index, items[index].quantity, value);
                                }}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-3 md:col-span-1">
                      <FormField
                        control={form.control}
                        name={`items.${index}.amount`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Amount</FormLabel>
                            <FormControl>
                              <Input {...field} readOnly type="number" step="0.01" className="bg-neutral-lightest" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="col-span-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeLineItem(index)}
                        disabled={items.length === 1}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
                
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addLineItem}
                  className="mt-2"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={4} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Subtotal:</span>
                  <span className="font-mono">${form.watch('subtotal').toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Tax (10%):</span>
                  <span className="font-mono">${form.watch('tax').toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between items-center font-bold">
                  <span>Total:</span>
                  <span className="font-mono">${form.watch('total').toFixed(2)}</span>
                </div>
              </div>
            </div>
          </CardContent>
          
          <CardFooter className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={onSuccess}
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={createPurchaseInvoiceMutation.isPending}
            >
              {createPurchaseInvoiceMutation.isPending ? "Saving..." : "Save Purchase Order"}
            </Button>
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}
