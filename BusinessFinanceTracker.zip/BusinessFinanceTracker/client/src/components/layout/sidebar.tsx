import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  ChevronRight,
  LayoutDashboard,
  Receipt,
  ShoppingCart,
  Package2,
  CreditCard,
  FileText,
  BookText,
  Building2,
  Receipt as ReceiptIcon,
  Scale,
  TrendingUp,
  Banknote,
  X,
  Menu,
  ChartScatter
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  currentPath: string;
  onClick?: () => void;
}

const NavItem = ({ href, icon, children, currentPath, onClick }: NavItemProps) => {
  const isActive = currentPath === href || (href !== "/" && currentPath.startsWith(href));
  
  return (
    <Link href={href}>
      <a
        className={cn(
          "flex items-center px-4 py-3 text-neutral-dark hover:bg-neutral-lightest",
          isActive && "text-primary bg-blue-50"
        )}
        onClick={onClick}
      >
        <span className="mr-3">{icon}</span>
        <span>{children}</span>
      </a>
    </Link>
  );
};

const Sidebar = () => {
  const [location] = useLocation();
  const isMobile = useIsMobile();
  const [isOpen, setIsOpen] = useState(!isMobile);

  // Handle sidebar state on screen size changes
  useEffect(() => {
    setIsOpen(!isMobile);
  }, [isMobile]);

  const toggleSidebar = () => setIsOpen(!isOpen);
  const closeSidebar = () => isMobile && setIsOpen(false);

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-10"
          onClick={closeSidebar}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "w-64 h-full bg-white shadow-md fixed top-0 left-0 z-20 transition-all duration-300",
          isMobile && !isOpen && "-translate-x-full"
        )}
      >
        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className="p-4 flex items-center border-b border-neutral-light">
            <div className="w-10 h-10 rounded-lg bg-primary flex items-center justify-center text-white mr-3">
              <ChartScatter size={24} />
            </div>
            <div>
              <h1 className="text-xl font-medium text-primary">FinanceFlow</h1>
              <div className="text-xs text-neutral">Accounting Software</div>
            </div>
            {isMobile && (
              <Button
                variant="ghost"
                size="icon"
                className="ml-auto lg:hidden"
                onClick={closeSidebar}
              >
                <X size={20} />
              </Button>
            )}
          </div>

          {/* Navigation Menu */}
          <nav className="flex-1 overflow-y-auto py-4">
            <div className="px-4 mb-3 text-xs font-semibold text-neutral uppercase tracking-wider">
              Main
            </div>
            <NavItem href="/" icon={<LayoutDashboard size={20} />} currentPath={location} onClick={closeSidebar}>
              Dashboard
            </NavItem>
            
            <div className="px-4 mt-6 mb-3 text-xs font-semibold text-neutral uppercase tracking-wider">
              Transactions
            </div>
            <NavItem href="/sales" icon={<Receipt size={20} />} currentPath={location} onClick={closeSidebar}>
              Sales
            </NavItem>
            <NavItem href="/purchases" icon={<ShoppingCart size={20} />} currentPath={location} onClick={closeSidebar}>
              Purchases
            </NavItem>
            <NavItem href="/inventory" icon={<Package2 size={20} />} currentPath={location} onClick={closeSidebar}>
              Inventory
            </NavItem>
            
            <div className="px-4 mt-6 mb-3 text-xs font-semibold text-neutral uppercase tracking-wider">
              Accounting
            </div>
            <NavItem href="/accounts-receivable" icon={<CreditCard size={20} />} currentPath={location} onClick={closeSidebar}>
              Accounts Receivable
            </NavItem>
            <NavItem href="/accounts-payable" icon={<FileText size={20} />} currentPath={location} onClick={closeSidebar}>
              Accounts Payable
            </NavItem>
            <NavItem href="/general-ledger" icon={<BookText size={20} />} currentPath={location} onClick={closeSidebar}>
              General Ledger
            </NavItem>
            <NavItem href="/bank-reconciliation" icon={<Building2 size={20} />} currentPath={location} onClick={closeSidebar}>
              Bank Reconciliation
            </NavItem>
            <NavItem href="/receipts" icon={<ReceiptIcon size={20} />} currentPath={location} onClick={closeSidebar}>
              Cash & Purchase Receipts
            </NavItem>
            
            <div className="px-4 mt-6 mb-3 text-xs font-semibold text-neutral uppercase tracking-wider">
              Reports
            </div>
            <NavItem href="/reports/balance-sheet" icon={<Scale size={20} />} currentPath={location} onClick={closeSidebar}>
              Balance Sheet
            </NavItem>
            <NavItem href="/reports/cash-flow" icon={<Banknote size={20} />} currentPath={location} onClick={closeSidebar}>
              Cash Flow
            </NavItem>
            <NavItem href="/reports/profit-loss" icon={<TrendingUp size={20} />} currentPath={location} onClick={closeSidebar}>
              Profit & Loss
            </NavItem>
          </nav>

          {/* User profile */}
          <div className="border-t border-neutral-light p-4">
            <div className="flex items-center">
              <div className="w-9 h-9 rounded-full bg-primary-light text-white flex items-center justify-center mr-3">
                <span className="font-medium">JD</span>
              </div>
              <div>
                <div className="font-medium">John Doe</div>
                <div className="text-xs text-neutral">Financial Administrator</div>
              </div>
              <div className="ml-auto">
                <Button variant="ghost" size="icon" className="text-neutral hover:text-primary">
                  <ChevronRight size={20} />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile toggle button */}
      {isMobile && !isOpen && (
        <Button
          variant="ghost"
          size="icon"
          className="fixed top-3 left-4 z-10"
          onClick={toggleSidebar}
        >
          <Menu size={24} />
        </Button>
      )}
    </>
  );
};

export default Sidebar;
