import { cn } from "@/lib/utils";

interface PageContainerProps {
  children: React.ReactNode;
  className?: string;
}

const PageContainer = ({ children, className }: PageContainerProps) => {
  return (
    <main className={cn("pt-16 pb-8 px-4 md:px-6 h-screen overflow-y-auto", className)}>
      {children}
    </main>
  );
};

export default PageContainer;
