import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bell, HelpCircle, Search, Settings } from "lucide-react";

const AppHeader = () => {
  return (
    <header className="bg-white shadow-sm fixed top-0 right-0 left-0 z-10 lg:left-64">
      <div className="flex h-16 items-center px-4">
        <div className="flex items-center border rounded-lg px-3 py-2 bg-neutral-lightest flex-1 max-w-xl ml-9 lg:ml-0">
          <Search className="text-neutral mr-2 h-5 w-5" />
          <Input
            type="text"
            placeholder="Search transactions, accounts..."
            className="bg-transparent border-0 shadow-none focus-visible:ring-0 pl-0"
          />
        </div>
        <div className="flex items-center ml-auto">
          <Button variant="ghost" size="icon" className="text-neutral-dark hover:text-primary mx-1">
            <HelpCircle size={20} />
          </Button>
          <Button variant="ghost" size="icon" className="text-neutral-dark hover:text-primary mx-1 relative">
            <Bell size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full"></span>
          </Button>
          <Button variant="ghost" size="icon" className="text-neutral-dark hover:text-primary mx-1">
            <Settings size={20} />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default AppHeader;
