import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell
} from "recharts";
import { formatCurrency } from "@/lib/utils";

interface ChartProps {
  title: string;
  children: React.ReactNode;
}

export const ChartContainer = ({ title, children }: ChartProps) => {
  return (
    <Card>
      <CardContent className="pt-5">
        <h2 className="font-medium mb-6">{title}</h2>
        {children}
      </CardContent>
    </Card>
  );
};

// Revenue & Expenses chart
interface RevenueExpensesChartProps {
  data: Array<{
    name: string;
    revenue: number;
    expenses: number;
  }>;
}

export const RevenueExpensesChart = ({ data }: RevenueExpensesChartProps) => {
  return (
    <ChartContainer title="Revenue & Expenses">
      <div className="flex items-center mb-6">
        <div className="flex items-center mr-4">
          <div className="w-3 h-3 rounded-full bg-primary mr-2"></div>
          <span className="text-sm text-neutral-dark">Revenue</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-error mr-2"></div>
          <span className="text-sm text-neutral-dark">Expenses</span>
        </div>
      </div>
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{
              top: 5,
              right: 30,
              left: 20,
              bottom: 5,
            }}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis tickFormatter={(value) => `$${value/1000}k`} />
            <Tooltip formatter={(value) => formatCurrency(Number(value))} />
            <Area type="monotone" dataKey="revenue" stroke="#1976D2" fill="#1976D2" fillOpacity={0.3} />
            <Area type="monotone" dataKey="expenses" stroke="#D32F2F" fill="#D32F2F" fillOpacity={0.3} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </ChartContainer>
  );
};

// Accounts Status (Payable/Receivable)
interface AccountsStatusProps {
  receivableTotal: number;
  receivableCurrent: number;
  receivableOverdue: number;
  payableTotal: number;
  payableCurrent: number;
  payableOverdue: number;
  inventoryValue: number;
  stockItems: number;
  lowStock: number;
}

export const AccountsStatusChart = ({
  receivableTotal,
  receivableCurrent,
  receivableOverdue,
  payableTotal,
  payableCurrent,
  payableOverdue,
  inventoryValue,
  stockItems,
  lowStock
}: AccountsStatusProps) => {
  return (
    <ChartContainer title="Accounts Status">
      <div className="space-y-5">
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-neutral-dark">Accounts Receivable</div>
            <div className="text-sm font-medium font-mono">{formatCurrency(receivableTotal)}</div>
          </div>
          <div className="w-full bg-neutral-light rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full" 
              style={{ width: `${(receivableCurrent / receivableTotal) * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-1 text-xs text-neutral">
            <span>Current: {formatCurrency(receivableCurrent)}</span>
            <span>Overdue: {formatCurrency(receivableOverdue)}</span>
          </div>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-neutral-dark">Accounts Payable</div>
            <div className="text-sm font-medium font-mono">{formatCurrency(payableTotal)}</div>
          </div>
          <div className="w-full bg-neutral-light rounded-full h-2">
            <div 
              className="bg-error h-2 rounded-full" 
              style={{ width: `${(payableCurrent / payableTotal) * 100}%` }}
            ></div>
          </div>
          <div className="flex justify-between mt-1 text-xs text-neutral">
            <span>Current: {formatCurrency(payableCurrent)}</span>
            <span>Overdue: {formatCurrency(payableOverdue)}</span>
          </div>
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm text-neutral-dark">Inventory Value</div>
            <div className="text-sm font-medium font-mono">{formatCurrency(inventoryValue)}</div>
          </div>
          <div className="w-full bg-neutral-light rounded-full h-2">
            <div 
              className="bg-amber-500 h-2 rounded-full" 
              style={{ width: "85%" }}
            ></div>
          </div>
          <div className="flex justify-between mt-1 text-xs text-neutral">
            <span>Stock Items: {stockItems}</span>
            <span>Low Stock: {lowStock}</span>
          </div>
        </div>
      </div>
    </ChartContainer>
  );
};

// Cash Flow Breakdown
interface CashFlowChartProps {
  data: Array<{
    name: string;
    value: number;
    color: string;
  }>;
}

export const CashFlowChart = ({ data }: CashFlowChartProps) => {
  return (
    <ChartContainer title="Cash Flow Breakdown">
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
              label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => formatCurrency(Number(value))} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="flex flex-wrap gap-4 justify-center mt-4">
        {data.map((item, index) => (
          <div key={index} className="flex items-center">
            <div 
              className="w-3 h-3 rounded-full mr-2" 
              style={{ backgroundColor: item.color }}
            ></div>
            <span className="text-sm text-neutral-dark">{item.name}</span>
          </div>
        ))}
      </div>
    </ChartContainer>
  );
};
