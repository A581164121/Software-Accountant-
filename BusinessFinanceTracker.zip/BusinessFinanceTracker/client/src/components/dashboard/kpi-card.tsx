import { formatCurrency, formatPercentage } from "@/lib/utils";
import { ChevronDown, ChevronUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface KpiCardProps {
  title: string;
  value: number;
  percentageChange: number;
  comparisonText: string;
  icon: React.ReactNode;
  iconBgClass?: string;
  delay?: number;
}

export const KpiCard = ({ 
  title, 
  value, 
  percentageChange, 
  comparisonText, 
  icon, 
  iconBgClass = "bg-primary bg-opacity-10",
  delay = 0 
}: KpiCardProps) => {
  const isPositiveChange = percentageChange >= 0;
  
  return (
    <Card 
      className="animate-fadeInUp"
      style={{ animationDelay: `${delay}ms` }}
    >
      <CardContent className="pt-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-neutral text-sm">{title}</h3>
            <p className="text-2xl font-medium font-mono">{formatCurrency(value)}</p>
          </div>
          <div className={cn("w-10 h-10 rounded-full flex items-center justify-center", iconBgClass)}>
            {icon}
          </div>
        </div>
        <div className="flex items-center">
          <span className={cn(
            "inline-flex items-center text-sm",
            isPositiveChange ? "text-success" : "text-error"
          )}>
            {isPositiveChange ? (
              <ChevronUp className="h-4 w-4 mr-1" />
            ) : (
              <ChevronDown className="h-4 w-4 mr-1" />
            )}
            {Math.abs(percentageChange).toFixed(1)}%
          </span>
          <span className="text-neutral text-xs ml-2">{comparisonText}</span>
        </div>
      </CardContent>
    </Card>
  );
};
