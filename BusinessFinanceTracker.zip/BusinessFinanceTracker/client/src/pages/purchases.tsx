import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlusCircle, DownloadCloud, Filter, ChevronDown, Pencil, Trash2, Eye } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import { PurchaseForm } from "@/components/forms/purchase-form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Purchases = () => {
  const [showNewPurchaseForm, setShowNewPurchaseForm] = useState(false);
  const [selectedPurchase, setSelectedPurchase] = useState<any>(null);
  
  // Fetch purchase invoices
  const { data: purchaseInvoices, isLoading } = useQuery({
    queryKey: ['/api/purchases'],
  });

  // Define columns for DataTable
  const columns = [
    {
      accessorKey: "invoiceNumber",
      header: "Purchase Order #",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("invoiceNumber")}</div>
        );
      },
    },
    {
      accessorKey: "vendor",
      header: "Vendor",
      cell: ({ row }: any) => {
        const vendor = row.original.vendor;
        return <div>{vendor?.name || "Unknown Vendor"}</div>;
      },
    },
    {
      accessorKey: "date",
      header: "Order Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "dueDate",
      header: "Due Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("dueDate"))}</div>;
      },
    },
    {
      accessorKey: "total",
      header: "Amount",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("total"))}</div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => {
        const status = row.getValue("status");
        const { bg, text } = getStatusColor(status);
        
        return (
          <div className="text-right">
            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium ${bg} ${text} rounded`}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </span>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSelectedPurchase(row.original)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  <span>View</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pencil className="mr-2 h-4 w-4" />
                  <span>Edit</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Trash2 className="mr-2 h-4 w-4" />
                  <span>Delete</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Purchase Orders</h1>
          <p className="text-neutral">Manage and track your purchase orders and vendor expenses</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <DownloadCloud className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button className="flex items-center gap-2" onClick={() => setShowNewPurchaseForm(true)}>
            <PlusCircle className="h-4 w-4" />
            <span>New Purchase</span>
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-5">
        <DataTable
          columns={columns}
          data={isLoading ? [] : purchaseInvoices || []}
          searchColumn="invoiceNumber"
          searchPlaceholder="Search purchase orders..."
        />
      </div>

      {/* New Purchase Form Dialog */}
      <Dialog open={showNewPurchaseForm} onOpenChange={setShowNewPurchaseForm}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <PurchaseForm onSuccess={() => setShowNewPurchaseForm(false)} />
        </DialogContent>
      </Dialog>

      {/* View Purchase Dialog */}
      <Dialog open={!!selectedPurchase} onOpenChange={() => setSelectedPurchase(null)}>
        <DialogContent className="max-w-4xl">
          {selectedPurchase && (
            <div className="p-4">
              <h2 className="text-xl font-medium mb-4">Purchase Order #{selectedPurchase.invoiceNumber}</h2>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="text-sm font-medium text-neutral">Vendor</h3>
                  <p>{selectedPurchase.vendor?.name || "Unknown Vendor"}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Status</h3>
                  <div className="mt-1">
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium ${getStatusColor(selectedPurchase.status).bg} ${getStatusColor(selectedPurchase.status).text} rounded`}>
                      {selectedPurchase.status.charAt(0).toUpperCase() + selectedPurchase.status.slice(1)}
                    </span>
                  </div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Order Date</h3>
                  <p>{formatDate(selectedPurchase.date)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Due Date</h3>
                  <p>{formatDate(selectedPurchase.dueDate)}</p>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="text-sm font-medium text-neutral mb-2">Items</h3>
                <table className="min-w-full border border-neutral-light">
                  <thead className="bg-neutral-lightest">
                    <tr>
                      <th className="py-2 px-3 text-left text-xs font-medium text-neutral-dark">Description</th>
                      <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Quantity</th>
                      <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Unit Price</th>
                      <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-light">
                    {selectedPurchase.items?.map((item: any, index: number) => (
                      <tr key={index} className="border-t border-neutral-light">
                        <td className="py-2 px-3 text-sm">{item.description}</td>
                        <td className="py-2 px-3 text-sm text-right">{item.quantity}</td>
                        <td className="py-2 px-3 text-sm text-right font-mono">{formatCurrency(item.unitPrice)}</td>
                        <td className="py-2 px-3 text-sm text-right font-mono">{formatCurrency(item.amount)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <div className="flex justify-end">
                <div className="w-64">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm">Subtotal:</span>
                    <span className="font-mono">{formatCurrency(selectedPurchase.subtotal)}</span>
                  </div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm">Tax:</span>
                    <span className="font-mono">{formatCurrency(selectedPurchase.tax)}</span>
                  </div>
                  <div className="flex justify-between items-center font-medium">
                    <span>Total:</span>
                    <span className="font-mono">{formatCurrency(selectedPurchase.total)}</span>
                  </div>
                </div>
              </div>

              {selectedPurchase.notes && (
                <div className="mt-6">
                  <h3 className="text-sm font-medium text-neutral mb-1">Notes</h3>
                  <p className="text-sm text-neutral-dark">{selectedPurchase.notes}</p>
                </div>
              )}

              <div className="flex justify-end mt-6 gap-2">
                <Button variant="outline">Download PDF</Button>
                <Button>Mark as Paid</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Purchases;
