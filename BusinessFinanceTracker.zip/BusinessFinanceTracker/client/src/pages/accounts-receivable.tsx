import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PlusCircle, DownloadCloud, Filter, ChevronDown, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertPaymentReceivedSchema } from "@shared/schema";

const paymentFormSchema = insertPaymentReceivedSchema.extend({
  customerId: z.coerce.number().min(1, "Customer is required"),
  amount: z.coerce.number().min(0.01, "Amount must be greater than 0"),
  date: z.string().min(1, "Date is required"),
  paymentMethod: z.string().min(1, "Payment method is required"),
});

type PaymentFormValues = z.infer<typeof paymentFormSchema>;

const AccountsReceivable = () => {
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch receivables
  const { data: receivables, isLoading } = useQuery({
    queryKey: ['/api/accounts-receivable'],
  });

  // Fetch customers
  const { data: customers } = useQuery({
    queryKey: ['/api/customers'],
  });

  const { register, handleSubmit, reset, control, formState: { errors } } = useForm<PaymentFormValues>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      receiptNumber: `REC-${new Date().getFullYear()}${(new Date().getMonth() + 1).toString().padStart(2, '0')}${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
      customerId: 0,
      date: new Date().toISOString().split('T')[0],
      amount: 0,
      paymentMethod: 'bank_transfer',
      reference: '',
      notes: '',
    },
  });

  const recordPaymentMutation = useMutation({
    mutationFn: async (data: PaymentFormValues) => {
      await apiRequest('POST', '/api/payments/received', data);
    },
    onSuccess: () => {
      toast({
        title: "Payment recorded",
        description: "Payment has been recorded successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/accounts-receivable'] });
      setShowPaymentForm(false);
      reset();
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to record payment: ${error.message}`,
      });
    },
  });

  const onSubmit = (data: PaymentFormValues) => {
    recordPaymentMutation.mutate(data);
  };

  // Calculate totals
  const calculateTotals = () => {
    if (!receivables) return { total: 0, current: 0, overdue: 0 };
    
    const total = receivables.reduce((sum: number, invoice: any) => sum + invoice.total, 0);
    const current = receivables.filter((invoice: any) => invoice.status !== 'overdue')
      .reduce((sum: number, invoice: any) => sum + invoice.total, 0);
    const overdue = receivables.filter((invoice: any) => invoice.status === 'overdue')
      .reduce((sum: number, invoice: any) => sum + invoice.total, 0);
    
    return { total, current, overdue };
  };

  const { total, current, overdue } = calculateTotals();

  // Define columns for DataTable
  const columns = [
    {
      accessorKey: "invoiceNumber",
      header: "Invoice #",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("invoiceNumber")}</div>
        );
      },
    },
    {
      accessorKey: "customer",
      header: "Customer",
      cell: ({ row }: any) => {
        const customer = row.original.customer;
        return <div>{customer?.name || "Unknown Customer"}</div>;
      },
    },
    {
      accessorKey: "date",
      header: "Invoice Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "dueDate",
      header: "Due Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("dueDate"))}</div>;
      },
    },
    {
      accessorKey: "total",
      header: "Amount",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("total"))}</div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => {
        const status = row.getValue("status");
        const { bg, text } = getStatusColor(status);
        
        return (
          <div className="text-right">
            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium ${bg} ${text} rounded`}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </span>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSelectedInvoice(row.original)}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  <span>Record Payment</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Clock className="mr-2 h-4 w-4" />
                  <span>Extend Due Date</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Accounts Receivable</h1>
          <p className="text-neutral">Manage customer invoices and payments</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <DownloadCloud className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button className="flex items-center gap-2" onClick={() => setShowPaymentForm(true)}>
            <PlusCircle className="h-4 w-4" />
            <span>Record Payment</span>
          </Button>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium text-neutral">Total Receivables</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-medium font-mono">{formatCurrency(total)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium text-neutral">Current</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-medium font-mono text-success">{formatCurrency(current)}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-medium text-neutral">Overdue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-medium font-mono text-error">{formatCurrency(overdue)}</div>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="all">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Invoices</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="overdue">Overdue</TabsTrigger>
          <TabsTrigger value="paid">Paid</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="mt-0">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <DataTable
              columns={columns}
              data={isLoading ? [] : receivables || []}
              searchColumn="invoiceNumber"
              searchPlaceholder="Search invoices..."
            />
          </div>
        </TabsContent>
        
        <TabsContent value="pending" className="mt-0">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <DataTable
              columns={columns}
              data={isLoading ? [] : receivables?.filter((invoice: any) => invoice.status === 'sent') || []}
              searchColumn="invoiceNumber"
              searchPlaceholder="Search pending invoices..."
            />
          </div>
        </TabsContent>
        
        <TabsContent value="overdue" className="mt-0">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <DataTable
              columns={columns}
              data={isLoading ? [] : receivables?.filter((invoice: any) => invoice.status === 'overdue') || []}
              searchColumn="invoiceNumber"
              searchPlaceholder="Search overdue invoices..."
            />
          </div>
        </TabsContent>
        
        <TabsContent value="paid" className="mt-0">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <DataTable
              columns={columns}
              data={isLoading ? [] : receivables?.filter((invoice: any) => invoice.status === 'paid') || []}
              searchColumn="invoiceNumber"
              searchPlaceholder="Search paid invoices..."
            />
          </div>
        </TabsContent>
      </Tabs>

      {/* Record Payment Dialog */}
      <Dialog open={showPaymentForm} onOpenChange={setShowPaymentForm}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="receiptNumber">Receipt Number</Label>
              <Input 
                id="receiptNumber" 
                {...register('receiptNumber')} 
                className={errors.receiptNumber ? "border-destructive" : ""}
              />
              {errors.receiptNumber && (
                <p className="text-xs text-destructive">{errors.receiptNumber.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="customerId">Customer</Label>
              <Controller
                control={control}
                name="customerId"
                render={({ field }) => (
                  <Select
                    onValueChange={(value) => field.onChange(parseInt(value))}
                    defaultValue={field.value.toString()}
                  >
                    <SelectTrigger className={errors.customerId ? "border-destructive" : ""}>
                      <SelectValue placeholder="Select a customer" />
                    </SelectTrigger>
                    <SelectContent>
                      {customers?.map((customer: any) => (
                        <SelectItem key={customer.id} value={customer.id.toString()}>
                          {customer.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.customerId && (
                <p className="text-xs text-destructive">{errors.customerId.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date">Payment Date</Label>
              <Input 
                id="date" 
                type="date" 
                {...register('date')} 
                className={errors.date ? "border-destructive" : ""}
              />
              {errors.date && (
                <p className="text-xs text-destructive">{errors.date.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input 
                id="amount" 
                type="number" 
                step="0.01"
                min="0.01"
                {...register('amount')} 
                className={errors.amount ? "border-destructive" : ""}
              />
              {errors.amount && (
                <p className="text-xs text-destructive">{errors.amount.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="paymentMethod">Payment Method</Label>
              <Controller
                control={control}
                name="paymentMethod"
                render={({ field }) => (
                  <Select
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                  >
                    <SelectTrigger className={errors.paymentMethod ? "border-destructive" : ""}>
                      <SelectValue placeholder="Select payment method" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cash">Cash</SelectItem>
                      <SelectItem value="check">Check</SelectItem>
                      <SelectItem value="credit_card">Credit Card</SelectItem>
                      <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.paymentMethod && (
                <p className="text-xs text-destructive">{errors.paymentMethod.message}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="reference">Reference</Label>
              <Input id="reference" {...register('reference')} />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Input id="notes" {...register('notes')} />
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowPaymentForm(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={recordPaymentMutation.isPending}
              >
                {recordPaymentMutation.isPending ? "Saving..." : "Save Payment"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AccountsReceivable;
