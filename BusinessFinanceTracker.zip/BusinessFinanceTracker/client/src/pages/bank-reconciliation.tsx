import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Check, PlusCircle, Filter, ChevronDown, Download, CalendarRange } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const BankReconciliation = () => {
  const [selectedAccount, setSelectedAccount] = useState<string | null>(null);
  const [showReconcileDialog, setShowReconcileDialog] = useState(false);
  const [showTransactionDialog, setShowTransactionDialog] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch bank accounts
  const { data: bankAccounts, isLoading: accountsLoading } = useQuery({
    queryKey: ['/api/bank-accounts'],
  });

  // Fetch bank transactions
  const { data: bankTransactions, isLoading: transactionsLoading } = useQuery({
    queryKey: ['/api/bank-transactions', selectedAccount],
    enabled: !!selectedAccount,
  });

  const reconcileTransactionsMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      await apiRequest('POST', '/api/bank-transactions/reconcile', { transactionIds: ids });
    },
    onSuccess: () => {
      toast({
        title: "Transactions reconciled",
        description: `${selectedItems.length} transactions have been reconciled successfully`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bank-transactions', selectedAccount] });
      setSelectedItems([]);
      setShowReconcileDialog(false);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to reconcile transactions: ${error.message}`,
      });
    },
  });

  // Calculate account summary
  const getAccountSummary = () => {
    if (!selectedAccount || !bankAccounts) return { balance: 0, reconciled: 0, unreconciled: 0 };
    
    const account = bankAccounts.find((acc: any) => acc.id.toString() === selectedAccount);
    if (!account) return { balance: 0, reconciled: 0, unreconciled: 0 };
    
    const balance = account.balance;
    
    const reconciled = bankTransactions
      ?.filter((tx: any) => tx.isReconciled)
      .reduce((sum: number, tx: any) => sum + (tx.type === 'deposit' ? tx.amount : -tx.amount), 0) || 0;
      
    const unreconciled = bankTransactions
      ?.filter((tx: any) => !tx.isReconciled)
      .reduce((sum: number, tx: any) => sum + (tx.type === 'deposit' ? tx.amount : -tx.amount), 0) || 0;
    
    return { balance, reconciled, unreconciled };
  };

  const { balance, reconciled, unreconciled } = getAccountSummary();

  const handleSelectRow = (id: string) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter(item => item !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(bankTransactions?.filter((tx: any) => !tx.isReconciled).map((tx: any) => tx.id.toString()) || []);
    } else {
      setSelectedItems([]);
    }
  };

  const handleReconcile = () => {
    if (selectedItems.length === 0) {
      toast({
        variant: "destructive",
        title: "No transactions selected",
        description: "Please select at least one transaction to reconcile",
      });
      return;
    }
    
    setShowReconcileDialog(true);
  };

  // Define columns for DataTable
  const columns = [
    {
      id: "select",
      header: ({ table }: any) => (
        <Checkbox
          checked={
            bankTransactions?.filter((tx: any) => !tx.isReconciled).length > 0 &&
            selectedItems.length === bankTransactions?.filter((tx: any) => !tx.isReconciled).length
          }
          onCheckedChange={(value) => handleSelectAll(!!value)}
          aria-label="Select all"
        />
      ),
      cell: ({ row }: any) => {
        return (
          <div className="flex items-center">
            <Checkbox
              checked={selectedItems.includes(row.original.id.toString())}
              onCheckedChange={() => handleSelectRow(row.original.id.toString())}
              aria-label="Select row"
              disabled={row.original.isReconciled}
            />
          </div>
        );
      },
      enableSorting: false,
      enableHiding: false,
    },
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "description",
      header: "Description",
      cell: ({ row }: any) => {
        return <div className="max-w-[300px] truncate">{row.getValue("description")}</div>;
      },
    },
    {
      accessorKey: "reference",
      header: "Reference",
      cell: ({ row }: any) => {
        return <div>{row.getValue("reference") || '--'}</div>;
      },
    },
    {
      accessorKey: "type",
      header: "Type",
      cell: ({ row }: any) => {
        const type = row.getValue("type");
        return <div className="capitalize">{type}</div>;
      },
    },
    {
      accessorKey: "amount",
      header: "Amount",
      cell: ({ row }: any) => {
        const amount = row.getValue("amount");
        const type = row.original.type;
        const formattedAmount = type === 'deposit' ? formatCurrency(amount) : formatCurrency(-amount);
        
        return (
          <div className={`text-right font-mono ${type === 'deposit' ? 'text-success' : 'text-error'}`}>
            {formattedAmount}
          </div>
        );
      },
    },
    {
      accessorKey: "isReconciled",
      header: "Status",
      cell: ({ row }: any) => {
        const isReconciled = row.getValue("isReconciled");
        
        return (
          <div className="flex justify-end">
            {isReconciled ? (
              <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-success rounded">
                <Check className="h-3 w-3 mr-1" />
                Reconciled
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-neutral-light text-neutral-dark rounded">
                Unreconciled
              </span>
            )}
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => handleSelectRow(row.original.id.toString())}
                  disabled={row.original.isReconciled}
                >
                  <Check className="mr-2 h-4 w-4" />
                  <span>Select</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Bank Reconciliation</h1>
          <p className="text-neutral">Reconcile your bank accounts and transactions</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <CalendarRange className="h-4 w-4" />
            <span>Date Range</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button 
            className="flex items-center gap-2" 
            onClick={handleReconcile}
            disabled={selectedItems.length === 0}
          >
            <Check className="h-4 w-4" />
            <span>Reconcile Selected</span>
          </Button>
          <Button className="flex items-center gap-2" onClick={() => setShowTransactionDialog(true)}>
            <PlusCircle className="h-4 w-4" />
            <span>New Transaction</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="md:col-span-1 bg-white rounded-xl shadow-sm p-5">
          <h3 className="font-medium mb-4">Bank Accounts</h3>
          <div className="space-y-2">
            {accountsLoading ? (
              <p>Loading accounts...</p>
            ) : bankAccounts?.length === 0 ? (
              <p className="text-neutral">No bank accounts found</p>
            ) : (
              bankAccounts?.map((account: any) => (
                <div 
                  key={account.id} 
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${selectedAccount === account.id.toString() ? 'bg-primary-light bg-opacity-10 text-primary' : 'bg-neutral-lightest hover:bg-blue-50'}`}
                  onClick={() => setSelectedAccount(account.id.toString())}
                >
                  <div className="font-medium">{account.name}</div>
                  <div className="text-sm text-neutral">{account.accountNumber}</div>
                  <div className="font-mono mt-1">{formatCurrency(account.balance)}</div>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="md:col-span-3 space-y-6">
          {selectedAccount ? (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium text-neutral">Account Balance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-medium font-mono">{formatCurrency(balance)}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium text-neutral">Reconciled</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-medium font-mono text-success">{formatCurrency(reconciled)}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-base font-medium text-neutral">Unreconciled</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-medium font-mono text-primary">{formatCurrency(unreconciled)}</div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="bg-white rounded-xl shadow-sm p-5">
                <Tabs defaultValue="all">
                  <TabsList className="mb-4">
                    <TabsTrigger value="all">All Transactions</TabsTrigger>
                    <TabsTrigger value="unreconciled">Unreconciled</TabsTrigger>
                    <TabsTrigger value="reconciled">Reconciled</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="all" className="mt-0">
                    <DataTable
                      columns={columns}
                      data={transactionsLoading ? [] : bankTransactions || []}
                      searchColumn="description"
                      searchPlaceholder="Search transactions..."
                    />
                  </TabsContent>
                  
                  <TabsContent value="unreconciled" className="mt-0">
                    <DataTable
                      columns={columns}
                      data={transactionsLoading ? [] : bankTransactions?.filter((tx: any) => !tx.isReconciled) || []}
                      searchColumn="description"
                      searchPlaceholder="Search unreconciled transactions..."
                    />
                  </TabsContent>
                  
                  <TabsContent value="reconciled" className="mt-0">
                    <DataTable
                      columns={columns}
                      data={transactionsLoading ? [] : bankTransactions?.filter((tx: any) => tx.isReconciled) || []}
                      searchColumn="description"
                      searchPlaceholder="Search reconciled transactions..."
                    />
                  </TabsContent>
                </Tabs>
              </div>
            </>
          ) : (
            <div className="bg-white rounded-xl shadow-sm p-8 text-center">
              <h3 className="font-medium text-lg mb-2">Select a Bank Account</h3>
              <p className="text-neutral">Please select a bank account from the left to view transactions</p>
            </div>
          )}
        </div>
      </div>

      {/* Reconcile Confirmation Dialog */}
      <Dialog open={showReconcileDialog} onOpenChange={setShowReconcileDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Reconciliation</DialogTitle>
          </DialogHeader>
          
          <div className="py-4">
            <p>
              Are you sure you want to reconcile <span className="font-medium">{selectedItems.length}</span> transaction{selectedItems.length !== 1 ? 's' : ''}?
            </p>
            
            <div className="mt-4 p-3 bg-neutral-lightest rounded-lg">
              <div className="flex justify-between items-center">
                <span>Total transactions:</span>
                <span className="font-medium">{selectedItems.length}</span>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span>Total amount:</span>
                <span className="font-medium font-mono">
                  {formatCurrency(selectedItems.reduce((sum, id) => {
                    const tx = bankTransactions?.find((t: any) => t.id.toString() === id);
                    if (!tx) return sum;
                    return sum + (tx.type === 'deposit' ? tx.amount : -tx.amount);
                  }, 0) || 0)}
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowReconcileDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              type="button"
              onClick={() => reconcileTransactionsMutation.mutate(selectedItems)}
              disabled={reconcileTransactionsMutation.isPending}
            >
              {reconcileTransactionsMutation.isPending ? "Processing..." : "Confirm Reconciliation"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* New Transaction Dialog */}
      <Dialog open={showTransactionDialog} onOpenChange={setShowTransactionDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>New Bank Transaction</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="bankAccountId">Bank Account</Label>
              <Select defaultValue={selectedAccount || ""}>
                <SelectTrigger>
                  <SelectValue placeholder="Select bank account" />
                </SelectTrigger>
                <SelectContent>
                  {bankAccounts?.map((account: any) => (
                    <SelectItem key={account.id} value={account.id.toString()}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="type">Transaction Type</Label>
              <Select defaultValue="deposit">
                <SelectTrigger>
                  <SelectValue placeholder="Select transaction type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="deposit">Deposit</SelectItem>
                  <SelectItem value="withdrawal">Withdrawal</SelectItem>
                  <SelectItem value="transfer">Transfer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input id="description" placeholder="Enter transaction description" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="amount">Amount</Label>
              <Input id="amount" type="number" step="0.01" min="0.01" placeholder="0.00" />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="reference">Reference</Label>
              <Input id="reference" placeholder="Check number, transaction ID, etc." />
            </div>
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setShowTransactionDialog(false)}
            >
              Cancel
            </Button>
            <Button type="button">
              Save Transaction
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BankReconciliation;
