import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlusCircle, DownloadCloud, Filter, ChevronDown, Pencil, Eye, Search } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const GeneralLedger = () => {
  const [selectedEntry, setSelectedEntry] = useState<any>(null);
  const [showNewEntryDialog, setShowNewEntryDialog] = useState(false);
  const [accountFilter, setAccountFilter] = useState<string | null>(null);
  
  // Fetch journal entries
  const { data: journalEntries, isLoading: entriesLoading } = useQuery({
    queryKey: ['/api/journal-entries'],
  });

  // Fetch accounts
  const { data: accounts, isLoading: accountsLoading } = useQuery({
    queryKey: ['/api/accounts'],
  });

  // Define columns for DataTable
  const columns = [
    {
      accessorKey: "entryNumber",
      header: "Entry #",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("entryNumber")}</div>
        );
      },
    },
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "description",
      header: "Description",
      cell: ({ row }: any) => {
        return <div className="max-w-[300px] truncate">{row.getValue("description")}</div>;
      },
    },
    {
      accessorKey: "totalDebit",
      header: "Debit",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("totalDebit"))}</div>
        );
      },
    },
    {
      accessorKey: "totalCredit",
      header: "Credit",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("totalCredit"))}</div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => {
        const status = row.getValue("status");
        const { bg, text } = getStatusColor(status);
        
        return (
          <div className="text-right">
            <span className={`inline-flex items-center px-2 py-1 text-xs font-medium ${bg} ${text} rounded`}>
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </span>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSelectedEntry(row.original)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  <span>View</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pencil className="mr-2 h-4 w-4" />
                  <span>Edit</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  // Function to filter journal entries by account
  const getFilteredEntries = () => {
    if (!journalEntries || !accountFilter) return journalEntries;
    
    return journalEntries.filter((entry: any) => 
      entry.lines.some((line: any) => line.accountId === parseInt(accountFilter))
    );
  };

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">General Ledger</h1>
          <p className="text-neutral">View and manage all accounting entries</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <DownloadCloud className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button className="flex items-center gap-2" onClick={() => setShowNewEntryDialog(true)}>
            <PlusCircle className="h-4 w-4" />
            <span>New Journal Entry</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <div className="md:col-span-3">
          <div className="bg-white rounded-xl shadow-sm p-5">
            <Tabs defaultValue="entries">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-4">
                <TabsList>
                  <TabsTrigger value="entries">Journal Entries</TabsTrigger>
                  <TabsTrigger value="accounts">Chart of Accounts</TabsTrigger>
                </TabsList>
                
                <div className="flex mt-4 md:mt-0">
                  <Select onValueChange={setAccountFilter}>
                    <SelectTrigger className="w-[250px]">
                      <SelectValue placeholder="Filter by account" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Accounts</SelectItem>
                      {!accountsLoading && accounts?.map((account: any) => (
                        <SelectItem key={account.id} value={account.id.toString()}>
                          {account.code} - {account.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <TabsContent value="entries" className="mt-0">
                <DataTable
                  columns={columns}
                  data={entriesLoading ? [] : getFilteredEntries() || []}
                  searchColumn="description"
                  searchPlaceholder="Search journal entries..."
                />
              </TabsContent>
              
              <TabsContent value="accounts" className="mt-0">
                <div className="relative mb-4 max-w-sm">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-neutral" />
                  <Input className="pl-8" placeholder="Search accounts..." />
                </div>
                
                <table className="min-w-full">
                  <thead>
                    <tr className="text-left text-xs text-neutral border-b">
                      <th className="pb-3 font-medium">Code</th>
                      <th className="pb-3 font-medium">Name</th>
                      <th className="pb-3 font-medium">Type</th>
                      <th className="pb-3 font-medium text-right">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {accountsLoading ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center">Loading accounts...</td>
                      </tr>
                    ) : accounts?.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center">No accounts found</td>
                      </tr>
                    ) : (
                      accounts?.map((account: any) => (
                        <tr key={account.id} className="border-b border-neutral-light">
                          <td className="py-3 text-sm">{account.code}</td>
                          <td className="py-3 text-sm">{account.name}</td>
                          <td className="py-3 text-sm capitalize">{account.type.toLowerCase()}</td>
                          <td className="py-3 text-sm text-right font-mono">
                            {formatCurrency(account.balance)}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </TabsContent>
            </Tabs>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h3 className="font-medium mb-4">Account Summary</h3>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm text-neutral">Assets</h4>
              <p className="text-xl font-medium font-mono mt-1">
                {formatCurrency(accounts?.filter((a: any) => a.type === 'Asset')
                  .reduce((sum: number, a: any) => sum + a.balance, 0) || 0)}
              </p>
            </div>
            
            <div>
              <h4 className="text-sm text-neutral">Liabilities</h4>
              <p className="text-xl font-medium font-mono mt-1">
                {formatCurrency(accounts?.filter((a: any) => a.type === 'Liability')
                  .reduce((sum: number, a: any) => sum + a.balance, 0) || 0)}
              </p>
            </div>
            
            <div>
              <h4 className="text-sm text-neutral">Equity</h4>
              <p className="text-xl font-medium font-mono mt-1">
                {formatCurrency(accounts?.filter((a: any) => a.type === 'Equity')
                  .reduce((sum: number, a: any) => sum + a.balance, 0) || 0)}
              </p>
            </div>
            
            <div>
              <h4 className="text-sm text-neutral">Revenue</h4>
              <p className="text-xl font-medium font-mono mt-1">
                {formatCurrency(accounts?.filter((a: any) => a.type === 'Revenue')
                  .reduce((sum: number, a: any) => sum + a.balance, 0) || 0)}
              </p>
            </div>
            
            <div>
              <h4 className="text-sm text-neutral">Expenses</h4>
              <p className="text-xl font-medium font-mono mt-1">
                {formatCurrency(accounts?.filter((a: any) => a.type === 'Expense')
                  .reduce((sum: number, a: any) => sum + a.balance, 0) || 0)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* View Journal Entry Dialog */}
      <Dialog open={!!selectedEntry} onOpenChange={() => setSelectedEntry(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Journal Entry #{selectedEntry?.entryNumber}</DialogTitle>
          </DialogHeader>
          
          {selectedEntry && (
            <div className="p-4">
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="text-sm font-medium text-neutral">Date</h3>
                  <p>{formatDate(selectedEntry.date)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Status</h3>
                  <div className="mt-1">
                    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium ${getStatusColor(selectedEntry.status).bg} ${getStatusColor(selectedEntry.status).text} rounded`}>
                      {selectedEntry.status.charAt(0).toUpperCase() + selectedEntry.status.slice(1)}
                    </span>
                  </div>
                </div>
                <div className="col-span-2">
                  <h3 className="text-sm font-medium text-neutral">Description</h3>
                  <p>{selectedEntry.description}</p>
                </div>
              </div>

              <h3 className="text-sm font-medium text-neutral mb-2">Journal Lines</h3>
              <table className="min-w-full border border-neutral-light">
                <thead className="bg-neutral-lightest">
                  <tr>
                    <th className="py-2 px-3 text-left text-xs font-medium text-neutral-dark">Account</th>
                    <th className="py-2 px-3 text-left text-xs font-medium text-neutral-dark">Description</th>
                    <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Debit</th>
                    <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Credit</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-light">
                  {selectedEntry.lines?.map((line: any, index: number) => {
                    const account = accounts?.find((a: any) => a.id === line.accountId);
                    return (
                      <tr key={index} className="border-t border-neutral-light">
                        <td className="py-2 px-3 text-sm">
                          {account ? `${account.code} - ${account.name}` : `Account ${line.accountId}`}
                        </td>
                        <td className="py-2 px-3 text-sm">{line.description || '--'}</td>
                        <td className="py-2 px-3 text-sm text-right font-mono">{line.debit > 0 ? formatCurrency(line.debit) : '--'}</td>
                        <td className="py-2 px-3 text-sm text-right font-mono">{line.credit > 0 ? formatCurrency(line.credit) : '--'}</td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="bg-neutral-lightest font-medium">
                  <tr className="border-t-2 border-neutral">
                    <td className="py-2 px-3 text-sm" colSpan={2}>Totals</td>
                    <td className="py-2 px-3 text-sm text-right font-mono">{formatCurrency(selectedEntry.totalDebit)}</td>
                    <td className="py-2 px-3 text-sm text-right font-mono">{formatCurrency(selectedEntry.totalCredit)}</td>
                  </tr>
                </tfoot>
              </table>

              <div className="flex justify-end mt-6 gap-2">
                <Button variant="outline">Print</Button>
                {selectedEntry.status === 'draft' && (
                  <Button>Post Entry</Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* New Journal Entry Dialog - Basic structure */}
      <Dialog open={showNewEntryDialog} onOpenChange={setShowNewEntryDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>New Journal Entry</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="entryNumber">Entry Number</Label>
                <Input id="entryNumber" defaultValue={`JE-${new Date().getFullYear()}${(new Date().getMonth() + 1).toString().padStart(2, '0')}${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`} />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input id="date" type="date" defaultValue={new Date().toISOString().split('T')[0]} />
              </div>
              
              <div className="col-span-2 space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input id="description" placeholder="Enter a description for this journal entry" />
              </div>
            </div>
            
            <div>
              <Label className="mb-2 block">Journal Lines</Label>
              <table className="min-w-full border border-neutral-light">
                <thead className="bg-neutral-lightest">
                  <tr>
                    <th className="py-2 px-3 text-left text-xs font-medium text-neutral-dark">Account</th>
                    <th className="py-2 px-3 text-left text-xs font-medium text-neutral-dark">Description</th>
                    <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Debit</th>
                    <th className="py-2 px-3 text-right text-xs font-medium text-neutral-dark">Credit</th>
                    <th className="py-2 px-3 w-10"></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-2 px-3">
                      <Select>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Select account" />
                        </SelectTrigger>
                        <SelectContent>
                          {!accountsLoading && accounts?.map((account: any) => (
                            <SelectItem key={account.id} value={account.id.toString()}>
                              {account.code} - {account.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </td>
                    <td className="py-2 px-3">
                      <Input placeholder="Description" />
                    </td>
                    <td className="py-2 px-3">
                      <Input type="number" min="0" step="0.01" placeholder="0.00" />
                    </td>
                    <td className="py-2 px-3">
                      <Input type="number" min="0" step="0.01" placeholder="0.00" />
                    </td>
                    <td className="py-2 px-3 text-center">
                      <Button variant="ghost" size="icon" className="h-7 w-7">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                </tbody>
                <tfoot className="bg-neutral-lightest">
                  <tr>
                    <td colSpan={5} className="py-2 px-3">
                      <Button variant="outline" size="sm" className="w-full">
                        <PlusCircle className="h-4 w-4 mr-2" />
                        Add Line
                      </Button>
                    </td>
                  </tr>
                  <tr className="border-t border-neutral">
                    <td className="py-2 px-3 font-medium" colSpan={2}>Totals</td>
                    <td className="py-2 px-3 text-right font-medium font-mono">$0.00</td>
                    <td className="py-2 px-3 text-right font-medium font-mono">$0.00</td>
                    <td></td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-medium" colSpan={2}>Difference</td>
                    <td className="py-2 px-3 text-right font-medium text-error font-mono" colSpan={2}>$0.00</td>
                    <td></td>
                  </tr>
                </tfoot>
              </table>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowNewEntryDialog(false)}
              >
                Cancel
              </Button>
              <Button type="submit">
                Save Journal Entry
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GeneralLedger;
