import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PlusCircle, DownloadCloud, Filter, ChevronDown, Pencil, Trash2, AlertTriangle } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { InventoryForm } from "@/components/forms/inventory-form";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const Inventory = () => {
  const [showForm, setShowForm] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch inventory items
  const { data: inventoryItems, isLoading } = useQuery({
    queryKey: ['/api/inventory'],
  });

  const deleteItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/inventory/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Item deleted",
        description: "Inventory item has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/inventory'] });
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: `Failed to delete inventory item: ${error.message}`,
      });
    },
  });

  // Define columns for DataTable
  const columns = [
    {
      accessorKey: "code",
      header: "Code",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("code")}</div>
        );
      },
    },
    {
      accessorKey: "name",
      header: "Name",
      cell: ({ row }: any) => {
        return <div>{row.getValue("name")}</div>;
      },
    },
    {
      accessorKey: "quantityOnHand",
      header: "Quantity",
      cell: ({ row }: any) => {
        const quantity = row.getValue("quantityOnHand");
        const reorderLevel = row.original.reorderLevel;
        const lowStock = quantity <= reorderLevel;
        
        return (
          <div className="flex items-center">
            {lowStock && (
              <AlertTriangle className="h-4 w-4 text-amber-500 mr-1" />
            )}
            <span className={lowStock ? "text-amber-600" : ""}>{quantity}</span>
          </div>
        );
      },
    },
    {
      accessorKey: "costPrice",
      header: "Cost Price",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("costPrice"))}</div>
        );
      },
    },
    {
      accessorKey: "unitPrice",
      header: "Selling Price",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("unitPrice"))}</div>
        );
      },
    },
    {
      id: "profit",
      header: "Profit Margin",
      cell: ({ row }: any) => {
        const unitPrice = row.original.unitPrice;
        const costPrice = row.original.costPrice;
        const margin = costPrice > 0 ? ((unitPrice - costPrice) / costPrice) * 100 : 0;
        
        return (
          <div className="text-right">
            {margin.toFixed(2)}%
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => {
                    setSelectedItem(row.original);
                    setShowForm(true);
                  }}
                >
                  <Pencil className="mr-2 h-4 w-4" />
                  <span>Edit</span>
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => {
                    setItemToDelete(row.original);
                    setDeleteDialogOpen(true);
                  }}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  <span>Delete</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  const handleCloseForm = () => {
    setShowForm(false);
    setSelectedItem(null);
  };

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Inventory Management</h1>
          <p className="text-neutral">Track and manage your inventory items</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <DownloadCloud className="h-4 w-4" />
            <span>Export</span>
          </Button>
          <Button className="flex items-center gap-2" onClick={() => setShowForm(true)}>
            <PlusCircle className="h-4 w-4" />
            <span>Add Item</span>
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-5">
        <DataTable
          columns={columns}
          data={isLoading ? [] : inventoryItems || []}
          searchColumn="name"
          searchPlaceholder="Search items..."
        />
      </div>

      {/* Inventory Form Dialog */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <InventoryForm onSuccess={handleCloseForm} initialData={selectedItem} />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the inventory item "{itemToDelete?.name}". 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => itemToDelete && deleteItemMutation.mutate(itemToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteItemMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default Inventory;
