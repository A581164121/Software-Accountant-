import { useState } from "react";
import { 
  Card, 
  CardContent
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { RevenueExpensesChart, AccountsStatusChart } from "@/components/dashboard/chart-container";
import { 
  Wallet,
  TrendingUp,
  Receipt,
  Banknote,
  ArrowRight,
  CirclePlus,
  FileText,
  Package2,
  FileBarChart2,
  ShoppingCart
} from "lucide-react";
import { Link } from "wouter";

const Dashboard = () => {
  const [dateRange, setDateRange] = useState("quarter"); // month, quarter, year
  
  // Fetch dashboard data
  const { data: dashboardData, isLoading: loadingDashboard } = useQuery({
    queryKey: ['/api/dashboard', dateRange],
  });

  // Fetch recent transactions
  const { data: recentTransactions, isLoading: loadingTransactions } = useQuery({
    queryKey: ['/api/transactions/recent'],
  });
  
  // Chart data
  const revenueExpensesData = [
    { name: "Jan", revenue: 92000, expenses: 80000 },
    { name: "Feb", revenue: 98000, expenses: 85000 },
    { name: "Mar", revenue: 105000, expenses: 90000 },
    { name: "Apr", revenue: 110000, expenses: 88000 },
    { name: "May", revenue: 120000, expenses: 95000 },
    { name: "Jun", revenue: 128430, expenses: 94215 },
  ];

  // Skeleton loaders for cards
  const renderKpiSkeleton = () => (
    <Card className="animate-pulse">
      <CardContent className="pt-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <div className="h-4 w-16 bg-neutral-light rounded"></div>
            <div className="h-8 w-32 bg-neutral-light rounded mt-2"></div>
          </div>
          <div className="w-10 h-10 rounded-full bg-neutral-light"></div>
        </div>
        <div className="h-4 w-24 bg-neutral-light rounded"></div>
      </CardContent>
    </Card>
  );

  return (
    <div className="py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-medium text-neutral-dark">Financial Dashboard</h1>
        <p className="text-neutral">Overview of your financial performance</p>
      </div>

      {/* Date range selector and filters */}
      <div className="flex flex-wrap items-center justify-between mb-6 gap-4">
        <div className="inline-flex items-center bg-white border rounded-lg">
          <Button 
            variant={dateRange === "month" ? "default" : "ghost"} 
            className="px-4 py-2"
            onClick={() => setDateRange("month")}
          >
            Month
          </Button>
          <Button 
            variant={dateRange === "quarter" ? "default" : "ghost"} 
            className="px-4 py-2"
            onClick={() => setDateRange("quarter")}
          >
            Quarter
          </Button>
          <Button 
            variant={dateRange === "year" ? "default" : "ghost"} 
            className="px-4 py-2"
            onClick={() => setDateRange("year")}
          >
            Year
          </Button>
        </div>
        <div className="flex items-center">
          <span className="text-sm text-neutral mr-2">Current period:</span>
          <div className="inline-flex items-center bg-white border rounded-lg">
            <Button variant="ghost" className="px-4 py-2 flex items-center">
              <span>
                {dateRange === "month" && "Jun 1 - Jun 30, 2023"}
                {dateRange === "quarter" && "Apr 1 - Jun 30, 2023"}
                {dateRange === "year" && "Jan 1 - Dec 31, 2023"}
              </span>
            </Button>
          </div>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
        {loadingDashboard ? (
          <>
            {renderKpiSkeleton()}
            {renderKpiSkeleton()}
            {renderKpiSkeleton()}
            {renderKpiSkeleton()}
          </>
        ) : (
          <>
            <KpiCard
              title="Revenue"
              value={128430}
              percentageChange={8.2}
              comparisonText="vs last quarter"
              icon={<Receipt className="text-primary" />}
              delay={0}
            />
            
            <KpiCard
              title="Expenses"
              value={94215}
              percentageChange={12.4}
              comparisonText="vs last quarter"
              icon={<ShoppingCart className="text-error" />}
              iconBgClass="bg-error bg-opacity-10"
              delay={100}
            />
            
            <KpiCard
              title="Net Profit"
              value={34215}
              percentageChange={3.8}
              comparisonText="vs last quarter"
              icon={<TrendingUp className="text-success" />}
              iconBgClass="bg-success bg-opacity-10"
              delay={200}
            />
            
            <KpiCard
              title="Cash Position"
              value={215784}
              percentageChange={5.2}
              comparisonText="vs last quarter"
              icon={<Wallet className="text-amber-500" />}
              iconBgClass="bg-amber-500 bg-opacity-10"
              delay={300}
            />
          </>
        )}
      </div>

      {/* Revenue and expense chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Revenue & Expenses chart */}
        <div className="lg:col-span-2">
          <RevenueExpensesChart data={revenueExpensesData} />
        </div>

        {/* Accounts payable/receivable */}
        <AccountsStatusChart
          receivableTotal={42580}
          receivableCurrent={32150}
          receivableOverdue={10430}
          payableTotal={28320}
          payableCurrent={25620}
          payableOverdue={2700}
          inventoryValue={86450}
          stockItems={238}
          lowStock={15}
        />
      </div>

      {/* Recent transactions and quick actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent transactions */}
        <div className="bg-white rounded-xl shadow-sm p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-medium">Recent Transactions</h2>
            <Link href="/sales">
              <a className="text-primary text-sm flex items-center">
                View All
                <ArrowRight className="h-4 w-4 ml-1" />
              </a>
            </Link>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="text-left text-xs text-neutral border-b">
                  <th className="pb-3 font-medium">Date</th>
                  <th className="pb-3 font-medium">Description</th>
                  <th className="pb-3 font-medium">Type</th>
                  <th className="pb-3 font-medium text-right">Amount</th>
                  <th className="pb-3 font-medium text-right">Status</th>
                </tr>
              </thead>
              <tbody>
                {loadingTransactions ? (
                  // Skeleton loading for transactions
                  Array(5).fill(0).map((_, index) => (
                    <tr key={index} className="border-b border-neutral-light">
                      <td className="py-3">
                        <div className="h-4 w-16 bg-neutral-light rounded animate-pulse"></div>
                      </td>
                      <td className="py-3">
                        <div className="h-4 w-24 bg-neutral-light rounded animate-pulse"></div>
                      </td>
                      <td className="py-3">
                        <div className="h-6 w-16 bg-neutral-light rounded animate-pulse"></div>
                      </td>
                      <td className="py-3 text-right">
                        <div className="h-4 w-16 bg-neutral-light rounded ml-auto animate-pulse"></div>
                      </td>
                      <td className="py-3 text-right">
                        <div className="h-6 w-14 bg-neutral-light rounded ml-auto animate-pulse"></div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <>
                    <tr className="border-b border-neutral-light">
                      <td className="py-3 text-sm">Jun 24, 2023</td>
                      <td className="py-3 text-sm truncate max-w-[140px]">Tech Supplies Inc.</td>
                      <td className="py-3">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-blue-100 text-primary rounded">
                          Invoice
                        </span>
                      </td>
                      <td className="py-3 text-sm text-right font-mono">$2,156.00</td>
                      <td className="py-3 text-right">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-success rounded">
                          Paid
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-neutral-light">
                      <td className="py-3 text-sm">Jun 22, 2023</td>
                      <td className="py-3 text-sm truncate max-w-[140px]">Office Rent - June</td>
                      <td className="py-3">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-red-100 text-error rounded">
                          Expense
                        </span>
                      </td>
                      <td className="py-3 text-sm text-right font-mono">$3,500.00</td>
                      <td className="py-3 text-right">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-success rounded">
                          Paid
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-neutral-light">
                      <td className="py-3 text-sm">Jun 20, 2023</td>
                      <td className="py-3 text-sm truncate max-w-[140px]">Acme Corporation</td>
                      <td className="py-3">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-blue-100 text-primary rounded">
                          Invoice
                        </span>
                      </td>
                      <td className="py-3 text-sm text-right font-mono">$8,750.00</td>
                      <td className="py-3 text-right">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-amber-100 text-amber-700 rounded">
                          Pending
                        </span>
                      </td>
                    </tr>
                    
                    <tr className="border-b border-neutral-light">
                      <td className="py-3 text-sm">Jun 18, 2023</td>
                      <td className="py-3 text-sm truncate max-w-[140px]">Employee Payroll</td>
                      <td className="py-3">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-red-100 text-error rounded">
                          Expense
                        </span>
                      </td>
                      <td className="py-3 text-sm text-right font-mono">$12,450.00</td>
                      <td className="py-3 text-right">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-success rounded">
                          Paid
                        </span>
                      </td>
                    </tr>
                    
                    <tr>
                      <td className="py-3 text-sm">Jun 15, 2023</td>
                      <td className="py-3 text-sm truncate max-w-[140px]">Global Partners LLC</td>
                      <td className="py-3">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-blue-100 text-primary rounded">
                          Invoice
                        </span>
                      </td>
                      <td className="py-3 text-sm text-right font-mono">$5,240.00</td>
                      <td className="py-3 text-right">
                        <span className="inline-flex items-center px-2 py-1 text-xs font-medium bg-green-100 text-success rounded">
                          Paid
                        </span>
                      </td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>
        </div>
        
        {/* Quick actions */}
        <div className="bg-white rounded-xl shadow-sm p-5">
          <h2 className="font-medium mb-4">Quick Actions</h2>
          <div className="space-y-3">
            <Link href="/sales">
              <a className="flex items-center p-3 bg-neutral-lightest rounded-lg hover:bg-blue-50 hover:text-primary transition-colors">
                <div className="w-9 h-9 rounded-full bg-primary-light bg-opacity-20 flex items-center justify-center mr-3">
                  <CirclePlus className="text-primary h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">New Invoice</div>
                  <div className="text-xs text-neutral">Create a new sales invoice</div>
                </div>
              </a>
            </Link>
            
            <Link href="/accounts-receivable">
              <a className="flex items-center p-3 bg-neutral-lightest rounded-lg hover:bg-blue-50 hover:text-primary transition-colors">
                <div className="w-9 h-9 rounded-full bg-success bg-opacity-20 flex items-center justify-center mr-3">
                  <Receipt className="text-success h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">Record Payment</div>
                  <div className="text-xs text-neutral">Enter a received payment</div>
                </div>
              </a>
            </Link>
            
            <Link href="/inventory">
              <a className="flex items-center p-3 bg-neutral-lightest rounded-lg hover:bg-blue-50 hover:text-primary transition-colors">
                <div className="w-9 h-9 rounded-full bg-amber-500 bg-opacity-20 flex items-center justify-center mr-3">
                  <Package2 className="text-amber-500 h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">Add Inventory</div>
                  <div className="text-xs text-neutral">Register new inventory items</div>
                </div>
              </a>
            </Link>
            
            <Link href="/accounts-payable">
              <a className="flex items-center p-3 bg-neutral-lightest rounded-lg hover:bg-blue-50 hover:text-primary transition-colors">
                <div className="w-9 h-9 rounded-full bg-error bg-opacity-20 flex items-center justify-center mr-3">
                  <FileText className="text-error h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">Record Expense</div>
                  <div className="text-xs text-neutral">Enter a new expense</div>
                </div>
              </a>
            </Link>
            
            <Link href="/reports/profit-loss">
              <a className="flex items-center p-3 bg-neutral-lightest rounded-lg hover:bg-blue-50 hover:text-primary transition-colors">
                <div className="w-9 h-9 rounded-full bg-primary-dark bg-opacity-20 flex items-center justify-center mr-3">
                  <FileBarChart2 className="text-primary-dark h-5 w-5" />
                </div>
                <div>
                  <div className="font-medium">Generate Reports</div>
                  <div className="text-xs text-neutral">Financial statements and reports</div>
                </div>
              </a>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
