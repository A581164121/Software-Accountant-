import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PlusCircle, DownloadCloud, Filter, ChevronDown, Pencil, Trash2, Eye, Receipt, CreditCard } from "lucide-react";
import { DataTable } from "@/components/ui/data-table";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency, formatDate, getStatusColor } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const Receipts = () => {
  const [activeTab, setActiveTab] = useState("received");
  const [showPaymentReceivedForm, setShowPaymentReceivedForm] = useState(false);
  const [showPaymentMadeForm, setShowPaymentMadeForm] = useState(false);
  const [selectedReceipt, setSelectedReceipt] = useState<any>(null);
  
  // Fetch payments received
  const { data: paymentsReceived, isLoading: receivedLoading } = useQuery({
    queryKey: ['/api/payments/received'],
  });

  // Fetch payments made
  const { data: paymentsMade, isLoading: madeLoading } = useQuery({
    queryKey: ['/api/payments/made'],
  });

  // Define columns for Payments Received DataTable
  const receivedColumns = [
    {
      accessorKey: "receiptNumber",
      header: "Receipt #",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("receiptNumber")}</div>
        );
      },
    },
    {
      accessorKey: "customer",
      header: "Customer",
      cell: ({ row }: any) => {
        const customer = row.original.customer;
        return <div>{customer?.name || "Unknown Customer"}</div>;
      },
    },
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "paymentMethod",
      header: "Payment Method",
      cell: ({ row }: any) => {
        const method = row.getValue("paymentMethod");
        return <div className="capitalize">{method.replace('_', ' ')}</div>;
      },
    },
    {
      accessorKey: "amount",
      header: "Amount",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("amount"))}</div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSelectedReceipt(row.original)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  <span>View</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pencil className="mr-2 h-4 w-4" />
                  <span>Edit</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <DownloadCloud className="mr-2 h-4 w-4" />
                  <span>Download PDF</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  // Define columns for Payments Made DataTable
  const madeColumns = [
    {
      accessorKey: "paymentNumber",
      header: "Payment #",
      cell: ({ row }: any) => {
        return (
          <div className="font-medium">{row.getValue("paymentNumber")}</div>
        );
      },
    },
    {
      accessorKey: "vendor",
      header: "Vendor",
      cell: ({ row }: any) => {
        const vendor = row.original.vendor;
        return <div>{vendor?.name || "Unknown Vendor"}</div>;
      },
    },
    {
      accessorKey: "date",
      header: "Date",
      cell: ({ row }: any) => {
        return <div>{formatDate(row.getValue("date"))}</div>;
      },
    },
    {
      accessorKey: "paymentMethod",
      header: "Payment Method",
      cell: ({ row }: any) => {
        const method = row.getValue("paymentMethod");
        return <div className="capitalize">{method.replace('_', ' ')}</div>;
      },
    },
    {
      accessorKey: "amount",
      header: "Amount",
      cell: ({ row }: any) => {
        return (
          <div className="text-right font-mono">{formatCurrency(row.getValue("amount"))}</div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => {
        return (
          <div className="text-right">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setSelectedReceipt(row.original)}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  <span>View</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Pencil className="mr-2 h-4 w-4" />
                  <span>Edit</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <DownloadCloud className="mr-2 h-4 w-4" />
                  <span>Download PDF</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Cash & Purchase Receipts</h1>
          <p className="text-neutral">Manage receipts for payments received and made</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            <span>Filter</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <DownloadCloud className="h-4 w-4" />
            <span>Export</span>
          </Button>
          {activeTab === "received" ? (
            <Button className="flex items-center gap-2" onClick={() => setShowPaymentReceivedForm(true)}>
              <PlusCircle className="h-4 w-4" />
              <span>New Receipt</span>
            </Button>
          ) : (
            <Button className="flex items-center gap-2" onClick={() => setShowPaymentMadeForm(true)}>
              <PlusCircle className="h-4 w-4" />
              <span>New Payment</span>
            </Button>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-5">
        <Tabs defaultValue="received" onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="received" className="flex items-center gap-2">
              <Receipt className="h-4 w-4" />
              <span>Payments Received</span>
            </TabsTrigger>
            <TabsTrigger value="made" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              <span>Payments Made</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="received" className="mt-0">
            <DataTable
              columns={receivedColumns}
              data={receivedLoading ? [] : paymentsReceived || []}
              searchColumn="receiptNumber"
              searchPlaceholder="Search receipts..."
            />
          </TabsContent>
          
          <TabsContent value="made" className="mt-0">
            <DataTable
              columns={madeColumns}
              data={madeLoading ? [] : paymentsMade || []}
              searchColumn="paymentNumber"
              searchPlaceholder="Search payments..."
            />
          </TabsContent>
        </Tabs>
      </div>

      {/* View Receipt Dialog */}
      <Dialog open={!!selectedReceipt} onOpenChange={() => setSelectedReceipt(null)}>
        <DialogContent className="max-w-3xl">
          {selectedReceipt && (
            <div className="p-4">
              <h2 className="text-xl font-medium mb-4">
                {activeTab === "received" 
                  ? `Receipt #${selectedReceipt.receiptNumber}`
                  : `Payment #${selectedReceipt.paymentNumber}`
                }
              </h2>
              
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <h3 className="text-sm font-medium text-neutral">
                    {activeTab === "received" ? "Customer" : "Vendor"}
                  </h3>
                  <p>
                    {activeTab === "received" 
                      ? selectedReceipt.customer?.name || "Unknown Customer"
                      : selectedReceipt.vendor?.name || "Unknown Vendor"
                    }
                  </p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Date</h3>
                  <p>{formatDate(selectedReceipt.date)}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Payment Method</h3>
                  <p className="capitalize">{selectedReceipt.paymentMethod.replace('_', ' ')}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-neutral">Amount</h3>
                  <p className="font-mono">{formatCurrency(selectedReceipt.amount)}</p>
                </div>
                {selectedReceipt.reference && (
                  <div className="col-span-2">
                    <h3 className="text-sm font-medium text-neutral">Reference</h3>
                    <p>{selectedReceipt.reference}</p>
                  </div>
                )}
                {selectedReceipt.notes && (
                  <div className="col-span-2">
                    <h3 className="text-sm font-medium text-neutral">Notes</h3>
                    <p>{selectedReceipt.notes}</p>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline">
                  <DownloadCloud className="h-4 w-4 mr-2" />
                  Download PDF
                </Button>
                <Button>
                  <Pencil className="h-4 w-4 mr-2" />
                  Edit
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Receipts;
