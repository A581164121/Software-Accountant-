import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency } from "@/lib/utils";
import { CalendarRange, Download, Printer } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const ProfitLoss = () => {
  const [period, setPeriod] = useState("quarter");
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setMonth(new Date().getMonth() - 5)).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });
  const [compareWith, setCompareWith] = useState<string | null>(null);
  
  // Fetch profit & loss data
  const { data: plData, isLoading } = useQuery({
    queryKey: ['/api/reports/profit-loss', period, dateRange.start, dateRange.end, compareWith],
  });

  // Placeholder report data for demonstration
  const placeholderData = {
    period: period,
    startDate: dateRange.start,
    endDate: dateRange.end,
    revenue: {
      sales: 120540.00,
      serviceRevenue: 7890.00,
      otherRevenue: 0.00,
      totalRevenue: 128430.00,
    },
    costOfSales: {
      costOfGoods: 68250.00,
      directLabor: 7985.00,
      totalCostOfSales: 76235.00,
    },
    grossProfit: 52195.00,
    expenses: {
      salaries: 14850.00,
      rent: 3500.00,
      utilities: 980.00,
      officeSupplies: 650.00,
      marketing: 2500.00,
      insurance: 1200.00,
      depreciation: 1850.00,
      otherExpenses: 450.00,
      totalExpenses: 25980.00,
    },
    operatingIncome: 26215.00,
    otherIncome: {
      interestIncome: 0.00,
      totalOtherIncome: 0.00,
    },
    otherExpenses: {
      interestExpense: 2000.00,
      totalOtherExpenses: 2000.00,
    },
    netIncomeBeforeTax: 24215.00,
    incomeTax: {
      currentTax: 10000.00,
      totalTax: 10000.00,
    },
    netIncome: 14215.00,
    monthlyData: [
      { name: 'Jan', revenue: 108250, expenses: 92450, profit: 15800 },
      { name: 'Feb', revenue: 116420, expenses: 96780, profit: 19640 },
      { name: 'Mar', revenue: 112380, expenses: 99240, profit: 13140 },
      { name: 'Apr', revenue: 118650, expenses: 100850, profit: 17800 },
      { name: 'May', revenue: 122430, expenses: 97600, profit: 24830 },
      { name: 'Jun', revenue: 128430, expenses: 104215, profit: 24215 },
    ],
  };

  // For demonstration, use placeholder data if actual data is not loaded
  const reportData = isLoading ? placeholderData : (plData || placeholderData);
  
  // Format date for display
  const formatDisplayDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  // Helper function to get percentage of total
  const getPercentage = (value: number, total: number) => {
    return total > 0 ? ((value / total) * 100).toFixed(1) + '%' : '0.0%';
  };

  // Helper function to render a section of the profit and loss
  const renderSection = (title: string, items: Record<string, number>, total: number, showPercentage: boolean = true) => {
    return (
      <>
        {title && <h3 className="font-medium">{title}</h3>}
        {Object.entries(items).map(([key, value]) => {
          // Skip the total line, it will be handled separately
          if (key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1') // Add spaces before capital letters
            .replace(/^./, (str) => str.toUpperCase()); // Capitalize first letter
          
          return (
            <div key={key} className="flex justify-between py-1">
              <span className="pl-4">{formattedKey}</span>
              <div className="flex space-x-4">
                {showPercentage && (
                  <span className="text-neutral text-sm w-16 text-right">
                    {getPercentage(value, total)}
                  </span>
                )}
                <span className="font-mono w-28 text-right">{formatCurrency(value)}</span>
              </div>
            </div>
          );
        })}
        
        {/* Render total line */}
        {Object.entries(items).map(([key, value]) => {
          if (!key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, (str) => str.toUpperCase());
          
          return (
            <div key={key} className="flex justify-between py-1 font-medium border-t border-neutral-light mt-1">
              <span>{formattedKey}</span>
              <div className="flex space-x-4">
                {showPercentage && (
                  <span className="text-neutral text-sm w-16 text-right">
                    {getPercentage(value, total)}
                  </span>
                )}
                <span className="font-mono w-28 text-right">{formatCurrency(value)}</span>
              </div>
            </div>
          );
        })}
      </>
    );
  };

  // Helper function to render a summary line
  const renderSummaryLine = (title: string, value: number, total: number, isBold: boolean = false) => {
    return (
      <div className={`flex justify-between py-1 ${isBold ? 'font-bold text-lg border-t-2 border-neutral' : 'font-medium border-t border-neutral-light'}`}>
        <span>{title}</span>
        <div className="flex space-x-4">
          <span className="text-neutral text-sm w-16 text-right">
            {getPercentage(value, total)}
          </span>
          <span className="font-mono w-28 text-right">{formatCurrency(value)}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Profit & Loss Statement</h1>
          <p className="text-neutral">Income statement for the selected period</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <Button 
              variant={period === "month" ? "default" : "outline"} 
              onClick={() => setPeriod("month")}
            >
              Month
            </Button>
            <Button 
              variant={period === "quarter" ? "default" : "outline"} 
              onClick={() => setPeriod("quarter")}
            >
              Quarter
            </Button>
            <Button 
              variant={period === "year" ? "default" : "outline"} 
              onClick={() => setPeriod("year")}
            >
              Year
            </Button>
          </div>
          <Select value={compareWith || ""} onValueChange={setCompareWith}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Compare with..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">No comparison</SelectItem>
              <SelectItem value="previous-period">Previous Period</SelectItem>
              <SelectItem value="previous-year">Previous Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="flex items-center gap-2">
            <Printer className="h-4 w-4" />
            <span>Print</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-white p-6 lg:col-span-2">
          <CardContent className="p-0">
            <div className="mb-4">
              <h2 className="text-xl font-medium">Profit & Loss Statement</h2>
              <p className="text-neutral">
                {formatDisplayDate(reportData.startDate)} to {formatDisplayDate(reportData.endDate)}
              </p>
            </div>

            <div className="h-64 mb-6">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={reportData.monthlyData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value) => `$${value/1000}k`} />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" name="Revenue" stroke="#1976D2" activeDot={{ r: 8 }} />
                  <Line type="monotone" dataKey="expenses" name="Expenses" stroke="#D32F2F" />
                  <Line type="monotone" dataKey="profit" name="Profit" stroke="#4CAF50" />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-6">
              {/* Revenue */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Revenue</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("", reportData.revenue, reportData.revenue.totalRevenue)}
                </div>
              </div>

              {/* Cost of Sales */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Cost of Sales</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("", reportData.costOfSales, reportData.revenue.totalRevenue)}
                </div>
              </div>

              {/* Gross Profit */}
              <div>
                {renderSummaryLine("Gross Profit", reportData.grossProfit, reportData.revenue.totalRevenue)}
              </div>

              {/* Operating Expenses */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Operating Expenses</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("", reportData.expenses, reportData.revenue.totalRevenue)}
                </div>
              </div>

              {/* Operating Income */}
              <div>
                {renderSummaryLine("Operating Income", reportData.operatingIncome, reportData.revenue.totalRevenue)}
              </div>

              {/* Other Income */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Other Income & Expenses</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("Other Income", reportData.otherIncome, reportData.revenue.totalRevenue)}
                  {renderSection("Other Expenses", reportData.otherExpenses, reportData.revenue.totalRevenue)}
                </div>
              </div>

              {/* Net Income Before Tax */}
              <div>
                {renderSummaryLine("Net Income Before Tax", reportData.netIncomeBeforeTax, reportData.revenue.totalRevenue)}
              </div>

              {/* Income Tax */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Income Tax</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("", reportData.incomeTax, reportData.revenue.totalRevenue)}
                </div>
              </div>

              {/* Net Income */}
              <div>
                {renderSummaryLine("Net Income", reportData.netIncome, reportData.revenue.totalRevenue, true)}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="bg-white p-6">
            <CardContent className="p-0">
              <h3 className="font-medium mb-4">Financial Metrics</h3>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-neutral">Gross Profit Margin</div>
                  <div className="flex items-center justify-between mt-1">
                    <div className="text-xl font-medium">
                      {((reportData.grossProfit / reportData.revenue.totalRevenue) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-success">
                      +2.4% vs prev.
                    </div>
                  </div>
                  <div className="h-2 bg-neutral-light rounded-full mt-2">
                    <div 
                      className="h-2 bg-primary rounded-full" 
                      style={{ width: `${(reportData.grossProfit / reportData.revenue.totalRevenue) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-neutral">Operating Profit Margin</div>
                  <div className="flex items-center justify-between mt-1">
                    <div className="text-xl font-medium">
                      {((reportData.operatingIncome / reportData.revenue.totalRevenue) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-success">
                      +1.8% vs prev.
                    </div>
                  </div>
                  <div className="h-2 bg-neutral-light rounded-full mt-2">
                    <div 
                      className="h-2 bg-primary rounded-full" 
                      style={{ width: `${(reportData.operatingIncome / reportData.revenue.totalRevenue) * 100}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="text-sm text-neutral">Net Profit Margin</div>
                  <div className="flex items-center justify-between mt-1">
                    <div className="text-xl font-medium">
                      {((reportData.netIncome / reportData.revenue.totalRevenue) * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-success">
                      +1.2% vs prev.
                    </div>
                  </div>
                  <div className="h-2 bg-neutral-light rounded-full mt-2">
                    <div 
                      className="h-2 bg-primary rounded-full" 
                      style={{ width: `${(reportData.netIncome / reportData.revenue.totalRevenue) * 100}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white p-6">
            <CardContent className="p-0">
              <h3 className="font-medium mb-4">Expense Breakdown</h3>
              <div className="space-y-4">
                {Object.entries(reportData.expenses).map(([key, value]) => {
                  if (key.toLowerCase().includes('total')) return null;
                  
                  const formattedKey = key
                    .replace(/([A-Z])/g, ' $1')
                    .replace(/^./, (str) => str.toUpperCase());
                  
                  return (
                    <div key={key}>
                      <div className="flex items-center justify-between text-sm">
                        <span>{formattedKey}</span>
                        <div className="flex items-center">
                          <span className="font-mono mr-3">{formatCurrency(value)}</span>
                          <span className="text-neutral w-12 text-right">
                            {getPercentage(value, reportData.expenses.totalExpenses)}
                          </span>
                        </div>
                      </div>
                      <div className="h-2 bg-neutral-light rounded-full mt-1">
                        <div 
                          className="h-2 bg-error bg-opacity-70 rounded-full" 
                          style={{ width: `${(value / reportData.expenses.totalExpenses) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}

                <div className="pt-2 border-t border-neutral-light">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Total Expenses</span>
                    <span className="font-mono font-medium">{formatCurrency(reportData.expenses.totalExpenses)}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white p-6">
            <CardContent className="p-0">
              <h3 className="font-medium mb-4">Profit Summary</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Revenue</span>
                  <span className="font-mono">{formatCurrency(reportData.revenue.totalRevenue)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Cost of Sales</span>
                  <span className="font-mono text-error">({formatCurrency(reportData.costOfSales.totalCostOfSales)})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Gross Profit</span>
                  <span className="font-mono font-medium">{formatCurrency(reportData.grossProfit)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Operating Expenses</span>
                  <span className="font-mono text-error">({formatCurrency(reportData.expenses.totalExpenses)})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Operating Income</span>
                  <span className="font-mono font-medium">{formatCurrency(reportData.operatingIncome)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Other Expenses (Net)</span>
                  <span className="font-mono text-error">({formatCurrency(reportData.otherExpenses.totalOtherExpenses - reportData.otherIncome.totalOtherIncome)})</span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Income Tax</span>
                  <span className="font-mono text-error">({formatCurrency(reportData.incomeTax.totalTax)})</span>
                </div>
                <div className="flex items-center justify-between pt-2 border-t border-neutral font-medium">
                  <span>Net Income</span>
                  <span className="font-mono text-success">{formatCurrency(reportData.netIncome)}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ProfitLoss;
