import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency } from "@/lib/utils";
import { CalendarRange, Download, Printer, TrendingUp, TrendingDown, ArrowRight } from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const CashFlow = () => {
  const [period, setPeriod] = useState("month");
  const [dateRange, setDateRange] = useState({
    start: new Date(new Date().setMonth(new Date().getMonth() - 5)).toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });
  
  // Fetch cash flow data
  const { data: cashFlowData, isLoading } = useQuery({
    queryKey: ['/api/reports/cash-flow', period, dateRange.start, dateRange.end],
  });

  // Placeholder report data for demonstration
  const placeholderData = {
    period: period,
    startDate: dateRange.start,
    endDate: dateRange.end,
    summary: {
      startingBalance: 180569.20,
      endingBalance: 215784.00,
      netCashFlow: 35214.80,
    },
    operations: {
      inflows: {
        receivedFromCustomers: 132450.00,
        otherOperatingInflows: 5280.00,
        totalOperatingInflows: 137730.00,
      },
      outflows: {
        paidToSuppliers: 62580.00,
        paidToEmployees: 12450.00,
        otherOperatingOutflows: 8750.00,
        totalOperatingOutflows: 83780.00,
      },
      netCashFromOperations: 53950.00,
    },
    investing: {
      inflows: {
        saleOfEquipment: 0.00,
        totalInvestingInflows: 0.00,
      },
      outflows: {
        purchaseOfEquipment: 15000.00,
        totalInvestingOutflows: 15000.00,
      },
      netCashFromInvesting: -15000.00,
    },
    financing: {
      inflows: {
        proceedsFromLoans: 0.00,
        totalFinancingInflows: 0.00,
      },
      outflows: {
        loanRepayments: 3735.20,
        totalFinancingOutflows: 3735.20,
      },
      netCashFromFinancing: -3735.20,
    },
    monthlyData: [
      { name: 'Jan', operations: 8250, investing: -2000, financing: -800 },
      { name: 'Feb', operations: 9120, investing: -1500, financing: -800 },
      { name: 'Mar', operations: 10500, investing: -1000, financing: -800 },
      { name: 'Apr', operations: 11340, investing: -3500, financing: -520 },
      { name: 'May', operations: 11890, investing: -3000, financing: -520 },
      { name: 'Jun', operations: 12850, investing: -4000, financing: -520 },
    ],
  };

  // For demonstration, use placeholder data if actual data is not loaded
  const reportData = isLoading ? placeholderData : (cashFlowData || placeholderData);
  
  // Format date for display
  const formatDisplayDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  // Helper function to calculate the net value color
  const getValueColor = (value: number) => {
    return value >= 0 ? "text-success" : "text-error";
  };

  // Helper function to render a section of the cash flow
  const renderSection = (title: string, items: Record<string, number>, isInflow: boolean = true) => {
    return (
      <>
        {title && <h3 className="font-medium">{title}</h3>}
        {Object.entries(items).map(([key, value]) => {
          // Skip the total line, it will be handled separately
          if (key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1') // Add spaces before capital letters
            .replace(/^./, (str) => str.toUpperCase()) // Capitalize first letter
            .replace('From', 'from')
            .replace('To', 'to');
          
          return (
            <div key={key} className="flex justify-between py-1">
              <span className="pl-4">{formattedKey}</span>
              <span className={`font-mono ${isInflow ? "text-success" : "text-error"}`}>
                {isInflow ? formatCurrency(value) : `(${formatCurrency(value)})`}
              </span>
            </div>
          );
        })}
        
        {/* Render total line */}
        {Object.entries(items).map(([key, value]) => {
          if (!key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, (str) => str.toUpperCase());
          
          return (
            <div key={key} className="flex justify-between py-1 font-medium border-t border-neutral-light mt-1">
              <span>{formattedKey}</span>
              <span className={`font-mono ${isInflow ? "text-success" : "text-error"}`}>
                {isInflow ? formatCurrency(value) : `(${formatCurrency(value)})`}
              </span>
            </div>
          );
        })}
      </>
    );
  };

  // Helper function to render a net section
  const renderNetSection = (title: string, value: number) => {
    return (
      <div className="flex justify-between py-2 font-medium border-t border-neutral mt-1">
        <span>{title}</span>
        <span className={`font-mono ${getValueColor(value)}`}>
          {value >= 0 ? formatCurrency(value) : `(${formatCurrency(Math.abs(value))})`}
        </span>
      </div>
    );
  };

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Cash Flow Statement</h1>
          <p className="text-neutral">Analysis of cash inflows and outflows</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <Button 
              variant={period === "month" ? "default" : "outline"} 
              onClick={() => setPeriod("month")}
            >
              Month
            </Button>
            <Button 
              variant={period === "quarter" ? "default" : "outline"} 
              onClick={() => setPeriod("quarter")}
            >
              Quarter
            </Button>
            <Button 
              variant={period === "year" ? "default" : "outline"} 
              onClick={() => setPeriod("year")}
            >
              Year
            </Button>
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <CalendarRange className="h-4 w-4" />
            <span>Date Range</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Printer className="h-4 w-4" />
            <span>Print</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="bg-white p-6 lg:col-span-2">
          <CardContent className="p-0">
            <div className="mb-4">
              <h2 className="text-xl font-medium">Cash Flow Statement</h2>
              <p className="text-neutral">
                {formatDisplayDate(reportData.startDate)} to {formatDisplayDate(reportData.endDate)}
              </p>
            </div>

            <div className="h-64 mb-6">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={reportData.monthlyData}
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis tickFormatter={(value) => `$${value/1000}k`} />
                  <Tooltip formatter={(value) => formatCurrency(Number(value))} />
                  <Legend />
                  <Bar dataKey="operations" name="Operating" fill="#4caf50" />
                  <Bar dataKey="investing" name="Investing" fill="#ff9800" />
                  <Bar dataKey="financing" name="Financing" fill="#2196f3" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-6">
              {/* Summary */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Summary</h2>
                <div className="space-y-2 mt-3">
                  <div className="flex justify-between py-1">
                    <span className="pl-4">Starting Cash Balance</span>
                    <span className="font-mono">{formatCurrency(reportData.summary.startingBalance)}</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="pl-4">Net Cash Flow</span>
                    <span className={`font-mono ${getValueColor(reportData.summary.netCashFlow)}`}>
                      {reportData.summary.netCashFlow >= 0 
                        ? formatCurrency(reportData.summary.netCashFlow) 
                        : `(${formatCurrency(Math.abs(reportData.summary.netCashFlow))})`}
                    </span>
                  </div>
                  <div className="flex justify-between py-1 font-medium border-t border-neutral-light mt-1">
                    <span>Ending Cash Balance</span>
                    <span className="font-mono">{formatCurrency(reportData.summary.endingBalance)}</span>
                  </div>
                </div>
              </div>

              {/* Operating Activities */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Operating Activities</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("Cash Inflows", reportData.operations.inflows, true)}
                  {renderSection("Cash Outflows", reportData.operations.outflows, false)}
                  {renderNetSection("Net Cash from Operating Activities", reportData.operations.netCashFromOperations)}
                </div>
              </div>

              {/* Investing Activities */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Investing Activities</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("Cash Inflows", reportData.investing.inflows, true)}
                  {renderSection("Cash Outflows", reportData.investing.outflows, false)}
                  {renderNetSection("Net Cash from Investing Activities", reportData.investing.netCashFromInvesting)}
                </div>
              </div>

              {/* Financing Activities */}
              <div>
                <h2 className="text-lg font-medium text-primary border-b pb-1">Financing Activities</h2>
                <div className="space-y-2 mt-3">
                  {renderSection("Cash Inflows", reportData.financing.inflows, true)}
                  {renderSection("Cash Outflows", reportData.financing.outflows, false)}
                  {renderNetSection("Net Cash from Financing Activities", reportData.financing.netCashFromFinancing)}
                </div>
              </div>

              {/* Total Net Cash Flow */}
              <div className="flex justify-between py-2 font-bold border-t-2 border-neutral text-lg">
                <span>Net Increase (Decrease) in Cash</span>
                <span className={`font-mono ${getValueColor(reportData.summary.netCashFlow)}`}>
                  {reportData.summary.netCashFlow >= 0 
                    ? formatCurrency(reportData.summary.netCashFlow) 
                    : `(${formatCurrency(Math.abs(reportData.summary.netCashFlow))})`}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <Card className="bg-white p-6">
            <CardContent className="p-0">
              <h3 className="font-medium mb-4">Cash Flow Summary</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-9 h-9 rounded-full bg-success bg-opacity-20 flex items-center justify-center mr-3">
                      <TrendingUp className="text-success h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm text-neutral">Operating</div>
                      <div className="font-medium font-mono">{formatCurrency(reportData.operations.netCashFromOperations)}</div>
                    </div>
                  </div>
                  {reportData.operations.netCashFromOperations >= 0 ? (
                    <ArrowRight className="text-success h-5 w-5" />
                  ) : (
                    <ArrowRight className="text-error h-5 w-5" />
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-9 h-9 rounded-full bg-amber-500 bg-opacity-20 flex items-center justify-center mr-3">
                      <TrendingDown className="text-amber-500 h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm text-neutral">Investing</div>
                      <div className="font-medium font-mono">
                        {reportData.investing.netCashFromInvesting >= 0 
                          ? formatCurrency(reportData.investing.netCashFromInvesting) 
                          : `(${formatCurrency(Math.abs(reportData.investing.netCashFromInvesting))})`}
                      </div>
                    </div>
                  </div>
                  {reportData.investing.netCashFromInvesting >= 0 ? (
                    <ArrowRight className="text-success h-5 w-5" />
                  ) : (
                    <ArrowRight className="text-error h-5 w-5" />
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-9 h-9 rounded-full bg-primary bg-opacity-20 flex items-center justify-center mr-3">
                      <TrendingDown className="text-primary h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm text-neutral">Financing</div>
                      <div className="font-medium font-mono">
                        {reportData.financing.netCashFromFinancing >= 0 
                          ? formatCurrency(reportData.financing.netCashFromFinancing) 
                          : `(${formatCurrency(Math.abs(reportData.financing.netCashFromFinancing))})`}
                      </div>
                    </div>
                  </div>
                  {reportData.financing.netCashFromFinancing >= 0 ? (
                    <ArrowRight className="text-success h-5 w-5" />
                  ) : (
                    <ArrowRight className="text-error h-5 w-5" />
                  )}
                </div>

                <div className="pt-4 border-t border-neutral-light">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className={`w-9 h-9 rounded-full ${reportData.summary.netCashFlow >= 0 ? 'bg-success bg-opacity-20' : 'bg-error bg-opacity-20'} flex items-center justify-center mr-3`}>
                        {reportData.summary.netCashFlow >= 0 ? (
                          <TrendingUp className="text-success h-5 w-5" />
                        ) : (
                          <TrendingDown className="text-error h-5 w-5" />
                        )}
                      </div>
                      <div>
                        <div className="text-sm text-neutral">Net Cash Flow</div>
                        <div className={`font-medium font-mono ${getValueColor(reportData.summary.netCashFlow)}`}>
                          {reportData.summary.netCashFlow >= 0 
                            ? formatCurrency(reportData.summary.netCashFlow) 
                            : `(${formatCurrency(Math.abs(reportData.summary.netCashFlow))})`}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white p-6">
            <CardContent className="p-0">
              <h3 className="font-medium mb-4">Cash Position</h3>
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-neutral">Starting Balance</div>
                  <div className="text-xl font-medium font-mono mt-1">{formatCurrency(reportData.summary.startingBalance)}</div>
                </div>
                
                <div className="h-2 bg-neutral-light rounded-full">
                  <div 
                    className={`h-2 rounded-full ${reportData.summary.netCashFlow >= 0 ? 'bg-success' : 'bg-error'}`} 
                    style={{ 
                      width: `${Math.min(
                        Math.abs(reportData.summary.netCashFlow) / reportData.summary.startingBalance * 100, 
                        100
                      )}%` 
                    }}
                  ></div>
                </div>
                
                <div>
                  <div className="text-sm text-neutral">Ending Balance</div>
                  <div className="text-xl font-medium font-mono mt-1">{formatCurrency(reportData.summary.endingBalance)}</div>
                </div>
                
                <div className="pt-4 border-t border-neutral-light">
                  <div className="text-sm text-neutral">Change</div>
                  <div className={`text-xl font-medium font-mono mt-1 ${getValueColor(reportData.summary.netCashFlow)}`}>
                    {reportData.summary.netCashFlow >= 0 
                      ? `+${formatCurrency(reportData.summary.netCashFlow)}` 
                      : `-${formatCurrency(Math.abs(reportData.summary.netCashFlow))}`}
                  </div>
                  <div className={`text-sm ${getValueColor(reportData.summary.netCashFlow)}`}>
                    {((reportData.summary.netCashFlow / reportData.summary.startingBalance) * 100).toFixed(2)}%
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default CashFlow;
