import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCurrency } from "@/lib/utils";
import { CalendarRange, Download, Printer } from "lucide-react";

const BalanceSheet = () => {
  const [asOfDate, setAsOfDate] = useState(new Date().toISOString().split('T')[0]);
  const [compareWith, setCompareWith] = useState<string | null>(null);
  
  // Fetch balance sheet data
  const { data: balanceSheetData, isLoading } = useQuery({
    queryKey: ['/api/reports/balance-sheet', asOfDate, compareWith],
  });

  // Placeholder report data for demonstration
  const placeholderData = {
    asOfDate: asOfDate,
    assets: {
      currentAssets: {
        cash: 145629.78,
        accountsReceivable: 42580.00,
        inventory: 86450.00,
        otherCurrentAssets: 12500.00,
        totalCurrentAssets: 287159.78,
      },
      fixedAssets: {
        propertyAndEquipment: 275000.00,
        accumulatedDepreciation: -45000.00,
        totalFixedAssets: 230000.00,
      },
      totalAssets: 517159.78,
    },
    liabilities: {
      currentLiabilities: {
        accountsPayable: 28320.00,
        shortTermDebt: 15000.00,
        accruedExpenses: 8500.00,
        totalCurrentLiabilities: 51820.00,
      },
      longTermLiabilities: {
        longTermDebt: 120000.00,
        totalLongTermLiabilities: 120000.00,
      },
      totalLiabilities: 171820.00,
    },
    equity: {
      capitalStock: 150000.00,
      retainedEarnings: 161124.78,
      currentYearEarnings: 34215.00,
      totalEquity: 345339.78,
    },
    totalLiabilitiesAndEquity: 517159.78,
  };

  // For demonstration, use placeholder data if actual data is not loaded
  const reportData = isLoading ? placeholderData : (balanceSheetData || placeholderData);

  // Format date for display
  const formatDisplayDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  // Helper function to render a section of the balance sheet
  const renderSection = (title: string, items: Record<string, number>, isTotal: boolean = false) => {
    return (
      <>
        {title && <h3 className={`font-medium ${isTotal ? "pt-2" : ""}`}>{title}</h3>}
        {Object.entries(items).map(([key, value]) => {
          // Skip the total line, it will be handled separately
          if (key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1') // Add spaces before capital letters
            .replace(/^./, (str) => str.toUpperCase()) // Capitalize first letter
            .replace('And', '&'); // Replace 'And' with '&'
          
          return (
            <div key={key} className="flex justify-between py-1">
              <span className="pl-4">{formattedKey}</span>
              <span className="font-mono">{formatCurrency(value)}</span>
            </div>
          );
        })}
        
        {/* Render total line */}
        {Object.entries(items).map(([key, value]) => {
          if (!key.toLowerCase().includes('total')) return null;
          
          const formattedKey = key
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, (str) => str.toUpperCase());
          
          return (
            <div key={key} className="flex justify-between py-1 font-medium border-t border-neutral-light mt-1">
              <span>{formattedKey}</span>
              <span className="font-mono">{formatCurrency(value)}</span>
            </div>
          );
        })}
      </>
    );
  };

  return (
    <div className="py-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-medium text-neutral-dark">Balance Sheet</h1>
          <p className="text-neutral">Statement of financial position</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2">
            <span className="text-sm">As of:</span>
            <input
              type="date"
              value={asOfDate}
              onChange={(e) => setAsOfDate(e.target.value)}
              className="px-3 py-2 border rounded-lg"
            />
          </div>
          <Select value={compareWith || ""} onValueChange={setCompareWith}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Compare with..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">No comparison</SelectItem>
              <SelectItem value="previous-month">Previous Month</SelectItem>
              <SelectItem value="previous-quarter">Previous Quarter</SelectItem>
              <SelectItem value="previous-year">Previous Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="flex items-center gap-2">
            <Printer className="h-4 w-4" />
            <span>Print</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            <span>Export</span>
          </Button>
        </div>
      </div>

      <Card className="bg-white p-6">
        <CardContent className="p-0">
          <div className="mb-4 text-center">
            <h2 className="text-xl font-medium">Balance Sheet</h2>
            <p>As of {formatDisplayDate(asOfDate)}</p>
          </div>

          <div className="space-y-6">
            {/* Assets */}
            <div>
              <h2 className="text-lg font-medium text-primary border-b pb-1">Assets</h2>
              <div className="space-y-4 mt-3">
                {renderSection("Current Assets", reportData.assets.currentAssets)}
                {renderSection("Fixed Assets", reportData.assets.fixedAssets)}
                <div className="flex justify-between py-1 font-medium border-t border-neutral mt-1">
                  <span>Total Assets</span>
                  <span className="font-mono">{formatCurrency(reportData.assets.totalAssets)}</span>
                </div>
              </div>
            </div>

            {/* Liabilities */}
            <div>
              <h2 className="text-lg font-medium text-primary border-b pb-1">Liabilities</h2>
              <div className="space-y-4 mt-3">
                {renderSection("Current Liabilities", reportData.liabilities.currentLiabilities)}
                {renderSection("Long Term Liabilities", reportData.liabilities.longTermLiabilities)}
                <div className="flex justify-between py-1 font-medium border-t border-neutral mt-1">
                  <span>Total Liabilities</span>
                  <span className="font-mono">{formatCurrency(reportData.liabilities.totalLiabilities)}</span>
                </div>
              </div>
            </div>

            {/* Equity */}
            <div>
              <h2 className="text-lg font-medium text-primary border-b pb-1">Equity</h2>
              <div className="space-y-4 mt-3">
                <div className="flex justify-between py-1">
                  <span className="pl-4">Capital Stock</span>
                  <span className="font-mono">{formatCurrency(reportData.equity.capitalStock)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="pl-4">Retained Earnings</span>
                  <span className="font-mono">{formatCurrency(reportData.equity.retainedEarnings)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span className="pl-4">Current Year Earnings</span>
                  <span className="font-mono">{formatCurrency(reportData.equity.currentYearEarnings)}</span>
                </div>
                <div className="flex justify-between py-1 font-medium border-t border-neutral-light mt-1">
                  <span>Total Equity</span>
                  <span className="font-mono">{formatCurrency(reportData.equity.totalEquity)}</span>
                </div>
              </div>
            </div>

            {/* Total Liabilities and Equity */}
            <div className="flex justify-between py-2 font-bold border-t-2 border-neutral text-lg">
              <span>Total Liabilities and Equity</span>
              <span className="font-mono">{formatCurrency(reportData.totalLiabilitiesAndEquity)}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BalanceSheet;
