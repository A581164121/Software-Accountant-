import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format currency with proper locale and currency symbol
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

// Format date to a readable format
export function formatDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  return new Intl.DateTimeFormat('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(dateObj);
}

// Generate a unique ID with a prefix
export function generateId(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).substring(2, 9)}`;
}

// Calculate the total of an array of numbers
export function calculateTotal(amounts: number[]): number {
  return amounts.reduce((sum, amount) => sum + amount, 0);
}

// Format percentage
export function formatPercentage(value: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'percent',
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(value / 100);
}

// Calculate the percentage change between two values
export function calculatePercentageChange(oldValue: number, newValue: number): number {
  if (oldValue === 0) return newValue > 0 ? 100 : 0;
  return ((newValue - oldValue) / Math.abs(oldValue)) * 100;
}

// Get status color based on payment status
export function getStatusColor(status: string): Record<string, string> {
  const statusMap: Record<string, Record<string, string>> = {
    paid: { bg: 'bg-green-100', text: 'text-success' },
    draft: { bg: 'bg-neutral-light', text: 'text-neutral-dark' },
    sent: { bg: 'bg-blue-100', text: 'text-primary' },
    overdue: { bg: 'bg-red-100', text: 'text-error' },
    pending: { bg: 'bg-amber-100', text: 'text-amber-700' },
    cancelled: { bg: 'bg-neutral-light', text: 'text-neutral' },
    received: { bg: 'bg-blue-100', text: 'text-primary' },
    posted: { bg: 'bg-green-100', text: 'text-success' },
    archived: { bg: 'bg-neutral-light', text: 'text-neutral' },
  };
  
  return statusMap[status.toLowerCase()] || { bg: 'bg-neutral-light', text: 'text-neutral-dark' };
}

// Generate financial period labels for reports
export function generatePeriodLabels(periods: number, periodType: 'month' | 'quarter' | 'year'): string[] {
  const labels: string[] = [];
  const now = new Date();
  let current = new Date();
  
  for (let i = 0; i < periods; i++) {
    if (periodType === 'month') {
      current = new Date(now.getFullYear(), now.getMonth() - i, 1);
      labels.unshift(new Intl.DateTimeFormat('en-US', { month: 'short' }).format(current));
    } else if (periodType === 'quarter') {
      const quarterMonth = Math.floor(now.getMonth() / 3) * 3 - (i * 3);
      current = new Date(now.getFullYear(), quarterMonth, 1);
      const quarter = Math.floor(current.getMonth() / 3) + 1;
      labels.unshift(`Q${quarter}`);
    } else if (periodType === 'year') {
      current = new Date(now.getFullYear() - i, 0, 1);
      labels.unshift(current.getFullYear().toString());
    }
  }
  
  return labels;
}
