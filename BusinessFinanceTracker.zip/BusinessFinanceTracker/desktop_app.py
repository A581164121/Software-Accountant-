#!/usr/bin/env python3
import tkinter as tk
from tkinter import ttk, messagebox, font
import sqlite3
import os
from ttkthemes import ThemedTk
from datetime import datetime
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd
from PIL import Image, ImageTk

from modules.database import Database
from modules.dashboard import DashboardFrame
from modules.inventory import InventoryFrame
from modules.accounts_receivable import AccountsReceivableFrame
# Import placeholder modules for those not fully implemented yet
from modules.placeholder_modules import (
    SalesFrame, PurchasesFrame, AccountsPayableFrame,
    GeneralLedgerFrame, BankReconciliationFrame, ReceiptsFrame
)
from modules.reports import BalanceSheetFrame, CashFlowFrame, ProfitLossFrame

class FinanceFlowApp(ThemedTk):
    def __init__(self):
        super().__init__(theme="arc")  # Clean, modern theme
        
        self.title("FinanceFlow - Accounting Software")
        self.geometry("1200x700")
        self.minsize(800, 600)
        
        # Initialize database
        self.db = Database()
        
        # Configure styles
        self.setup_styles()
        
        # Create main container
        self.main_container = ttk.Frame(self)
        self.main_container.pack(fill=tk.BOTH, expand=True)
        
        # Create sidebar for navigation
        self.setup_sidebar()
        
        # Create content area
        self.content_frame = ttk.Frame(self.main_container, style='Content.TFrame')
        self.content_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Dictionary to store frames for different modules
        self.frames = {}
        
        # Initialize all frames
        self.initialize_frames()
        
        # Show dashboard by default
        self.show_frame('dashboard')
        
    def setup_styles(self):
        """Configure ttk styles for the application"""
        self.style = ttk.Style()
        
        # Define colors
        self.primary_color = "#1976D2"  # Blue
        self.secondary_color = "#4CAF50"  # Green
        self.accent_color = "#D32F2F"  # Red
        self.bg_color = "#FFFFFF"  # White
        self.text_color = "#333333"  # Dark gray
        self.light_gray = "#F5F5F5"  # Light gray
        
        # Configure fonts
        default_font = font.nametofont("TkDefaultFont")
        default_font.configure(family="Helvetica", size=10)
        heading_font = font.Font(family="Helvetica", size=12, weight="bold")
        
        # Configure styles
        self.style.configure('Sidebar.TFrame', background=self.primary_color)
        self.style.configure('Content.TFrame', background=self.bg_color)
        self.style.configure('Nav.TButton', 
                             background=self.primary_color, 
                             foreground='white',
                             borderwidth=0)
        self.style.map('Nav.TButton', 
                        background=[('active', self.primary_color), 
                                    ('pressed', '!disabled', self.primary_color)],
                        foreground=[('active', 'white'), 
                                    ('pressed', 'white')])
        
        self.style.configure('Primary.TButton', 
                             background=self.primary_color, 
                             foreground='white')
        self.style.map('Primary.TButton', 
                        background=[('active', '#1668b8'), 
                                    ('pressed', '!disabled', '#105394')])
        
        self.style.configure('Accent.TButton', 
                             background=self.accent_color, 
                             foreground='white')
        self.style.map('Accent.TButton', 
                        background=[('active', '#bc2a2a'), 
                                    ('pressed', '!disabled', '#9e2424')])
        
        self.style.configure('Success.TButton', 
                             background=self.secondary_color, 
                             foreground='white')
        self.style.map('Success.TButton', 
                        background=[('active', '#43a047'), 
                                    ('pressed', '!disabled', '#388e3c')])
                                    
        # Treeview styles (for data tables)
        self.style.configure("Treeview", 
                            background=self.bg_color,
                            foreground=self.text_color, 
                            rowheight=25, 
                            fieldbackground=self.bg_color)
        self.style.configure("Treeview.Heading", 
                            font=heading_font, 
                            background=self.light_gray, 
                            foreground=self.text_color)
        self.style.map('Treeview', 
                       background=[('selected', self.primary_color)])
    
    def setup_sidebar(self):
        """Create the navigation sidebar"""
        # Sidebar container
        self.sidebar = ttk.Frame(self.main_container, style='Sidebar.TFrame', width=220)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y, expand=False)
        self.sidebar.pack_propagate(False)  # Prevent sidebar from shrinking
        
        # Logo and title
        title_frame = ttk.Frame(self.sidebar, style='Sidebar.TFrame')
        title_frame.pack(fill=tk.X, padx=10, pady=(15, 20))
        
        title_label = ttk.Label(title_frame, text="FinanceFlow", 
                               background=self.primary_color, 
                               foreground="white", 
                               font=("Helvetica", 16, "bold"))
        title_label.pack(side=tk.LEFT)
        
        subtitle_label = ttk.Label(title_frame, text="Accounting Software", 
                                 background=self.primary_color, 
                                 foreground="white", 
                                 font=("Helvetica", 8))
        subtitle_label.pack(side=tk.LEFT, padx=(5, 0), pady=(6, 0))
        
        # Navigation buttons - Main
        section_label = ttk.Label(self.sidebar, text="MAIN", 
                                background=self.primary_color, 
                                foreground="#B3E5FC", 
                                font=("Helvetica", 8))
        section_label.pack(fill=tk.X, padx=10, pady=(10, 5), anchor=tk.W)
        
        self.create_nav_button("Dashboard", 'dashboard')
        
        # Navigation buttons - Transactions
        section_label = ttk.Label(self.sidebar, text="TRANSACTIONS", 
                                background=self.primary_color, 
                                foreground="#B3E5FC", 
                                font=("Helvetica", 8))
        section_label.pack(fill=tk.X, padx=10, pady=(10, 5), anchor=tk.W)
        
        self.create_nav_button("Sales", 'sales')
        self.create_nav_button("Purchases", 'purchases')
        self.create_nav_button("Inventory", 'inventory')
        
        # Navigation buttons - Accounting
        section_label = ttk.Label(self.sidebar, text="ACCOUNTING", 
                                background=self.primary_color, 
                                foreground="#B3E5FC", 
                                font=("Helvetica", 8))
        section_label.pack(fill=tk.X, padx=10, pady=(10, 5), anchor=tk.W)
        
        self.create_nav_button("Accounts Receivable", 'accounts_receivable')
        self.create_nav_button("Accounts Payable", 'accounts_payable')
        self.create_nav_button("General Ledger", 'general_ledger')
        self.create_nav_button("Bank Reconciliation", 'bank_reconciliation')
        self.create_nav_button("Receipts", 'receipts')
        
        # Navigation buttons - Reports
        section_label = ttk.Label(self.sidebar, text="REPORTS", 
                                background=self.primary_color, 
                                foreground="#B3E5FC", 
                                font=("Helvetica", 8))
        section_label.pack(fill=tk.X, padx=10, pady=(10, 5), anchor=tk.W)
        
        self.create_nav_button("Balance Sheet", 'balance_sheet')
        self.create_nav_button("Cash Flow", 'cash_flow')
        self.create_nav_button("Profit & Loss", 'profit_loss')
        
        # User profile
        user_frame = ttk.Frame(self.sidebar, style='Sidebar.TFrame')
        user_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        
        user_label = ttk.Label(user_frame, text="John Doe", 
                              background=self.primary_color, 
                              foreground="white", 
                              font=("Helvetica", 10, "bold"))
        user_label.pack(side=tk.LEFT)
        
        role_label = ttk.Label(user_frame, text="Administrator", 
                             background=self.primary_color, 
                             foreground="#B3E5FC", 
                             font=("Helvetica", 8))
        role_label.pack(side=tk.LEFT, padx=(5, 0), pady=(0, 0))
    
    def create_nav_button(self, text, frame_id):
        """Create a navigation button in the sidebar"""
        button = ttk.Button(self.sidebar, text=text, style='Nav.TButton',
                          command=lambda: self.show_frame(frame_id))
        button.pack(fill=tk.X, padx=5, pady=2)
        
    def initialize_frames(self):
        """Initialize all module frames"""
        # Create instances of each module's frame
        self.frames['dashboard'] = DashboardFrame(self.content_frame, self)
        self.frames['sales'] = SalesFrame(self.content_frame, self)
        self.frames['purchases'] = PurchasesFrame(self.content_frame, self)
        self.frames['inventory'] = InventoryFrame(self.content_frame, self)
        self.frames['accounts_receivable'] = AccountsReceivableFrame(self.content_frame, self)
        self.frames['accounts_payable'] = AccountsPayableFrame(self.content_frame, self)
        self.frames['general_ledger'] = GeneralLedgerFrame(self.content_frame, self)
        self.frames['bank_reconciliation'] = BankReconciliationFrame(self.content_frame, self)
        self.frames['receipts'] = ReceiptsFrame(self.content_frame, self)
        self.frames['balance_sheet'] = BalanceSheetFrame(self.content_frame, self)
        self.frames['cash_flow'] = CashFlowFrame(self.content_frame, self)
        self.frames['profit_loss'] = ProfitLossFrame(self.content_frame, self)
        
        # Place all frames in the content area but only show one at a time
        for frame in self.frames.values():
            frame.pack(fill=tk.BOTH, expand=True)
            frame.pack_forget()
    
    def show_frame(self, frame_id):
        """Show the selected frame and hide others"""
        # Hide all frames
        for frame in self.frames.values():
            frame.pack_forget()
        
        # Show the selected frame
        self.frames[frame_id].pack(fill=tk.BOTH, expand=True)
        
        # Refresh data in the frame if needed
        if hasattr(self.frames[frame_id], 'refresh_data'):
            self.frames[frame_id].refresh_data()

if __name__ == "__main__":
    app = FinanceFlowApp()
    app.mainloop()