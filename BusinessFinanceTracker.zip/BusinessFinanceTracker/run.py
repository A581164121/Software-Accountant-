#!/usr/bin/env python3
import os
import sys
from desktop_app import FinanceFlowApp

if __name__ == "__main__":
    # Run the desktop application
    app = FinanceFlowApp()
    app.mainloop()